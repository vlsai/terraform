该示例展示如何使用云商店提供的资源编排能力，在用户购买镜像后，自动化开通部署，提升用户的购买体验。

示例代码请参考[code目录](code)

文档请参考[introduction/README.md](introduction/README.md)