## 介绍

华为云商店提供了应用自动部署能力，现支持镜像类商品和License类商品。您可以通过开发自动部署模板，为您上架到云商店的应用提供自动部署能力。在买家购买了您的应用以后，可以做到一键开通，提升买家的购买和部署效率，同时降低您的交付成本。

通过本示例您将学到：
* 如何开发自动部署模板。
* 如何发布镜像/软件包资产。
* 如何修改镜像/License商品，使其支持自动部署。

## 开发时序图/流程图

1. 针对镜像类商品，自动部署的接入流程请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649339.html

2. 针对License商品，自动部署的接入流程请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649325.html

## 前置条件
使用华为云商店的自动部署能力，需要先成为华为云商店的商家，并发布一个镜像类商品或License类商品。商家入驻、镜像类商品和License类商品的发布可参考官方文档，这里不再详细阐述。
* 商家入驻可参考：https://support.huaweicloud.com/usermanual-marketplace/sp_topic_0000007.html。
* 制作私有镜像和发布镜像类商品可以参考华为云商店官方指导文档：https://support.huaweicloud.com/usermanual-marketplace/sp_topic_0000017.html。

   **注意：制作完镜像后，需要手工限制SSH服务使用的秘钥文件权限合/etc/ssh/sshd_config的访问权限，限制方法可参考：[镜像商品上架预处理流程](https://support.huaweicloud.com/usermanual-marketplace/sp_topic_00000880.html)**

* License类商品发发布可参考：https://support.huaweicloud.com/usermanual-marketplace/sp_topic_0000028.html


## 制作软件包
如果您是镜像商品或者使用镜像作为部署物，可以直接略过本章节。软件包的制作请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649327.html


## 制作镜像
如果您的应用运行环境比较复杂，建议您将软件包放到镜像中，使用镜像作为部署物。同时建议您将您应用设置为开机自启动，避免客户在使用过程中，由于关机、开机导致应用无法使用。如果使用镜像作为部署物，您需要额外发布一个隐藏的镜像商品，镜像的制作和商品的发布可参考：https://support.huaweicloud.com/usermanual-marketplace/sp_topic_0000017.html。


## 资产申请
如果您是镜像类商品，可直接略过本章节。制作完软件包/镜像以后，您需要进入云商店的卖家中心发布资产，下面模板开发会用到资产Id查询相应的软件包下载地址。资产的发布您可以参考：https://support.huaweicloud.com/usermanual-marketplace/sp_topic_0000123.html

## 开发/修改自动部署模板
自动部署模板基于Terraform进行开发。[Terraform](https://www.terraform.io/)是一个开源的自动化资源编排工具，使用Terraform管理云资源的流程如下图所示。在运行本示例之前，您需要先参考[Terraform的快速入门](https://support.huaweicloud.com/qs-terraform/index.html)完成Terraform的安装、配置，使用Terraform完成华为云VPC的创建。同时学习[华为云资源编排服务RFS](https://support.huaweicloud.com/usermanual-aos/rf_04_0003.html),掌握如何创建资源栈、创建执行计划、删除资源栈等。


![](assets/3.1.png)


Terraform支持使用配置文件描述单个应用或整个数据中心。通过Terraform您可以轻松的创建、管理、删除华为云资源，并对其进行版本控制。Terraform支持编排的华为云资源请参考：https://registry.terraform.io/providers/huaweicloud/huaweicloud/latest/docs。

本篇Codelab所涉及的自动部署模板的源码位于code目录下，code的目录结构如下图所示。
![](assets/3.4.png)

其中modules下面包含了ecs、eip、evs、rds、elb、vpc等多个模块，分别提供了创建ECS、EIP、EVS、RDS、elb、VPC等云服务的相关功能，您可以根据您的实际业务使用。在solutions中目前四个解决方案级的模板，每个解决方案级模板的功能如下:
* ecs-cluster-deployment， ECS集群化部署模板，其中包含了两个ECS、一个RDS、一个ELB和一个EIP。
* ecs-fg-init-deployment，ECS和FunctionGraph的部署模板，在ECS创建完成之后，借助于FunctionGraph执行shell脚本。
* single-node-ecs-deployment，新建VPC的ECS单节点部署，其中包含了一个ECS、一个RDS和一个EIP。
* single-node-ecs-deployment-ExistingVPC，基于已有VPC和子网的ECS单节点部署，其中包含了一个ECS、一个RDS和一个EIP。
* ecs-ha-deployment，基于已有VPC和子网的ECS高可用部署，其中包含了两台ECS、两个EIP和一个VIP。

每个模板的组成包括：.extension、main.tf、outputs.tf、providers.tf、variables.tf和versions.tf，下面分别介绍各个文件的作用，详细的使用方法可参考每个解决方案级示例模板目录下的README.md。

* .extension，RFS的扩展能力，用户帮助用户更好的配置参数，理解参数，更多信息可参考：https://support.huaweicloud.com/tr-aos/rf_05_0026.html
* main.tf，自动部署模板的执行入口，包含了创建云资源的具体代码逻辑。
* outputs.tf，自动部署的输出信息，比如ECS的资源Id。
* providers.tf，huaweicloud provider的配置信息，本地调测的时候，我们推荐您使用环境变量的方式配置ak和sk，不要在providers.tf文件中直接配置ak和sk。
* variables.tf，部署模板中定义的变量，需要部署时手工输入，比如ECS实例的密码。
* versions.tf，huaweicloud provider的版本，我们推荐您采用>=配置provider的版本号，比如version = ">= 1.70.0"。

 完整的示例代码可通过Codelab页面右侧的“浏览代码”查看，如下图所示。
![](assets/3.3.png)


## 自动部署模板本地调测
1. 安装Terraform，使用**环境变量**的方式为Terraform配置认证信息，详情可参考[Terraform快速入门](https://support.huaweicloud.com/qs-terraform/index.html)，如果您用的是windows，可以使用如下命令设置环境变量：
      ```
     set HW_REGION_NAME=cn-north-4
     set HW_ACCESS_KEY=your ak
     set HW_SECRET_KEY=your sk
     ```
2. 打开cmd命令行窗口，进入模板目录，执行如下命令，并根据提示输入相应的配置信息。
    ```
    terraform init
    terraform plan 
    terraform apply 
    ```
3. 进入华为云控制台，查看创建出来的云服务信息
4. 本示例创建的云资源需要您支付相应的费用，当您不需要这些资源的时候，请执行`terraform destroy`及时删除这些资源。


## 在线测试模板

自动部署模板的测试请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649329.html

## 为镜像类商品关联自动部署模板

如果您是License商品，可直接略过本章节，镜像类商品关联自动部署模板请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649332.html

## 为资产关联自动部署模板
如果您是镜像类商品，可直接略过本章节，为资产关联自动部署模板请参考[修改资产操作指导](https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649335.html)中的**修改自动部署模板操作部署**

## 发布资产
关联完模板以后，您需要进入云商店的卖家中心发布资产。资产的发布您可以参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649334.html

## 修改商品，为需要做自动部署的规格关联模板/资产
商品的修改请参考：https://support.huaweicloud.com/accessg-marketplace/zh-cn_topic_0070649337.html