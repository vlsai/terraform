output "ecs_flavors" {
  value = var.ecs_flavor
}