# Query Available az
data "huaweicloud_availability_zones" "az" {}

data "huaweicloud_vpc_subnet" "subnet" {
  id = var.business_subnet
}

data "huaweicloud_vpc_subnet" "subnet2" {
  id = var.ha_subnet
}

// Query flavors of all az
data "huaweicloud_compute_flavors" "flavors" {
  count = length(data.huaweicloud_availability_zones.az.names)

  availability_zone = data.huaweicloud_availability_zones.az.names[count.index]

  performance_type = var.ecs_flavor != null ? null : var.performance_type
  cpu_core_count   = var.ecs_flavor != null ? null : var.instance_flavor_cpu
  memory_size      = var.ecs_flavor != null ? null : var.instance_flavor_memory
}

# 局部变量
locals {
  # 网卡3 & vip所在子网掩码
  code3 = split("/", data.huaweicloud_vpc_subnet.subnet.cidr)[1]
  # 网卡2 ha口子网掩码
  code2 = split("/", data.huaweicloud_vpc_subnet.subnet2.cidr)[1]

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  app_id      = "SS2"
  name_suffix = formatdate("hhmm", timestamp())

  # Billing model for cloud resources
  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  # The billing model for bandwidth
  bandwidth_charge_mode = "bandwidth"

  # Image information in different regions, you need to enter your own image ID or add another region.
  # For Marketplace Image Id,you can log in to Seller Console, view the marketplace image id on Product Specifications section of My Products detail page.
  instance_image_id_maps = {
    cn-north-4     = "02a17486-1214-4e42-8da7-7d200cac585e"
    cn-south-1     = ""
    cn-east-3      = "ea0d6e0e-99c3-406d-a873-3bb45462b624"
    cn-north-9     = ""
    cn-southwest-2 = ""
  }

  # NIC information of ECS
  networks0 = distinct(flatten(jsondecode(jsonencode(module.ecs-master.networks))[*][*].port))
  networks1 = distinct(flatten(jsondecode(jsonencode(module.ecs-slave.networks))[*][*].port))

  # az and available flavors map, such as {cn-north-4a = ["ac7.large.2", "c3ne.large.2"]}
  az2flavors_maps = { for i, flavor_ids in data.huaweicloud_compute_flavors.flavors[*].ids : data.huaweicloud_availability_zones.az.names[i] => flavor_ids if length(flavor_ids) > 0 }

  # az and available flavors map, such as {ac7.large.2 = ["cn-north-4a", "cn-north-4b"]}
  flavors2az_maps = transpose(local.az2flavors_maps)

  # Only flavors that exist in two or more AZs are reserved.
  available_flavors_map = { for flavor_id, azs in local.flavors2az_maps : flavor_id => azs if length(azs) >= 2 }

  # Obtains an available flavor.
  available_flavor = var.ecs_flavor != null ? var.ecs_flavor : keys(local.available_flavors_map)[0]

  # Obtain the AZs of the master and slave nodes.
  az_master = local.available_flavors_map[local.available_flavor][0]
  az_slave  = local.available_flavors_map[local.available_flavor][1]
}

module "ecs-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "ecs-secgroup")
  is_delete_default_rules = true

  # You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "22", remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "443", remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
    # By default, the outbound direction is not restricted.
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
  ]
}

# security group of HA Subnet
module "ha-subnet-secgroup" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "ha-subnet-secgroup")
  is_delete_default_rules = true

  # You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "8080", remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
    # By default, the outbound direction is not restricted.
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
  ]
}

# security group of Business Subnet
module "business-subnet-secgroup" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "business-subnet-secgroup")
  is_delete_default_rules = true

  # You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "8081", remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
    # By default, the outbound direction is not restricted.
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
  ]
}

# Create an Master ECS
module "ecs-master" {
  source             = "../../modules/ecs"
  is_instance_create = true

  # The total number of The ECS instance
  instance_count = 1

  instance_image_id = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]

  instance_flavor_id = local.available_flavor
  availability_zone  = local.az_master

  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs-master")

  security_group_ids = module.ecs-security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = "GPSSD"
  system_disk_size = 40

  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = var.manage_subnet, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = false, access_network = false },
  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  instance_tags = local.tags

  user_data = <<-EOF
  #!/bin/bash
  echo "${huaweicloud_vpc_network_interface.ha-slave-network.fixed_ip_v4} , ${local.code3} ,${local.code2}">> /usr/local/result.txt
  echo "${huaweicloud_networking_vip.vip.ip_address}">> /usr/local/result.txt
  echo "${data.huaweicloud_vpc_subnet.subnet.gateway_ip}">> /usr/local/result.txt
  echo "${huaweicloud_vpc_network_interface.ha-master-network.fixed_ip_v4}">> /usr/local/result.txt
  echo "${huaweicloud_vpc_network_interface.ha-master-network.mac_address}">> /usr/local/result.txt
  EOF
}

# Create ha network in ha subnet which will attach to master ecs
resource "huaweicloud_vpc_network_interface" "ha-master-network" {
  name               = format("%s-%s", local.app_id, "ha-master-network")
  subnet_id          = var.ha_subnet
  security_group_ids = module.ha-subnet-secgroup.secgroup_id
}

# attach ha subnet to master ecs
resource "huaweicloud_compute_interface_attach" "attach-ha-master" {
  instance_id       = module.ecs-master.ecs_ids[0]
  port_id           = huaweicloud_vpc_network_interface.ha-master-network.id
  source_dest_check = false
}

# Create business network in business subnet which will attach to master ecs
resource "huaweicloud_vpc_network_interface" "bs-master-network" {
  name               = format("%s-%s", local.app_id, "bs-master-network")
  subnet_id          = var.business_subnet
  security_group_ids = module.business-subnet-secgroup.secgroup_id
}

# attach business subnet to master ecs
resource "huaweicloud_compute_interface_attach" "attach-bs-master" {
  instance_id       = module.ecs-master.ecs_ids[0]
  port_id           = huaweicloud_vpc_network_interface.bs-master-network.id
  source_dest_check = false
  depends_on = [huaweicloud_compute_interface_attach.attach-ha-master]
}

# Scripts to be executed on the Master ECS node
module "coc-script-master" {
  source             = "../../modules/coc"
  script_name        = "master-script"
  script_description = "Scripts to be executed on the Master ECS node"
  risk_level         = "LOW"
  script_version     = "1.0.0"
  script_type        = "SHELL"

  script_content = <<EOF
  #! /bin/bash
  echo "hello ${module.ecs-slave.access_ips[0]}!" >> /usr/local/coc.txt
  EOF

  instance_id     = module.ecs-master.ecs_ids[0]
  execute_timeout = 600
  execute_user    = "root"
}

module "ecs-slave" {
  source             = "../../modules/ecs"
  is_instance_create = true

  # The total number of The ECS instance
  instance_count = 1

  instance_image_id = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]

  instance_flavor_id = local.available_flavor
  availability_zone  = local.az_slave

  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs-slave")

  security_group_ids = module.ecs-security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = "GPSSD"
  system_disk_size = 40

  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = var.manage_subnet, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = false, access_network = false },
  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  instance_tags = local.tags

  user_data = <<-EOF
  #!/bin/bash
  echo "${huaweicloud_vpc_network_interface.ha-master-network.fixed_ip_v4}">> /usr/local/result.txt
  echo "${huaweicloud_networking_vip.vip.ip_address}">> /usr/local/result.txt
  EOF
}

# Create ha network in ha subnet which will attach to Slave ecs
resource "huaweicloud_vpc_network_interface" "ha-slave-network" {
  name               = format("%s-%s", local.app_id, "ha-slave-network")
  subnet_id          = var.ha_subnet
  security_group_ids = module.ha-subnet-secgroup.secgroup_id
}

# attach ha subnet to slave ecs
resource "huaweicloud_compute_interface_attach" "attach-ha-slave" {
  instance_id       = module.ecs-slave.ecs_ids[0]
  port_id           = huaweicloud_vpc_network_interface.ha-slave-network.id
  source_dest_check = false
}

# Create ha network in ha subnet which will attach to Slave ecs
resource "huaweicloud_vpc_network_interface" "bs-slave-network" {
  name               = format("%s-%s", local.app_id, "bs-slave-network")
  subnet_id          = var.business_subnet
  security_group_ids = module.business-subnet-secgroup.secgroup_id
}

# attach business subnet to slave ecs
resource "huaweicloud_compute_interface_attach" "attach-bs-slave" {
  instance_id        = module.ecs-slave.ecs_ids[0]
  port_id         = huaweicloud_vpc_network_interface.bs-slave-network.id
  source_dest_check  = false
  depends_on = [huaweicloud_compute_interface_attach.attach-ha-slave]
}

# Scripts to be executed on the Master ECS node
module "coc-script-slave" {
  source             = "../../modules/coc"
  script_name        = "slave-script"
  script_description = "Scripts to be executed on the Slave ECS node"
  risk_level         = "LOW"
  script_version     = "1.0.0"
  script_type        = "SHELL"

  script_content = <<EOF
  #! /bin/bash
  echo "hello ${module.ecs-master.access_ips[0]}!" >> /usr/local/coc.txt
  EOF

  instance_id     = module.ecs-slave.ecs_ids[0]
  execute_timeout = 600
  execute_user    = "root"
}

# Create an EIP, if you do not need to create an EIP, delete the code and modules/eip directory
module "eip-master" {
  source = "../../modules/eip"

  is_eip_create = var.is_eip_create

  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip-master")

  publicip_type = "5_bgp"

  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = "PER"
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = 1

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags

  associated_configuration = [
    { fixed_ip = null, network_id = null, port_id = local.networks0[0] }
  ]
}

module "eip-slave" {
  source = "../../modules/eip"

  is_eip_create = var.is_eip_create

  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip-slave")

  publicip_type = "5_bgp"

  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = "PER"
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = 1

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  associated_configuration = [
    { fixed_ip = null, network_id = null, port_id = local.networks1[0] }
  ]

  eip_tags = local.tags
}

# Create VIP
resource "huaweicloud_networking_vip" "vip" {
  network_id = var.business_subnet
}

# Associate VIP with the business subnet of ECS
resource "huaweicloud_networking_vip_associate" "vip_associated" {
  vip_id   = huaweicloud_networking_vip.vip.id
  port_ids = [huaweicloud_vpc_network_interface.bs-master-network.id, huaweicloud_vpc_network_interface.bs-slave-network.id]
}