variable "ecs_flavor" {
  type = string
  description = "the flavor of ecs."
  default = null
}
variable "instance_flavor_cpu" {
  type        = number
  description = "Specifies the number of vCPUs in the ECS flavor."
  default = 2
  validation {
    condition     = contains([2, 4], var.instance_flavor_cpu)
    error_message = "Allowed values for input_parameter are 2 and 4."
  }
}
variable "instance_flavor_memory" {
  type        = number
  description = "Specifies the memory size(GB) in the ECS flavor."
  default = 4
  validation {
    condition     = contains([4, 8], var.instance_flavor_memory)
    error_message = "Allowed values for input_parameter are 4 and 8."
  }
}
variable "performance_type" {
  type        = string
  description = "the ECS flavor type. Possible values are as follows:normal(General computing)、computingv3(General computing-plus)、highmem(Memory-optimized)、saphana(Large-memory HANA ECS)、diskintensive(Disk-intensive)"
  default = "normal"
  validation {
    condition     = contains(["normal", "computingv3", "highmem", "saphana", "diskintensive"], var.performance_type)
    error_message = "Allowed values for input_parameter are normal、computingv3、highmem、saphana、diskintensive."
  }
}
variable "is_eip_create" {
  type = string
  default = "true"
  description = "Indicates whether to create the EIP"
  validation {
    condition = contains(["true", "false"], var.is_eip_create)
    error_message = "Indicates whether to create the EIP, the value can be true or false"
  }
}

# 管理子网
variable "manage_subnet" {
  type = string
  description = "manage subnet"
}
# HA子网
variable "ha_subnet" {
  type = string
  description = "HA subnet"
}

# 业务子网
variable "business_subnet" {
  type = string
  description = "Business subnet"
}

variable "charging_mode" {
  type        = string
  nullable    = false
  default = "postPaid"
  description = " Specifies the charging mode of the disk. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode. Changing this creates a new disk."
  validation {
    condition     = contains(["postPaid", "prePaid"], var.charging_mode)
    error_message = "Allowed values for input_parameter are prePaid or postPaid."
  }
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase.Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = string
  default = "month"
  validation {
    condition     = contains(["month", "year"], var.period_unit)
    error_message = "Allowed values for input_parameter are month or year."
  }
}

variable "period" {
  description = "The period number of the pre-paid purchase. If period_unit is set to month , the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = number
  default = 1
}