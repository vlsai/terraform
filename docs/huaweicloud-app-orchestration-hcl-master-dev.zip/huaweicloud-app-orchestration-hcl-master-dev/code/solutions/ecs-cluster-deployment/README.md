## 介绍

本示例提供了一个方案，通过[Terraform](https://support.huaweicloud.com/productdesc-terraform/index.html)或者[华为云的资源编排服务RFS](https://support.huaweicloud.com/usermanual-aos/rf_04_0020.html)在已有的[VPC和子网](https://support.huaweicloud.com/productdesc-vpc/vpc_pro_0001.html)下，自动完成[弹性云服务器ECS](https://www.huaweicloud.com/product/ecs.html)、[云硬盘EVS](https://www.huaweicloud.com/product/evs.html)和[安全组](https://support.huaweicloud.com/usermanual-vpc/zh-cn_topic_0073379079.html)的创建和配置。

在运行本示例之前，您需要先参考
[Terraform的快速入门](https://support.huaweicloud.com/qs-terraform/index.html)完成Terraform的安装、配置，使用Terraform完成华为云VPC的创建。同时学习[华为云资源编排服务RFS](https://support.huaweicloud.com/usermanual-aos/rf_04_0003.html),掌握如何创建资源栈、创建执行计划、删除资源栈等。
通过本示例您将学到：
* 基于Terraform配置语言，开发自动部署模板
* 搭建Terraform环境，使用Terraform命令行工具，在本地完成自动部署模板的开发、调测，完成华为云ECS等资源的自动创建、配置。
* 基于华为云资源编排服务RFS，完成自动部署模板的开发、调测，完成华为云ECS等资源的自动创建、配置。

## 使用说明

1. 将源码目录 `code/solutions/ecs-cluster-deployment` 拷贝出一份副本，并删除`assets`目录和`README.md`文件

2. 将模块目录 `code/modules` 中的 `vpc` 、`security-group`、`rds`、`ecs`、`elb`、`eip`、`nat` 和`evs`模块拷贝到 ecs-cluster-deployment 副本之下的 `modules` 目录当中

    最终 ecs-cluster-deployment 副本目录结构如下所示：

    ```
    |-- .extension
    |   -- main.rfs.json
    |-- modules
    |   |-- ecs
    |   |-- eip
    |   |-- evs
    |   |-- security-group
    |   |-- vpc-route
    |-- main.tf
    |-- outputs.tf
    |-- provider.tf
    |-- variables.tf
    |-- versions.tf
    ```

3. 修改 ecs-cluster-deployment副本之下的 `main.tf` 的模块引用路径，即将 `../../modules/vpc` 改为 `./modules/vpc`，将 `../../modules/security-group` 改为 `./modules/security-group`，将 `../../modules/rds` 改为 `./modules/rds`，将 `../../modules/ecs` 改为 `./modules/ecs`，
    将 `../../modules/elb` 改为 `./modules/elb`，将 `../../modules/nat` 改为 `./modules/nat`，将 `../../modules/evs` 改为 `./modules/evs`，

    * 修改前：

        ![](assets/image001.png)

    * 修改后：

        ![](assets/image002.png)


4. 基于Terraform运行本示例
   * 安装Terraform，使用**环境变量**的方式为Terraform配置认证信息，详情可参考[Terraform快速入门](https://support.huaweicloud.com/qs-terraform/index.html)，如果您用的是windows，可以使用如下命令设置环境变量：
      ```
     set HW_REGION_NAME=cn-north-4
     set HW_ACCESS_KEY=your ak
     set HW_SECRET_KEY=your sk
     ```
   * 打开cmd命令行窗口，进入 `ecs-cluster-deployment` 副本目录，执行如下命令，并根据提示输入相应的配置信息。
       ```
       terraform init
       terraform plan 
       terraform apply 
       ```
   * 进入华为云ECS的控制台，查看创建出来的ECS实例
   * 本示例创建的云资源需要您支付相应的费用，当您不需要这些资源的时候，请执行`terraform destroy`及时删除这些资源。

5. 基于华为云资源编排服务RFS运行本示例

   * 进入 `ecs-cluster-deployment` 副本目录，将目录内的所有内容添加到zip压缩包中，命名为 `ecs-cluster-deployment.zip`

   * 进入RFS控制台，创建资源栈，上传 `ecs-cluster-deployment.zip`，如下图所示，更多详情可参考[RFS创建资源栈](https://support.huaweicloud.com/usermanual-aos/rf_04_0003.html)

        ![](assets/image003.png)

    * 填写配置参数，如下图所示

        ![](assets/image004.png)

    * 设置资源栈

        ![](assets/image005.png)

    * 确认配置参数和资源栈的设置，如果没有问题，点击`创建执行计划`

        ![](assets/image006.png)

    * 查看费用明细，如下图所示
   
        ![](assets/image007.png)

        ![](assets/image008.png)

    * 如果没有问题，点击`部署`，如下图所示
   
        ![](assets/image009.png)

    * 等待资源部署成功，如下图所示

        ![](assets/image010.png)

        ![](assets/image011.png)
   
    * 本示例创建的云资源需要您支付相应的费用，当您不需要这些资源的时候，请`删除资源栈`及时删除这些资源，如下图所示
        ![](assets/im~~~~age012.png)

6. 至此，您就基于Terraform和华为云资源编排服务RFS完成了本示例的运行，接下来，您就可以基于此示例和您自己的应用软件，完成您应用软件自动部署模板的开发