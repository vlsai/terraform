// Query the az available for the Region
data "huaweicloud_availability_zones" "az" {}

data "huaweicloud_compute_flavors" "flavors" {
  availability_zone = local.availability_zone
  performance_type  = "normal"
  cpu_core_count    = 2
  memory_size       = 4
}

//  Query available falvors for ECS
data "huaweicloud_images_image" "myimage" {
  name        = "CentOS 7.9 64bit"
  most_recent = true
}

//  Query available RDS for falvor
data "huaweicloud_rds_flavors" "flavors" {
  db_type           = var.db_engines
  db_version        = var.db_version
  instance_mode     = "single"
  vcpus             = 2
  memory            = 4
  availability_zone = local.availability_zone
}

locals {
  //  You need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id = format("%s-%s", "mkp-app", formatdate("hhmm", timestamp()))

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  //  Billing model for cloud resources
  charging_mode = "postPaid"
  //  The billing model for bandwidth
  bandwidth_charge_mode = "traffic"
  db_port               = 3306
  availability_zone     = data.huaweicloud_availability_zones.az.names[0]

  period_unit = var.period_unit
  period      = var.period
  // The billing model for bandwidth, You need to modify it according to your actual situation.
  bandwidth_share_type = "PER"
  //  Mapping of Region and imageId, required
  image_ids_map = {
    cn-north-4 = ""
    cn-south-1 = ""
  }
}

// Create a VPC
module "vpc" {
  source = "../../modules/vpc"

  # config of vpc
  name_suffix       = "mkp"
  vpc_name          = format("%s-%s", local.app_id, "vpc")
  availability_zone = local.availability_zone
  vpc_cidr          = "192.168.0.0/16"
  remote_ip_cidr    = var.remote_ip_cidr
  vpc_tags          = local.tags

  # config of subnet
  subnet_name           = format("%s-%s", local.app_id, "subnet")
  vpc_subnet_cidr       = var.vpc_subnet_cidr
  vpc_subnet_gateway_ip = "192.168.10.1"
  subnet_tags           = local.tags
}

module "ecs-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = "mkp"
  secgroup_name           = format("%s-%s", local.app_id, "ecs-secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "20-9527", remote_ip_prefix = var.remote_ip_cidr, remote_group_id = null },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = "tcp", ports = "1433", remote_ip_prefix = var.vpc_subnet_cidr, remote_group_id = null },
  ]
}

module "rds-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = "mkp"
  secgroup_name           = format("%s-%s", local.app_id, "rds-secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "1433", remote_ip_prefix = var.vpc_subnet_cidr, remote_group_id = null }
  ]
}

// To create an RDS, if you do not need to create an RDS, delete the code and the modules/rds directory
module "rds" {
  source = "../../modules/rds_mysql"

  is_rds_create = true

  charging_mode            = local.charging_mode
  db_instance_name         = "rds_${local.app_id}"
  db_availability_zone     = [local.availability_zone]
  time_zone                = var.time_zone
  vpc_id                   = module.vpc.vpc_id
  subnet_id                = module.vpc.subnet_id
  security_group_id        = module.rds-security-group.secgroup_id[0]
  flavor                   = data.huaweicloud_rds_flavors.flavors.flavors[0].name
  db_engines               = "MySQL"
  db_version               = "8.0"
  db_password              = var.db_password
  group_type               = "normalLocalssd"
  disk_encryption_id       = ""
  param_group_id           = ""
  keep_days                = 100
  start_time               = "01:00-02:00"
  db_port                  = local.db_port
  db_instance_storage_type = var.db_instance_storage_type
  db_allocated_storage     = var.db_allocated_storage
  rds_tags                 = local.tags

  mysql_configuration = [
    { name = "test", character_set = "utf8" }
  ]
}

// Create an ECS
module "ecs" {
  source = "../../modules/ecs"

  images_visibility  = "public"
  name_suffix        = "mkp"
  instance_name      = format("%s-%s", local.app_id, "ecs")
  availability_zone  = local.availability_zone
  instance_image_id  = data.huaweicloud_images_image.myimage.id
  instance_flavor_id = data.huaweicloud_compute_flavors.flavors.ids[0]
  charging_mode      = local.charging_mode
  security_group_ids = module.ecs-security-group.secgroup_id
  networks_configuration = [
    {
      subnet_id         = module.vpc.subnet_id,
      fixed_ip_v4       = null,
      ipv6_enable       = false,
      source_dest_check = false,
      access_network    = false
  }]
  instance_tags = local.tags
  user_data     = "#!/bin/sh\necho 'root:${var.ecs_password}'| chpasswd"
}

// Create an ELB
module "elb" {
  source = "../../modules/elb"

  loadbalancer_name   = "loadbalancer_${local.app_id}"
  listener_name       = "listener_${local.app_id}"
  pool_name           = "pool_${local.app_id}"
  protocol_port       = var.protocol_port
  lb_method           = var.lb_method
  monitor_type        = var.monitor_type
  monitor_delay       = var.monitor_delay
  monitor_timeout     = var.monitor_timeout
  monitor_max_retries = var.monitor_max_retries
  listener_protocol   = var.listener_protocol
  pool_protocol       = var.pool_protocol
  url_path            = "/"
  ipv4_subnet_id      = module.vpc.subnet_ipv4_subnet_id
  member_configuration = [
    {
      address = module.ecs.access_ips[0],
      weight  = 1
    }
  ]
  listener_tags = local.tags
}

//  Create an EIP, if you do not need to create an EIP, delete the code and modules/eip directory
module "eip" {
  source      = "../../modules/eip"
  name_suffix = "mkp"
  eip_name    = format("%s-%s", local.app_id, "eip")

  publicip_type = "5_bgp"

  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = local.bandwidth_share_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = 1

  charging_mode = local.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  eip_tags = local.tags
}

module "nat" {
  source = "../../modules/nat"

  is_nat_creat = false
  spec         = null
  vpc_id       = null
  subnet_id    = null
  publicip_id  = null
  nat_tags     = local.tags
}

//  To create a data disk for ECS, if you do not need to bind the data disk, delete the code and modules/evs directory
module "evs" {
  source      = "../../modules/evs"
  name_suffix = "mkp"
  volume_name = format("%s-%s", local.app_id, "evs")
  attached_configuration = [
    {
      instance_id = module.ecs.ecs_ids[0]
    }
  ]
  availability_zone = local.availability_zone
  charging_mode     = local.charging_mode

  volume_tags = local.tags
}
