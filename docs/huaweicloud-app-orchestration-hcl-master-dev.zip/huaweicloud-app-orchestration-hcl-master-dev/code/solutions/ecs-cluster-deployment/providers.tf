//  Configure the HuaweiCloud Provider
provider "huaweicloud" {
  region = var.region
}