variable "region" {
  type        = string
  default     = "cn-north-4"
  description = "This is the Huawei Cloud region."
  validation {
    condition     = contains(["cn-north-4", "cn-south-1"], var.region)
    error_message = "Allowed values for input_parameter are cn-north-4 or cn-south-1."
  }
}

variable "ecs_password" {
  type        = string
  description = "the admin password of ecs."
  //  The password can be deployed on the page
  nullable = false
  sensitive   = true
}

variable "remote_ip_cidr" {
  type        = string
  description = " Specifies the remote CIDR, the value needs to be a valid CIDR (i.e. 192.168.0.0/16). Changing this creates a new security group rule."
  nullable = false
}

variable "db_allocated_storage" {
  type        = number
  default     = 40
  description = "the size of database, in GB."
}

variable "db_password" {
  type        = string
  sensitive   = true
  description = "rds password."
  nullable = false
}

variable "time_zone" {
  type        = string
  default     = "UTC"
  description = " Specifies the UTC time zone. For MySQL and PostgreSQL Chinese mainland site and international site use UTC by default. "
}

variable "db_version" {
  type        = string
  default     = "8.0"
  description = "Specifies the database version"
}

variable "db_engines" {
  type        = string
  default     = "MySQL"
  description = "MySQL, PostgreSQL or SQLServer"
}

variable "db_instance_storage_type" {
  type        = string
  default     = "CLOUDSSD"
  description = "Specifies the volume type,the value can be ULTRAHIGH,LOCALSSD,CLOUDSSD,ESSD"
}

variable "protocol_port" {
  type = string
  default = "80"
  description = "The protocol_port of listener and pool"
}

variable "lb_method" {
  type = string
  default = "ROUND_ROBIN"
  description = "ROUND_ROBIN、LEAST_CONNECTIONS、SOURCE_IP"
}

variable "monitor_type" {
  type = string
  default = "TCP"
  description = "TCP、UDP、HTTP、HTTPS"
}

variable "monitor_delay" {
  type    = number
  default = 5
  description = "1-50"
}

variable "monitor_timeout" {
  type    = number
  default = 3
  description = "1-50"
}

variable "monitor_max_retries" {
  type    = number
  default = 3
  description = "1-10"
}

variable "listener_protocol" {
  type = string
  default = "TCP"
  description = "TCP、HTTP、UDP、TERMINATED_HTTPS"
}

variable "pool_protocol" {
  type = string
  default = "TCP"
  description = "TCP、UDP、HTTP"
}

variable "database_character_set" {
  type = string
  default = "utf8"
  description = "utf8、gbk、latin1、utf8m64、binary"
}

variable "database_name" {
  type = string
  default = "test"
  description = "name of the rds database"
}

variable "vpc_subnet_cidr" {
  type        = string
  default     = "192.168.10.0/24"
  description = "Specifies the network segment on which the subnet resides. The value must be in CIDR format and within the CIDR block of the VPC. The subnet mask cannot be greater than 28. Changing this creates a new Subnet."
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase.Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. "

  type        = string
  default     = "month"
  validation {
    condition     = contains([
      "month",
      "year"], var.period_unit)
    error_message = "Allowed values for input_parameter are month or year."
  }
}

variable "period" {
  description = "The period number of the pre-paid purchase. If period_unit is set to month , the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. "
  type        = number
  default     = 1
}
