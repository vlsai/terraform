## 介绍

本示例提供了一个方案，即使用华为云的 [函数工作流 FunctionGraph](https://www.huaweicloud.com/product/functiongraph.html) 能力，实现 [弹性云服务器 ECS](https://www.huaweicloud.com/product/ecs.html) 实例的初始化工作。

通过本示例您将学到：
* 如何创建 [资源编排服务 RFS](https://www.huaweicloud.com/product/aos.html) 的资源栈模板，并执行自动部署。
* 如何在 FunctionGraph 中实现通过 ssh 登录 ECS 实例，并执行 shell 脚本完成 ECS 实例的初始化工作。

## 使用说明

1. 将源码目录 `code/solutions/ecs-fg-init-deployment` 拷贝出一份副本

2. 将模块目录 `code/modules` 中的 `ecs` 和 `vpc` 模块拷贝到 ecs-fg-init-deployment 副本之下的 `modules` 目录当中

最终 ecs-fg-init-deployment 副本目录结构如下所示：

```
|-- .extension
|   `-- main.rfs.json
|-- modules
|   |-- ecs
|   |   |-- main.tf
|   |   |-- outputs.tf
|   |   |-- variables.tf
|   |   `-- versions.tf
|   `-- vpc
|       |-- main.tf
|       |-- outputs.tf
|       |-- variables.tf
|       `-- versions.tf
|-- main.tf
|-- outputs.tf
|-- providers.tf
|-- shell.sh
|-- variables.tf
`-- versions.tf
```

3. 修改 ecs-fg-init-deployment 副本之下的 `main.tf` 的模块引用路径，即将 `../../modules/vpc` 改为 `./modules/vpc`，将 `../../modules/ecs` 改为 `./modules/ecs`

修改前：

![](assets/image001.png)

修改后：

![](assets/image002.png)

4. 在 `ecs-fg-init-deployment` 副本之下的 `shell.sh` 中编写初始化ECS的shell脚本，例如
```sh
apt-get update
echo "$(date) shell exec success" >> date.log
```

5. 进入 `ecs-fg-init-deployment` 副本目录，将目录内的所有内容添加到zip压缩包中，命名为 `ecs-fg-init-deployment.zip`

6. 根据 https://support.huaweicloud.com/usermanual-iam/iam_01_0605.html 指引，创建自定义策略，“策略名称”填写“IAM ALL”，“策略配置方式”选择“JSON视图”，策略内容填写如下内容

```json
{
    "Version": "1.1",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "IAM:*:*"
            ]
        }
    ]
}
```

单击“确定”保存设置。

![](assets/image003.png)

7. 根据 https://support.huaweicloud.com/usermanual-iam/iam_06_0002.html 指引，创建委托，委托类型为云服务，云服务选择RFS 

![](assets/image004.png)

委托策略选择“Tenant Administrator”和“IAM ALL”，选择授权范围方案为所有范围

![](assets/image005.png)

![](assets/image006.png)

8. 进入RFS控制台，创建资源栈，上传第5步打包好的 `ecs-fg-init-deployment.zip`

![](assets/image007.png)

填写配置参数

![](assets/image008.png)

选择第7步创建好的委托，创建执行计划

![](assets/image009.png)

9. 执行计划显示创建成功之后执行部署

![](assets/image010.png)

10. 等待资源部署成功

![](assets/image011.png)

![](assets/image012.png)
