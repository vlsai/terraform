# Put your custom shell script here that should be executed once on the ECS instance.

set -e

uname -a
echo "$(date) shell exec success" >> date.log
