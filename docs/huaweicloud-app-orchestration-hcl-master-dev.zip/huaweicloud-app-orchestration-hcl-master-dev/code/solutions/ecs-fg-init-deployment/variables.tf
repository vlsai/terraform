variable "region" {
  type        = string
  default     = "cn-north-4"
  description = "This is the Huawei Cloud region."
  validation {
    condition     = contains(["cn-north-4", "cn-south-1"], var.region)
    error_message = "Allowed values for input_parameter are cn-north-4 or cn-south-1."
  }
}

variable "ecs_cpu_core_count" {
  type        = number
  default     = 2
  description = "Specifies the number of vCPUs in the ECS flavor"
}

variable "ecs_memory_size" {
  type        = number
  default     = 4
  description = "Specifies the memory size(GB) in the ECS flavor"
}

variable "ecs_password" {
  type        = string
  description = "the admin password of ecs."
  //  The password can be deployed on the page
  nullable  = false
  sensitive = true
}

variable "remote_ip_cidr" {
  type        = string
  description = " Specifies the remote CIDR, the value needs to be a valid CIDR (i.e. 192.168.0.0/16). Changing this creates a new security group rule."
  nullable  = false
}

variable "vpc_subnet_cidr" {
  type        = string
  default     = "192.168.10.0/24"
  description = "Specifies the network segment on which the subnet resides. The value must be in CIDR format and within the CIDR block of the VPC. The subnet mask cannot be greater than 28. Changing this creates a new Subnet."
}
