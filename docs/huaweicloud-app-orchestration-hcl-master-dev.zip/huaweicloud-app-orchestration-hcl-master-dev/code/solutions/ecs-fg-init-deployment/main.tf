// Query the az available for the Region
data "huaweicloud_availability_zones" "az" {}

data "huaweicloud_compute_flavors" "flavors" {
  availability_zone = local.availability_zone
  performance_type  = "normal"
  cpu_core_count    = var.ecs_cpu_core_count
  memory_size       = var.ecs_memory_size
}

// Query available falvors for ECS
data "huaweicloud_images_image" "myimage" {
  name        = "CentOS 7.5 64bit"
  most_recent = true
}

locals {
  // You need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id = format("%s-%s", "mkp-app", formatdate("hhmm", timestamp()))

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  // Billing model for cloud resources
  charging_mode     = "postPaid"
  availability_zone = data.huaweicloud_availability_zones.az.names[0]
  // You need to store the shell script for initializing the ECS instance in this file
  shell = "shell.sh"
}

// Create a VPC
module "vpc" {
  source = "../../modules/vpc"

  # config of vpc
  name_suffix       = "mkp"
  vpc_name          = format("%s-%s", local.app_id, "vpc")
  availability_zone = local.availability_zone
  vpc_cidr          = "192.168.0.0/16"
  remote_ip_cidr    = var.remote_ip_cidr
  vpc_tags          = local.tags

  # config of subnet
  subnet_name           = format("%s-%s", local.app_id, "subnet")
  vpc_subnet_cidr       = var.vpc_subnet_cidr
  vpc_subnet_gateway_ip = "192.168.10.1"
  subnet_tags           = local.tags
}

module "ecs-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = "mkp"
  secgroup_name           = format("%s-%s", local.app_id, "ecs-secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "20-9527", remote_ip_prefix = var.remote_ip_cidr, remote_group_id = null },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = "tcp", ports = "1433", remote_ip_prefix = var.vpc_subnet_cidr, remote_group_id = null },
  ]
}

// Create an ECS
module "ecs" {
  source             = "../../modules/ecs"
  images_visibility  = "public"
  name_suffix        = "mkp"
  instance_name      = format("%s-%s", local.app_id, "ecs")
  availability_zone  = local.availability_zone
  instance_image_id  = data.huaweicloud_images_image.myimage.id
  instance_flavor_id = data.huaweicloud_compute_flavors.flavors.ids[0]
  charging_mode      = local.charging_mode
  security_group_ids = module.ecs-security-group.secgroup_id
  admin_pass         = var.ecs_password
  networks_configuration = [
    {
      subnet_id         = module.vpc.subnet_id,
      fixed_ip_v4       = null,
      ipv6_enable       = false,
      source_dest_check = false,
      access_network    = false
  }]
  instance_tags = local.tags
}

// Create a bucket for storing shell scripts and shell execution state
resource "huaweicloud_obs_bucket" "bucket" {
  bucket = "mybucket-kdism9234kdas"
  acl    = "private"
  tags   = local.tags
}

// Create an object for marking shell execution state
resource "huaweicloud_obs_bucket_object" "is_initialized" {
  bucket = huaweicloud_obs_bucket.bucket.bucket
  key    = "is_initialized"
  // 0: not initialized, 1: initialized
  content = "0"
}

// Create a role for accessing OBS
resource "huaweicloud_identity_role" "fg-obs" {
  name        = "FunctionGraph OBS Operate Object"
  description = "created by terraform"
  type        = "XA"
  policy = jsonencode(
    {
      "Version" : "1.1",
      "Statement" : [
        {
          "Action" : [
            "obs:object:GetObject",
            "obs:object:PutObject"
          ],
          "Effect" : "Allow"
        }
      ]
    }
  )
}

// Create a role for accessing VPS
resource "huaweicloud_identity_role" "fg-vpc" {
  name        = "FunctionGraph VPC"
  description = "created by terraform"
  type        = "XA"
  policy = jsonencode(
    {
      "Version" : "1.1",
      "Statement" : [
        {
          "Action" : [
            "vpc:ports:*",
            "vpc:vpcs:get",
            "vpc:subnets:get"
          ],
          "Effect" : "Allow"
        }
      ]
    }
  )
}

// Create an agency for FunctionGraph
resource "huaweicloud_identity_agency" "agency" {
  name        = "agency_vpc_obs_${local.app_id}"
  description = "vpc obs"
  // FunctionGraph service name
  delegated_service_name = "op_svc_cff"

  project_role {
    project = var.region
    roles = [
      huaweicloud_identity_role.fg-vpc.name
    ]
  }

  project_role {
    project = "MOS"
    roles = [
      huaweicloud_identity_role.fg-obs.name
    ]
  }
}

// Create a FunctionGraph dependency
resource "huaweicloud_fgs_dependency" "paramiko" {
  name    = "paramiko"
  runtime = "Python3.10"
  link    = "https://public-kd8h.obs.cn-north-4.myhuaweicloud.com/paramiko.zip"
}

// Create a FunctionGraph
resource "huaweicloud_fgs_function" "ecs-init" {
  name                  = "ecs_init_${local.app_id}"
  functiongraph_version = "v2"
  app                   = "default"
  description           = "ecs init fuction"
  handler               = "index.handler"
  memory_size           = 128
  // shell execution timeout
  timeout     = 3600
  runtime     = "Python3.10"
  depend_list = [huaweicloud_fgs_dependency.paramiko.id]
  code_type   = "obs"
  // code url for logiing into an ECS instance and execute shell script via ssh implemented in Python
  code_url   = "https://public-kd8h.obs.cn-north-4.myhuaweicloud.com/ecs-init-python.zip"
  agency     = huaweicloud_identity_agency.agency.name
  vpc_id     = module.vpc.vpc_id
  network_id = module.vpc.subnet_id
  user_data = jsonencode({
    bucket_name  = huaweicloud_obs_bucket.bucket.bucket
    object_key   = local.shell
    obs_endpoint = "obs.${var.region}.myhuaweicloud.com"
    host         = module.ecs.access_ips[0]
    port         = "22"
    user         = "root"
  })
  encrypted_user_data = jsonencode({
    password = var.ecs_password
  })
}

// Create a FunctionGraph OBS trigger
resource "huaweicloud_fgs_trigger" "obs" {
  function_urn = huaweicloud_fgs_function.ecs-init.urn
  type         = "OBS"
  status       = "ACTIVE"

  obs {
    bucket_name             = huaweicloud_obs_bucket.bucket.bucket
    event_notification_name = "obs_create_${local.app_id}"
    suffix                  = local.shell
    events                  = ["ObjectCreated"]
  }
}

// Upload shell script trigger event to FunctionGraph
resource "huaweicloud_obs_bucket_object" "object" {
  bucket     = huaweicloud_obs_bucket.bucket.bucket
  key        = local.shell
  content    = file(local.shell)
  depends_on = [huaweicloud_fgs_trigger.obs]
}
