variable "performance_type" {
  type        = string
  description = "the ECS flavor type. Possible values are as follows:normal(General computing)、computingv3(General computing-plus)、highmem(Memory-optimized)、saphana(Large-memory HANA ECS)、diskintensive(Disk-intensive)"
  default = "normal"
  validation {
    condition     = contains(["normal", "computingv3", "highmem", "saphana", "diskintensive"], var.performance_type)
    error_message = "Allowed values for input_parameter are normal、computingv3、highmem、saphana、diskintensive."
  }
}

variable "instance_flavor_id" {
  description = "The ID of the ECS instance flavor"
  nullable  = false
  type    = string
  default = null
}

variable "admin_password" {
  type        = string
  description = "the admin password of ecs."
  nullable    = false
  sensitive   = true
}

variable "subnet_id" {
  type        = string
  default     = null
  nullable  = false
  description = "The Id of the subnet"
}

variable "is_eip_create" {
  type        = string
  default     = "true"
  description = "Indicates whether to create an EIP."
  validation {
    condition     = contains(["true", "false"], var.is_eip_create)
    error_message = "Indicates whether to create an EIP. The value true indicates that the EIP is created, and the value false indicates that the EIP is not created."
  }
}

variable "remote_ip_cidr" {
  type        = string
  default     = null
  nullable  = false
  description = "Specifies the remote CIDR which is allowed to access the ECS instance, the value needs to be a valid CIDR (i.e. 192.168.0.0/16).This parameter is mutually exclusive with parameters remote_group_id."
}

variable "remote_group_id" {
  type        = string
  default     = null
  nullable  = false
  description = "Specifies the remote group ID whose traffic is allowed to access the ECS instance.This parameter is mutually exclusive with parameters remote_ip_cidr."
}

variable "charging_mode" {
  type        = string
  nullable    = false
  description = " Specifies the charging mode of the disk. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode. Changing this creates a new disk."
  validation {
    condition     = contains(["postPaid", "prePaid"], var.charging_mode)
    error_message = "Allowed values for input_parameter are prePaid or postPaid."
  }
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase.Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = string
  default = "month"
  validation {
    condition     = contains(["month", "year"], var.period_unit)
    error_message = "Allowed values for input_parameter are month or year."
  }
}

variable "period" {
  description = "The period number of the pre-paid purchase. If period_unit is set to month , the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = number
  default = 1
}