//  Query the az available for the Region
data "huaweicloud_availability_zones" "az" {}

// Query flavors of all az
data "huaweicloud_compute_flavors" "flavors" {
  count = length(data.huaweicloud_availability_zones.az.names)

  availability_zone = data.huaweicloud_availability_zones.az.names[count.index]

  performance_type = var.performance_type
  cpu_core_count   = local.instance_flavor_cpu
  memory_size      = local.instance_flavor_memory
  #  generation       = local.generation
}

// Query Subnet
data "huaweicloud_vpc_subnet" "subnet" {
  id = var.subnet_id
}

# You can obtain the download address of the software package from marketplace. The code is as follows:
# data.huaweicloud_koogallery_assets.assets.assets[0].software_pkg_deployed_object[0].internal_path
# The asset_id、deployed_type and asset_version, you need modify.
data "huaweicloud_koogallery_assets" "assets" {
  asset_id      = ""
  deployed_type = "software_package"
  asset_version = "V1.0"
}

locals {
  // you need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id = format("%s-%s", "mkp-app", formatdate("hhmm", timestamp()))

  name_suffix = "mkp"

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  # Configuration of the ECS memory size and number of cores
  instance_flavor_cpu    = 2
  instance_flavor_memory = 4
  # for more details, please refer to https://support.huaweicloud.com/api-ecs/ecs_02_0101.html#ecs_02_0101__table53188122
  ecs_volume_type = "GPSSD"

  # Specifies the generation of an ECS type. For example, s3 indicates the general-purpose third-generation ECSs. For details, see https://support.huaweicloud.com/productdesc-ecs/zh-cn_topic_0159822360.html.
  # If you have no special requirements on ECS specifications, you can delete this parameter.
  #  generation = "s3"

  # az and available flavors map, such as {cn-north-4a = ["ac7.large.2", "c3ne.large.2"]}
  available_flavors_id_maps = { for i, flavor_ids in data.huaweicloud_compute_flavors.flavors[*].ids : data.huaweicloud_availability_zones.az.names[i] => flavor_ids if length(flavor_ids) > 0 }
  # az and available flavors map, such as {ac7.large.2 = ["cn-north-4a", "cn-north-4b"]}
  flavors2az_maps = transpose(local.available_flavors_id_maps)
  # Only flavors that exist in two or more AZs are reserved.
  available_flavors_map = { for flavor_id, azs in local.flavors2az_maps : flavor_id => azs if length(azs) >= 2 }
  # Obtains an available flavor.
  available_flavor = keys(local.available_flavors_map)[0]
  # Obtain the AZs of the master and slave nodes.
  availability_zone = local.available_flavors_map[local.available_flavor][0]

  # the software url of marketplace
  software_url        = data.huaweicloud_koogallery_assets.assets.assets[0].software_pkg_deployed_object[0].internal_path
  software_url_decode = jsondecode("\"${local.software_url}\"")

  // Billing model for cloud resources, You need to modify it according to your actual situation.
  // In the development and testing phase, pay-per-use billing is recommended.
  // You can also set these three parameters as variables, allowing users to select at deployment time.
  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  // The billing model for bandwidth, You need to modify it according to your actual situation.
  publicip_type         = "5_bgp"
  bandwidth_share_type  = "PER"
  bandwidth_charge_mode = "traffic"
  bandwidth_size        = 1

  # Image information in different regions, you need to enter your own image ID or add another region.
  # For Marketplace Image Id,you can log in to Seller Console, view the marketplace image id on Product Specifications section of My Products detail page.
  instance_image_id_maps = {
    cn-north-4     = "e7c716d5-3002-44bd-8cd5-6bd16eae33b1"
    cn-south-1     = ""
    cn-east-3      = ""
    cn-north-9     = ""
    cn-southwest-2 = ""
  }
}

# Create security group
module "security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "443,22", remote_ip_prefix = var.remote_ip_cidr, remote_group_id = var.remote_group_id },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null }
  ]
}

# Create route, If you don't need, you can delete it.
module "vpc_route" {
  source = "../../modules/vpc_route"

  // You need to modify it according to your actual situation.
  vpc_routes_configuration = [
    { vpc_id = data.huaweicloud_vpc_subnet.subnet.vpc_id, destination = "172.16.0.0/12", type = "ecs", nexthop = module.ecs.ecs_ids[0], description = "", route_table_id = null }
  ]
}

// Create an ECS
module "ecs" {
  source = "../../modules/ecs"

  is_instance_create = true
  # The total number of The ECS instance
  instance_count = 1

  # You need to change the image ID to your own.
  instance_image_id = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]
  # If you use Public Image，you can use instance_image_name, such as instance_image_name = "CentOS 7.9 64bit"
  #  instance_image_name = "CentOS 7.9 64bit"

  # If no AZ is specified, the first AZ of the current region is used by default.
  availability_zone = local.availability_zone

  # You need to change the performance type、cpu and memory of the ECS based on the your requirements.
  instance_flavor_performance = var.performance_type
  instance_flavor_cpu         = local.instance_flavor_cpu
  instance_flavor_memory      = local.instance_flavor_memory

  # The priority of instance_flavor_id is higher than that of instance_flavor_cpu and instance_flavor_cpu.
  instance_flavor_id = var.instance_flavor_id != null ? var.instance_flavor_id : local.available_flavor

  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs")

  security_group_ids = module.security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = local.ecs_volume_type
  system_disk_size = 40

  eip_id = module.eip.id != null && length(module.eip.id) > 0 ? module.eip.id[0] : null

  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = var.subnet_id, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = true, access_network = false },
    { subnet_id = "", fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = true, access_network = false }
  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  admin_pass = var.admin_password

  instance_tags = local.tags

  # Script executed by default after the ECS is created.You need to modify it according to your actual situation.
  # For more information about user_data, visit https://support.huaweicloud.com/usermanual-ecs/zh-cn_topic_0032380449.html.
  user_data = <<-EOF
  #!/bin/bash
  echo 'root:${var.admin_password}' | chpasswd
  wget -O /usr/local/FileBrower.zip "${local.software_url_decode}"
  unzip /usr/local/FileBrower.zip -d /usr/local/
  chmod u+x /usr/local/install.sh
  nohup bash /usr/local/install.sh >/dev/null 2>&1
  EOF
}

// Create an EIP, if you do not need to create an EIP, delete the code and modules/eip directory
module "eip" {
  source = "../../modules/eip"

  is_eip_create = var.is_eip_create

  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip")

  publicip_type         = local.publicip_type
  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = local.bandwidth_share_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = local.bandwidth_size

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags
}

//  To create a data disk for ECS, if you do not need to bind the data disk, delete the code and modules/evs directory
module "evs" {
  source = "../../modules/evs"

  is_volume_create = true
  # The total number of The EVS instance
  volume_count = 1

  availability_zone = local.availability_zone

  name_suffix = local.name_suffix
  volume_name = format("%s-%s", local.app_id, "evs")

  # Default size and type of the system disk, You need to modify it according to your actual situation.
  volume_type = local.ecs_volume_type
  volume_size = 40

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  attached_configuration = [
    { instance_id = module.ecs.ecs_ids[0] }
  ]

  volume_tags = local.tags
}
