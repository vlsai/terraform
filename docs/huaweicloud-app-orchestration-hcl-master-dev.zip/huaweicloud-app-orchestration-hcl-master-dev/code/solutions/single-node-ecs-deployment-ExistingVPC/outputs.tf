output "subnet_vpc_id" {
  value = data.huaweicloud_vpc_subnet.subnet
}