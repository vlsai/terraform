output "db_infos" {
  value = data.huaweicloud_rds_flavors.flavors
}