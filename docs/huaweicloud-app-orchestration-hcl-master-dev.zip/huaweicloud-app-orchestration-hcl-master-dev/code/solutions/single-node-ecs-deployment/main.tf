//  Query the az available for the Region
data "huaweicloud_availability_zones" "az" {}

//  Query available RDS for flavor,for more details please refer to https://registry.terraform.io/providers/huaweicloud/huaweicloud/latest/docs/data-sources/rds_flavors.
data "huaweicloud_rds_flavors" "flavors" {
  db_type       = local.db_type
  db_version    = local.db_version
  instance_mode = local.db_instance_mode
  vcpus         = local.db_vcpus
  memory        = local.db_memory
  group_type    = local.db_group_type
}

// Query flavors of all az
data "huaweicloud_compute_flavors" "flavors" {
  count = length(data.huaweicloud_availability_zones.az.names)

  availability_zone = data.huaweicloud_availability_zones.az.names[count.index]

  performance_type = var.performance_type
  cpu_core_count   = local.instance_flavor_cpu
  memory_size      = local.instance_flavor_memory
}

# You can obtain the download address of the software package from marketplace. The code is as follows:
# data.huaweicloud_koogallery_assets.assets.assets[0].software_pkg_deployed_object[0].internal_path
# The asset_id、deployed_type and asset_version, you need modify.
data "huaweicloud_koogallery_assets" "assets" {
  asset_id      = ""
  deployed_type = "software_package"
  asset_version = "V1.0"
}

locals {
  // you need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id      = format("%s-%s", "mkp-app", formatdate("hhmm", timestamp()))
  name_suffix = "mkp"

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  # the software url of marketplace
  software_url        = data.huaweicloud_koogallery_assets.assets.assets[0].software_pkg_deployed_object[0].internal_path
  software_url_decode = jsondecode("\"${local.software_url}\"")

  # Configuration of the ECS memory size and number of cores
  instance_flavor_cpu    = 2
  instance_flavor_memory = 4
  # for more details, please refer to https://support.huaweicloud.com/api-ecs/ecs_02_0101.html#ecs_02_0101__table53188122
  ecs_volume_type = "GPSSD"

  # Specifies the generation of an ECS type. For example, s3 indicates the general-purpose third-generation ECSs. For details, see https://support.huaweicloud.com/productdesc-ecs/zh-cn_topic_0159822360.html.
  # If you have no special requirements on ECS specifications, you can delete this parameter.
  #  generation = "s3"

  # az and available flavors map, such as {cn-north-4a = ["ac7.large.2", "c3ne.large.2"]}
  available_flavors_id_maps = { for i, flavor_ids in data.huaweicloud_compute_flavors.flavors[*].ids : data.huaweicloud_availability_zones.az.names[i] => flavor_ids if length(flavor_ids) > 0 }
  # az and available flavors map, such as {ac7.large.2 = ["cn-north-4a", "cn-north-4b"]}
  flavors2az_maps = transpose(local.available_flavors_id_maps)
  # Only flavors that exist in two or more AZs are reserved.
  available_flavors_map = { for flavor_id, azs in local.flavors2az_maps : flavor_id => azs if length(azs) >= 2 }
  # Obtains an available flavor.
  available_flavor = keys(local.available_flavors_map)[0]
  # Obtain the AZs of the master and slave nodes.
  availability_zone = local.available_flavors_map[local.available_flavor][0]

  //  Billing model for cloud resources
  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  // The billing model for bandwidth
  publicip_type         = "5_bgp"
  bandwidth_share_type  = "PER"
  bandwidth_charge_mode = "bandwidth"
  bandwidth_size        = 1

  // RDS Config
  db_port          = 1433
  db_type          = "SQLServer"
  db_version       = "2016_SE"
  db_instance_mode = "single"
  db_vcpus         = 2
  db_memory        = 4
  db_group_type    = "general" // for more details, please refer to https://support.huaweicloud.com/api-rds/rds_06_0002.html

  # Image information in different regions, you need to enter your own image ID or add another region.
  # For Marketplace Image Id,you can log in to Seller Console, view the marketplace image id on Product Specifications section of My Products detail page.
  # Windows Server 2016数据中心板
  instance_image_id_maps = {
    cn-north-4     = "2a760cf5-8ae6-4b5a-a1d4-da4df55da961"
    cn-south-1     = "c1716093-3757-4d0e-bdc4-a3a6fc4fc1a3"
    cn-east-3      = "5fd35ec8-0a1e-43a9-9ec1-6052aae973ed"
    cn-north-9     = "016b50eb-ccb0-48c9-833f-1fbbc9de25cf"
    cn-southwest-2 = "3d22c3a6-7b01-4332-9cef-324746069e88"
  }

  # Specifies the DNS server address list of a subnet. For details about the private DNS address, see https://support.huaweicloud.com/dns_faq/dns_faq_002.html#?
  subnet_dns_list_maps = {
    cn-north-4     = ["100.125.1.250", "100.125.129.250"]
    cn-south-1     = ["100.125.1.250", "100.125.136.29"]
    cn-east-3      = ["100.125.1.250", "100.125.64.250"]
    cn-north-9     = ["100.125.1.250", "100.125.107.250"]
    cn-southwest-2 = ["100.125.1.250", "100.125.129.250"]
  }
}

// Create a VPC
module "vpc" {
  source = "../../modules/vpc"

  # config of vpc
  name_suffix       = local.name_suffix
  vpc_name          = format("%s-%s", local.app_id, "vpc")
  availability_zone = local.availability_zone
  vpc_cidr          = "192.168.0.0/16"
  remote_ip_cidr    = var.remote_ip_cidr
  vpc_tags          = local.tags

  # config of subnet
  subnet_name           = format("%s-%s", local.app_id, "subnet")
  vpc_subnet_dns_list   = local.subnet_dns_list_maps[data.huaweicloud_availability_zones.az.region]
  vpc_subnet_cidr       = var.vpc_subnet_cidr
  vpc_subnet_gateway_ip = "192.168.10.1"
  subnet_tags           = local.tags
}

module "ecs-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "ecs-secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "20-9527", remote_ip_prefix = var.remote_ip_cidr, remote_group_id = null },
    # By default, the outbound direction is not restricted.
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null },
  ]
}

module "rds-security-group" {
  source = "../../modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "rds-secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "1433", remote_ip_prefix = var.vpc_subnet_cidr, remote_group_id = null }
  ]
}

// To create an RDS, if you do not need to create an RDS, delete the code and the modules/rds directory
module "rds" {
  source = "../../modules/rds_sqlserver"

  is_rds_create = true

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  name_suffix          = local.name_suffix
  db_instance_name     = format("%s-%s", local.app_id, "rds")
  db_availability_zone = [data.huaweicloud_rds_flavors.flavors.flavors[0].availability_zones[0]]
  time_zone            = "UTC"

  vpc_id            = module.vpc.vpc_id
  subnet_id         = module.vpc.subnet_id
  security_group_id = module.rds-security-group.secgroup_id[0]

  flavor = data.huaweicloud_rds_flavors.flavors.flavors[0].name

  param_group_id = ""

  replication_mode = null

  # db config
  db_version  = local.db_version
  db_password = var.db_password
  db_port     = local.db_port

  account_name  = var.account_name
  account_pwd   = var.account_pwd
  database_name = var.database_name

  lower_case_table_names = "1"
  collation              = "Chinese_PRC_CI_AS"

  # backup_strategy
  keep_days  = 100
  start_time = "01:00-02:00"

  # volume config
  db_instance_storage_type = "CLOUDSSD"
  db_allocated_storage     = var.db_allocated_storage
  disk_encryption_id       = ""

  rds_tags = local.tags
}

# Bind an EIP to RDS. If you do not need it, delete the code.
module "rds_eip" {
  source = "../../modules/eip"

  is_eip_create = true

  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "rds_eip")

  publicip_type         = local.publicip_type
  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = local.bandwidth_share_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = local.bandwidth_size

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  associated_configuration = [
    { fixed_ip = module.rds.rds_ip[0], network_id = module.vpc.subnet_id, port_id = null }
  ]

  eip_tags = local.tags
}

// Create an ECS
module "ecs" {
  source = "../../modules/ecs"

  is_instance_create = true

  # The total number of The ECS instance
  instance_count = 1

  instance_image_id = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]

  # If no AZ is specified, the first AZ of the current region is used by default.
  availability_zone = local.availability_zone

  # You need to change the performance type、cpu and memory of the ECS based on the your requirements.
  instance_flavor_performance = var.performance_type
  instance_flavor_cpu         = local.instance_flavor_cpu
  instance_flavor_memory      = local.instance_flavor_memory
  instance_flavor_id          = local.available_flavor

  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs")

  security_group_ids = module.ecs-security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = local.ecs_volume_type
  system_disk_size = 40

  eip_id = module.eip.id[0]

  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = module.vpc.subnet_id, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = false, access_network = false }
  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  instance_tags = local.tags

  admin_pass = var.admin_password
  # Script executed by default after the ECS is created.You need to modify it according to your actual situation.
  # For more information about user_data, visit https://support.huaweicloud.com/usermanual-ecs/zh-cn_topic_0032380449.html.
  user_data = <<-EOF
  <powershell>
  #ps1
  $contentToAdd = @'
  #ps1
  echo "${local.software_url_decode}"
  bash install.sh ${module.rds.rds_ip}
  # Note: Double quotation marks are required here.
  $url = "${local.software_url_decode}"
  $outputPath = "C:\test.zip"
  Invoke-WebRequest -Uri $url -OutFile $outputPath
  $extractPath = "C:\test"
  Expand-Archive -Path $outputPath -DestinationPath $extractPath
  '@
  Add-Content "C:\run.ps1" $contentToAdd
  </powershell>
  EOF
}

// Create an EIP, if you do not need to create an EIP, delete the code and modules/eip directory
module "eip" {
  source = "../../modules/eip"

  is_eip_create = true

  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip")

  publicip_type         = local.publicip_type
  bandwidth_name        = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type  = local.bandwidth_share_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size        = local.bandwidth_size

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags
}

//  To create a data disk for ECS, if you do not need to bind the data disk, delete the code and modules/evs directory
module "evs" {
  source = "../../modules/evs"

  is_volume_create = true
  # The total number of The EVS instance
  volume_count = 1

  availability_zone = local.availability_zone

  name_suffix = local.name_suffix
  volume_name = format("%s-%s", local.app_id, "evs")

  volume_type = local.ecs_volume_type
  volume_size = 40

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  attached_configuration = [
    { instance_id = module.ecs.ecs_ids[0] }
  ]

  volume_tags = local.tags
}
