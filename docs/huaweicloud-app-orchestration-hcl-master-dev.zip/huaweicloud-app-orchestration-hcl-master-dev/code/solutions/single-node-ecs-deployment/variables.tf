variable "performance_type" {
  type        = string
  description = "the ECS flavor type. Possible values are as follows:normal(General computing)、computingv3(General computing-plus)、highmem(Memory-optimized)、saphana(Large-memory HANA ECS)、diskintensive(Disk-intensive)"
  default = "normal"
  validation {
    condition     = contains(["normal", "computingv3", "highmem", "saphana", "diskintensive"], var.performance_type)
    error_message = "Allowed values for input_parameter are normal、computingv3、highmem、saphana、diskintensive."
  }
}

variable "is_rds_create" {
  type        = string
  default     = "true"
  description = "Indicates whether to create an EIP."
  validation {
    condition     = contains(["true", "false"], var.is_rds_create)
    error_message = "Indicates whether to create an EIP. The value true indicates that the EIP is created, and the value false indicates that the EIP is not created."
  }
}

variable "admin_password" {
  type        = string
  description = "the admin password of ecs."
  nullable = false
  sensitive   = true
}

variable "remote_ip_cidr" {
  type        = string
  description = " Specifies the remote CIDR, the value needs to be a valid CIDR (i.e. 192.168.0.0/16). Changing this creates a new security group rule."
  nullable  = false
}

variable "vpc_subnet_cidr" {
  type        = string
  default     = "192.168.10.0/24"
  description = "Specifies the network segment on which the subnet resides. The value must be in CIDR format and within the CIDR block of the VPC. The subnet mask cannot be greater than 28. Changing this creates a new Subnet."
}

variable "db_allocated_storage" {
  type        = number
  default     = 40
  description = "the size of database, in GB."
}

variable "db_password" {
  type        = string
  sensitive   = true
  nullable  = false
  description = "database password."
}

variable "account_name" {
  type = string
  nullable  = false
  description = "Specifies the username of the DB account. The username consists of 1 to 128 characters and must be different from system usernames. System users include rdsadmin, rdsuser, rdsbackup, and rdsmirror."
}

variable "account_pwd" {
  type = string
  sensitive   = true
  nullable  = false
  description = "Specifies the password of the DB account.It consists of 8 to 128 characters and contains at least three types of the following characters: uppercase letters, lowercase letters, digits, and special characters. "
}

variable "database_name" {
  type = string
  nullable  = false
  description = "Create a database"
}

variable "charging_mode" {
  type        = string
  nullable    = false
  default = "postPaid"
  description = " Specifies the charging mode of the disk. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode. Changing this creates a new disk."
  validation {
    condition     = contains(["postPaid", "prePaid"], var.charging_mode)
    error_message = "Allowed values for input_parameter are prePaid or postPaid."
  }
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase.Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = string
  default = "month"
  validation {
    condition     = contains(["month", "year"], var.period_unit)
    error_message = "Allowed values for input_parameter are month or year."
  }
}

variable "period" {
  description = "The period number of the pre-paid purchase. If period_unit is set to month , the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = number
  default = 1
}