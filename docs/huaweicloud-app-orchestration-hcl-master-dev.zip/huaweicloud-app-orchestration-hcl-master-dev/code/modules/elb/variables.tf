variable "charging_mode" {
  description = "Specifies the charging mode of the elastic IP. Valid values are prePaid and postPaid. The valid values are as follows:prePaid: the year/month billing mode,postPaid: the pay-per-use billing mode."

  type    = string
  default = null
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "is_auto_renew" {
  description = "Specifies whether auto renew is enabled. Valid values are true and false. Defaults to false."

  type    = bool
  default = false
}

variable "loadbalancer_name" {
  type = string
  default = null
}
variable "ipv4_eip_ip" {
  type = string
  default = null
}
variable "ipv4_subnet_id" {
  type = string
  default = null
}

variable "listener_name" {
  type = string
  default = null
}

variable "protocol_port" {
  type = string
  default = null
}

variable "member_protocol_port" {
  type = string
  default = null
}

variable "pool_name" {
  type = string
  default = null
}

variable "lb_method" {
  type = string
  default = null
  description = "ROUND_ROBIN、LEAST_CONNECTIONS、SOURCE_IP"
}

variable "monitor_type" {
  type = string
  default = null
  description = "TCP、UDP、HTTP、HTTPS"
}

variable "monitor_delay" {
  type    = number
  default = null
  description = "1-50"
}

variable "monitor_timeout" {
  type    = number
  default = null
  description = "1-50"
}

variable "monitor_max_retries" {
  type    = number
  default = null
  description = "1-10"
}

variable "listener_protocol" {
  type = string
  description = "TCP、HTTP、UDP、TERMINATED_HTTPS"
  default = null
}

variable "pool_protocol" {
  type = string
  description = "TCP、UDP、HTTP"
  default = null
}

variable "url_path" {
  type = string
  default = null
}

variable "member_configuration" {
  description = "The configuration for member resources to which the elb belongs"
  type = list(object({
    address = string
    weight  = number
  }))
  default = []
}

variable "name_suffix" {
  description = "The suffix string of name for all elb resources"
  
  type    = string
  default = ""
}

variable "loadbalancer_tags" {
  description = "The tags configuration of the ECS instance"
  
  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "listener_tags" {
  description = "The tags configuration of the ELB Listener"
  
  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "is_elb_creat" {
  type = bool
  default = true
}