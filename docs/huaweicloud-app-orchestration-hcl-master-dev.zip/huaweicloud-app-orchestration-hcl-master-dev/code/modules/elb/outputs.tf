output "loadbalancer_vip_port_id" {
  value = huaweicloud_lb_loadbalancer.loadbalancer[0].vip_port_id
}
