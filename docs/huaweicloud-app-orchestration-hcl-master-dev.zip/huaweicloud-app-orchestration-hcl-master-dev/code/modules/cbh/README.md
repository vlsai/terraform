# The Terraform module of HUAWEI Cloud ECS Service

## Usage

### Create an CBH instance

```
module "cbh" {
  source = "modules/cbh"

  cbh_type     = "basic"
  asset_number = 10

  name_suffix           = "mkp"
  cbh_name              = format("%s-%s", "mkp", "cbh")
  vpc_id                = ""
  subnet_id             = ""
  security_group_id     = ""
  availability_zone     = ""
  cbh_password          = ""
  charging_mode         = "prePaid"
  period_unit           = "month"
  period                = 1
  enterprise_project_id = "xxx"
}

```