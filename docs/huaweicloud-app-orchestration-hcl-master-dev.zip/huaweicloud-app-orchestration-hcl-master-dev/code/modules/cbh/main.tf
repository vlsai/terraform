data "huaweicloud_cbh_flavors" "cbh_flavors" {
  type  = var.cbh_type
  asset = var.asset_number
}

resource "huaweicloud_cbh_instance" "cbh" {
  count             = var.is_instance_create ? (var.instance_count > 0 ? var.instance_count : 1) : 0
  flavor_id         = var.flavor_id != null ? var.flavor_id : data.huaweicloud_cbh_flavors.cbh_flavors.flavors[0].id
  name              = var.name_suffix != null ? format("%s-%s", var.cbh_name, var.name_suffix) : var.cbh_name
  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id
  availability_zone = var.availability_zone
  public_ip_id      = var.public_ip_id
  password          = var.cbh_password
  charging_mode     = var.charging_mode
  period_unit       = var.period_unit
  period            = var.period
}