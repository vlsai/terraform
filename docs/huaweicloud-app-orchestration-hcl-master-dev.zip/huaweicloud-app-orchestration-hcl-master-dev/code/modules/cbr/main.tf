resource "huaweicloud_cbr_vault" "cbr" {
  name                  = var.name_suffix != null ? format("%s-%s", var.vault_name, var.name_suffix) : var.vault_name
  type                  = var.type
  protection_type       = var.protection_type
  consistent_level      = var.consistent_level
  size                  = var.size
  is_multi_az           = var.is_multi_az
  backup_name_prefix    = var.backup_name_prefix
  enterprise_project_id = var.enterprise_project_id
  tags                  = var.vault_tags

  dynamic "resources" {
    for_each = var.resources

    content {
      server_id = resources.value["server_id"]
      excludes  = resources.value["excludes"]
      includes  = resources.value["includes"]
    }
  }

  policy {
    id = huaweicloud_cbr_policy.cbr_policy.id
  }

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.is_auto_renew
}

resource "huaweicloud_cbr_policy" "cbr_policy" {
  name        = var.name_suffix != null ? format("%s-%s", var.policy_name, var.name_suffix) : var.policy_name
  type        = var.policy_type
  time_period = var.time_period

  enabled = var.enabled

  backup_cycle {
    interval        = var.backup_interval
    execution_times = var.execution_times
  }
}