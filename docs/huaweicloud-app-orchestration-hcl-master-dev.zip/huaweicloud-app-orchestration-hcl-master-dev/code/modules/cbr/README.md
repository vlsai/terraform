# The Terraform module of HUAWEI Cloud CBR Service

## Usage

### Create an CBR Vault and Policy 

```
module "cbr" {
  source                = "modules/cbr"
  vault_name            = "cbr_vault"
  name_suffix           = ""
  type                  = "server"
  protection_type       = "backup"
  consistent_level      = "crash_consistent"
  size                  = 1000
  is_multi_az           = false
  backup_name_prefix    = ""
  enterprise_project_id = ""
  charging_mode         = "postPaid"

  policy_name     = "cbr_policy"
  policy_type     = "backup"
  time_period     = 365
  enabled         = true
  backup_interval = 3
  execution_times = ["02:00"]
}

```