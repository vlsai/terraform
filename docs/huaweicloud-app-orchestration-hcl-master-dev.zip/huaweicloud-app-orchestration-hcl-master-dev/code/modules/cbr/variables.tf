variable "vault_name" {
  description = "Specifies a unique name of the CBR vault. This parameter can contain a maximum of 64 characters, which may consist of letters, digits, underscores(_) and hyphens (-)."

  type    = string
  default = null
}

variable "name_suffix" {
  description = "The suffix string of name for all CBR resources"

  type    = string
  default = "mkp"
}

variable "type" {
  description = "Specifies the object type of the CBR vault. Changing this will create a new vault. Valid values are as follows:server (Elastic Cloud Server), disk (EVS Disk), turbo (SFS Turbo file system), workspace (Workspace Desktop), vmware (VMware), file (File System)"

  type    = string
  default = null
}

variable "protection_type" {
  description = "Specifies the protection type of the CBR vault. The valid values are backup and replication. Vaults of type disk don't support replication. Changing this will create a new vault."

  type    = string
  default = null
}

variable "size" {
  description = "Specifies the vault capacity, in GB. The valid value range is 1 to 10,485,760."

  type    = number
  default = 100
}

variable "consistent_level" {
  description = "Specifies the consistent level (specification) of the vault. The valid values are as follows:crash_consistent and app_consistent, Only server type vaults support application consistent and defaults to crash_consistent, and only crash_consistent can be updated to app_consistent. The workspace type vaults does not support application consistent."

  type    = string
  default = "crash_consistent"
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the CBH instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}

variable "backup_name_prefix" {
  description = "Specifies the backup name prefix. Changing this will create a new vault."

  type = string
  default = ""
}

variable "is_multi_az" {
  description = "Specifies whether multiple availability zones are used for backing up. Defaults to false."

  type = bool
  default = false
}

variable "vault_tags" {
  description = "Specifies the key/value pairs to associate with the CBR vault"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "resources" {
  description = "Specifies an array of one or more resources to attach to the CBR vault.This feature is not supported for the vmware type and the file type."
  type = list(object({
    server_id = string
    excludes = list(string)
    includes = list(string)
  }))
  default = []
}

variable "charging_mode" {
  description = "Specifies the charging mode of the elastic IP. Valid values are prePaid and postPaid. The valid values are as follows:prePaid: the year/month billing mode,postPaid: the pay-per-use billing mode."

  type    = string
  default = null
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "is_auto_renew" {
  description = "Specifies whether auto renew is enabled. Valid values are true and false. Defaults to false."

  type    = bool
  default = false
}

variable "policy_name" {
  description = "Specifies the policy name.This parameter can contain a maximum of 64 characters, which may consist of chinese characters, letters, digits, underscores(_) and hyphens (-)."

  type = string
  default = null
}

variable "policy_type" {
  description = "Specifies the protection type of the policy. Valid values are backup and replication. Changing this will create a new policy"

  type = string
  default = null
}

variable "enabled" {
  description = "Specifies whether to enable the policy. Default to true"

  type = bool
  default = true
}

variable "time_period" {
  description = "Specifies the duration (in days) for retained backups. The value ranges from 2 to 99,999."

  type =  number
  default = 100
}

variable "backup_interval" {
  description = "Specifies the interval (in days) of backup schedule. The value range is 1 to 30. This parameter and days are alternative."

  type = number
  default = 1
}

variable "execution_times" {
  description = "Specifies the backup time. Automated backups will be triggered at the backup time. The current time is in the UTC format (HH:MM). The minutes in the list must be set to 00 and the hours cannot be repeated. In the replication policy, you are advised to set one time point for one day."

  type = list(string)
  default = ["02:00"]
}
