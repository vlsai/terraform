output "db_user_name" {
  value = huaweicloud_gaussdb_mysql_instance.gaussdb_mysql.db_user_name
}

output "private_dns_name" {
  value = huaweicloud_gaussdb_mysql_instance.gaussdb_mysql.private_dns_name
}
