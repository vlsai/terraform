# The Terraform module of HUAWEI Cloud GaussDB for Mysql Service

## Usage

### Create an GaussDB for Mysql 

```
module "gaussdb_mysql" {
  source = "modules/gaussdb_mysql"

  name              = "gaussdb_mysql"
  flavor            = "gaussdb.mysql.large.x86.normal.4"
  db_password       = "xxx"
  vpc_id            = "xxx"
  subnet_id         = "xxx"
  security_group_id = "xxx"

  port          = 3306
  ssl_option    = true
  charging_mode = "postPaid"
}
```