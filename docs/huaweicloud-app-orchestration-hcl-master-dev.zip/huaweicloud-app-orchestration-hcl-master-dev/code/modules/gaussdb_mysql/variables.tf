variable "name_suffix" {
  description = "The suffix string of name for all GaussDB for mysql resources"

  type    = string
  default = "mkp"
}

variable "name" {
  type        = string
  default     = null
  description = "Specifies the instance name, which can be the same as an existing instance name. The value must be 4 to 64 characters in length and start with a letter. It is case-sensitive and can contain only letters, digits, hyphens (-), and underscores (_)."
}

variable "description" {
  type = string
  default = null
  description = "Specifies the description of the instance."
}

variable "flavor" {
  type        = string
  default     = null
  description = "Specifies the instance specifications"
}

variable "db_password" {
  type        = string
  description = "the admin password of gauss for mysql."
  nullable    = false
  sensitive   = true
  validation {
    condition = (
    length(var.db_password) >= 8 && length(var.db_password) <= 32 &&
    length(regexall(".*[a-zA-Z].*", var.db_password)) > 0 &&
    length(regexall(".*[0-9].*", var.db_password)) > 0 &&
    length(regexall(".*[\\|\\.~!@#\\$%\\^\\*-_=\\+\\?,\\(\\)&].*", var.db_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(|.~!@#$%^*-_=+?,()&)中的三种！"
  }
}

variable "vpc_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a VPC."
}

variable "subnet_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a subnet."
}

variable "security_group_id" {
  type        = string
  default     = null
  description = "Specifies the security group ID. Required if the selected subnet doesn't enable network ACL"
}

variable "dedicated_resource_id" {
  type = string
  default = null
  description = "Specifies the dedicated resource ID."
}

variable "dedicated_resource_name" {
  type = string
  default = null
  description = "Specifies the dedicated resource name."
}

variable "port" {
  type = number
  default = 3306
  description = "Specifies the database port."
}

variable "ssl_option" {
  type = bool
  default = true
  description = "Specifies whether to enable SSL."
}

variable "private_write_ip" {
  type = string
  default = null
  description = "Specifies the private IP address of the DB instance."
}

variable "configuration_id" {
  type = string
  default = null
  description = "Specifies the configuration ID"
}

variable "private_dns_name_prefix" {
  type = string
  default = null
  description = "Specifies the prefix of the private domain name. The value contains 8 to 63 characters. Only uppercase letters, lowercase letters, and digits are allowed"
}

variable "maintain_begin" {
  type = string
  default = "22:00"
  description = "Specifies the start time for a maintenance window"
}

variable "maintain_end" {
  type = string
  default = "01:00"
  description = "Specifies the end time for a maintenance window, "
}

variable "seconds_level_monitoring_enabled" {
  type = bool
  default = true
  description = "Specifies whether to enable seconds level monitoring."
}

variable "seconds_level_monitoring_period" {
  type = number
  default = 5
  description = " Specifies the seconds level collection period.This parameter is valid only when seconds_level_monitoring_enabled is set to true.This parameter can not be specified when seconds_level_monitoring_enabled is set to false."
}

variable "enterprise_project_id" {
  type        = string
  default     = "0"
  description = "Specifies the enterprise project id"
}

variable "table_name_case_sensitivity" {
  type = bool
  default = false
  description = "Whether the kernel table name is case sensitive. The value can be true (case sensitive) and false (case insensitive). Defaults to false"
}

variable "read_replicas" {
  type = number
  default = 1
  description = "Specifies the count of read replicas."
}

variable "time_zone" {
  type = string
  default = "UTC+08:00"
  description = "Specifies the time zone. Defaults to \"UTC+08:00\"."
}

variable "availability_zone_mode" {
  type = string
  default = "multi"
  description = "Specifies the availability zone mode: \"single\" or \"multi\". Defaults to \"multi\"."
}

variable "master_availability_zone" {
  type = string
  default = null
  description = "Specifies the availability zone where the master node resides. The parameter is required in multi availability zone mode."
}

variable "charging_mode" {
  type        = string
  default     = "postPaid"
  description = "Specifies the charging mode of the instance. Valid values are prePaid and postPaid, defaults to postPaid. "
}

variable "period_unit" {
  type    = string
  default = "month"
  description = "Specifies the charging period unit of the instance. Valid values are month and year."
}

variable "period" {
  type    = number
  default = 1
  description = "Specifies the charging period of the instance.If period_unit is set to month , the value ranges from 1 to 9.If period_unit is set to year, the value ranges from 1 to 3"
}

variable "auto_renew" {
  type = bool
  default = false
  description = "Specifies whether auto renew is enabled."
}

variable "datastore_engine" {
  type = string
  default = "gaussdb-mysql"
  description = "Specifies the database engine. Only \"gaussdb-mysql\" is supported now."
}

variable "datastore_version" {
  type = string
  default = "8.0"
  description = " Specifies the database version. Only \"8.0\" is supported now."
}

variable "bak_start_time" {
  type = string
  default = "01:00-02:00"
  description = "Specifies the backup time window. Automated backups will be triggered during the backup time window."
}

variable "bak_keep_days" {
  type = number
  default = 30
  description = "Specifies the number of days to retain the generated backup files.The value ranges from 0 to 35"
}

variable "audit_log_enabled" {
  type = bool
  default = false
  description = "Specifies whether audit log is enabled."
}

variable "sql_filter_enabled" {
  type = bool
  default = false
  description = "Specifies whether sql filter is enabled."
}

variable "encryption_status" {
  type = string
  default = "OFF"
  description = "Specifies whether to enable or disable encrypted backup.Value options: ON: enabled, OFF: disabled"
}

variable "encryption_type" {
  type = string
  default = "kms"
  description = "specifies the encryption type. Currently, only kms (case-insensitive) is supported. It is mandatory when encryption_status is set to ON."
}

variable "kms_key_id" {
  type = string
  default = null
  description = "Specifies the KMS ID. It is mandatory when encryption_status is set to ON."
}

variable "parameter_configuration" {
  description = "Specify an array of one or more parameters to be set to the RDS instance after launched. You can check on console to see which parameters supported."
  type = list(object({
    parameter_name         = string
    parameter_value       = string
  }))
  default = []
}

variable "tags" {
  description = "The tags configuration of the GaussDB for mysql instance"
  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "volume_size" {
  type        = number
  default     = null
  description = " Specifies the volume size of the instance"
}
