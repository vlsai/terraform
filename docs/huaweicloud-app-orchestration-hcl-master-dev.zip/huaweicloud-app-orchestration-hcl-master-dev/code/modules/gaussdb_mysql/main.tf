data "huaweicloud_gaussdb_mysql_flavors" "flavors" {
  engine = var.datastore_engine
  version = var.datastore_version
  availability_zone_mode = var.availability_zone_mode
}

locals {
  flavors_az_maps = { for i, flavor_ids in data.huaweicloud_gaussdb_mysql_flavors.flavors.flavors[*] : data.huaweicloud_gaussdb_mysql_flavors.flavors.flavors[i].name => data.huaweicloud_gaussdb_mysql_flavors.flavors.flavors[i].az_status }
  az_map = local.flavors_az_maps[var.flavor]
  azs = [for k, v in local.az_map : k if v == "normal"]
}

resource "huaweicloud_gaussdb_mysql_instance" "gaussdb_mysql" {
  name        = var.name_suffix != null ? format("%s-%s", var.name, var.name_suffix) : var.name
  description = var.description
  flavor      = var.flavor
  password    = var.db_password

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id

  dedicated_resource_id   = var.dedicated_resource_id
  dedicated_resource_name = var.dedicated_resource_name

  port       = var.port
  ssl_option = var.ssl_option

  private_write_ip        = var.private_write_ip
  private_dns_name_prefix = var.private_dns_name_prefix

  configuration_id = var.configuration_id

  maintain_begin = var.maintain_begin
  maintain_end   = var.maintain_end

  seconds_level_monitoring_enabled = var.seconds_level_monitoring_enabled
  seconds_level_monitoring_period  = var.seconds_level_monitoring_period

  enterprise_project_id       = var.enterprise_project_id

  table_name_case_sensitivity = var.table_name_case_sensitivity
  read_replicas               = var.read_replicas
  time_zone                   = var.time_zone

  availability_zone_mode   = var.availability_zone_mode
  master_availability_zone = var.master_availability_zone != null ? var.master_availability_zone : local.azs[0]

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.auto_renew
  volume_size   = var.charging_mode == "postPaid" ? null : var.volume_size

  audit_log_enabled  = var.audit_log_enabled
  sql_filter_enabled = var.sql_filter_enabled
  encryption_status  = var.encryption_status
  encryption_type    = var.encryption_type
  kms_key_id         = var.kms_key_id

  datastore {
    engine  = var.datastore_engine
    version = var.datastore_version
  }

  backup_strategy {
    start_time         = var.bak_start_time
    keep_days          = var.bak_keep_days
  }

  dynamic "parameters" {
    for_each = var.parameter_configuration

    content {
      name  = parameters.value["parameter_name"]
      value = parameters.value["parameter_value"]
    }
  }

  tags = var.tags
}