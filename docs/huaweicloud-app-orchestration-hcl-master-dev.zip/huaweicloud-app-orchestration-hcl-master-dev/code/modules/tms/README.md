# The Terraform module of HUAWEI Cloud TMS Service

## Usage

### Create an TMS tag and attach to resources 

```
module "resource_tags" {
  source = "module/tms"

  resources_project_name  = "cn-south-1"
  resources_configuration = [{ resource_type = "ecs", resource_id = "resource_id" }]
  resources_tags          = { Purpose = "MkpApplication" }
}
```