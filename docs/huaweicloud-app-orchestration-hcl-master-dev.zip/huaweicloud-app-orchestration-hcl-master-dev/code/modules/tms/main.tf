data "huaweicloud_identity_projects" "projects" {
  name = var.resources_project_name
}

resource "huaweicloud_tms_resource_tags" "resource_tags" {
  project_id = data.huaweicloud_identity_projects.projects.projects[0].id

  dynamic "resources" {
    for_each = var.resources_configuration

    content {
      resource_type = resources.value["resource_type"]
      resource_id   = resources.value["resource_id"]
    }
  }

  tags = var.resources_tags
}