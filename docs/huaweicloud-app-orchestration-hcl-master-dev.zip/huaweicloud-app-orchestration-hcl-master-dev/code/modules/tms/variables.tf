variable "resources_project_name" {
  type = string
  description = "Specifies the IAM project name to query"
}

variable "resources_configuration" {
  type = list(object({
    resource_type = string
    resource_id   = string
  }))
}

variable "resources_tags" {
  type = map(string)
  default = {
    Purpose = "MkpApplication"
  }
}