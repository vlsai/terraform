# Please refer to https://support.huaweicloud.com/api-vpc/vpc_route_0003.html
resource "huaweicloud_vpc_route" "vpc_route" {
  count = var.vpc_routes_configuration != null ? length(var.vpc_routes_configuration) : 0

  vpc_id         = lookup(element(var.vpc_routes_configuration, count.index), "vpc_id")
  destination    = lookup(element(var.vpc_routes_configuration, count.index), "destination")
  type           = lookup(element(var.vpc_routes_configuration, count.index), "type")
  nexthop        = lookup(element(var.vpc_routes_configuration, count.index), "nexthop")
  description    = lookup(element(var.vpc_routes_configuration, count.index), "description")
  route_table_id = lookup(element(var.vpc_routes_configuration, count.index), "route_table_id")
}