# The Terraform module of HUAWEI Cloud VPC Route

## Usage

### Create VPC Route

```
module "vpc_route" {
  source = "./modules/vpc_route"

  // You need to modify it according to your actual situation.
  vpc_routes_configuration = [
    { vpc_id = data.huaweicloud_vpc_subnet.subnet.vpc_id, destination = "172.16.0.0/12", type = "ecs", nexthop = module.ecs.ecs_ids[0], description = "", route_table_id = null }
  ]
}

```