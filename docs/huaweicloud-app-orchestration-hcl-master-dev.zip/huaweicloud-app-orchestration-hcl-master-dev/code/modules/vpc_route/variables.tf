variable "vpc_routes_configuration" {
  description = "The configuration for vpc routes"
  type = list(object({
    vpc_id         = string
    destination    = string
    type           = string
    nexthop        = string
    description    = string
    route_table_id = string
  }))
  default = []
}