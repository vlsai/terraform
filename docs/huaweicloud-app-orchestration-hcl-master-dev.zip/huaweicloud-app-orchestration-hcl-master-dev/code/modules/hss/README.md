# The Terraform module of HUAWEI Cloud HSS Service

## Usage

### Create an HSS instance

```
module "hss" {
  source = "modules/hss"

  host_id                 = "ecs_id"
  host_protection_version = "hss.version.enterprise"
  charging_mode           = "postPaid"
  
  is_wait_host_available = true

  quota_version = "hss.version.enterprise"
  period_unit   = "month"
  period        = 1
}

```