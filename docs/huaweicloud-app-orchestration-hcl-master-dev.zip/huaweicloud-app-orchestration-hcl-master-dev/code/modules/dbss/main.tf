data "huaweicloud_dbss_flavors" "dbss_flavors" {
  level = var.level
}

locals {
  availability_zone = join(",", data.huaweicloud_dbss_flavors.dbss_flavors[0].availability_zones)
  dbss_flavor       = data.huaweicloud_dbss_flavors.dbss_flavors[0].id

  # entry:���Ű�, low:������, medium: רҵ��, high: �߼���
  resource_spec_code_map = {
    entry  = "dbss.bypassaudit.entry"
    low    = "dbss.bypassaudit.low"
    medium = "dbss.bypassaudit.medium"
    high   = "dbss.bypassaudit.high"
  }
}

resource "huaweicloud_dbss_instance" "dbss" {
  name        = var.name_suffix != null ? format("%s-%s", var.name, var.name_suffix) : var.name
  description = var.description

  availability_zone  = var.availability_zone != null ? var.availability_zone : local.availability_zone
  flavor             = var.dbss_flavor != null ? var.dbss_flavor : local.dbss_flavor
  resource_spec_code = var.resource_spec_code != null ? var.resource_spec_code : local.resource_spec_code_map[var.level]
  product_spec_desc  = "{\"specDesc\":{\"zh-cn\":{\"key1\":\"value1\"},\"en-us\":{\"key1\":\"value1\"}}}"

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id
  ip_address        = var.ip_address

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.auto_renew

  enterprise_project_id = var.enterprise_project_id
  tags                  = var.dbss_tags
}