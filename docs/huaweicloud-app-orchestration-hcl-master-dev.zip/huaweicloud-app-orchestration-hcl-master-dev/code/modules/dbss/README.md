# The Terraform module of HUAWEI Cloud DBSS Service

## Usage

### Create an DBSS 

```
module "dbss" {
  source = "modules/dbss"
  name   = "dbss"

  vpc_id            = ""
  subnet_id         = ""
  security_group_id = ""
  charging_mode     = "prePaid"
  period_unit       = "month"
  period            = 1
  level             = "entry"
}

```