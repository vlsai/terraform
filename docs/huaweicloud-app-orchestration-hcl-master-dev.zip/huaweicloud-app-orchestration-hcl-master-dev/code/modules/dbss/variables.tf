variable "level" {
  description = "Specifies the level of the flavor.Value options:entry: Starter edition, low: Basic edition, medium: Professional edition, high: Premium edition."

  type    = string
  default = null
}

variable "name" {
  description = "Specifies the instance name. The name can contain 1 to 64 characters. Only letters, digits, underscores (_), and hyphens (-) are allowed."

  type    = string
  default = null
}

variable "availability_zone" {
  description = "Specifies the availability zone to which the instance belongs."

  type    = string
  default = null
}

variable "vpc_id" {
  description = "Specifies the VPC ID"

  type    = string
  default = null
}

variable "subnet_id" {
  description = "Specifies the subnet ID of the NIC"

  type    = string
  default = null
}

variable "security_group_id" {
  description = "Specifies the ID of the security group."

  type    = string
  default = null
}

variable "resource_spec_code" {
  description = "Specifies the resource specifications. Possible values are:dbss.bypassaudit.entry: Entry Version, dbss.bypassaudit.low: Basic version, dbss.bypassaudit.medium: Professional version, dbss.bypassaudit.high: Advanced version."

  type    = string
  default = null
}

variable "charging_mode" {
  description = "Specifies the charging mode of the elastic IP. Valid values are prePaid and postPaid. The valid values are as follows:prePaid: the year/month billing mode,postPaid: the pay-per-use billing mode."

  type    = string
  default = null
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "auto_renew" {
  description = "Specifies whether auto-renew is enabled. Valid values are true and false. Defaults to false."

  type    = bool
  default = false
}

variable "name_suffix" {
  description = "The suffix string of name for all DBSS resources"

  type    = string
  default = "mkp"
}

variable "dbss_tags" {
  description = "The tags configuration of the DBSS"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "dbss_flavor" {
  description = "Specifies the flavor, Possible values are: c3ne.xlarge.4: Basic version, c3ne.2xlarge.4: Professional version, c6.4xlarge.4: Advanced version."

  type    = string
  default = "c3.xlarge.4"
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the CBH instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}

variable "ip_address" {
  description = "Specifies the IP address. If the value of this parameter is left blank or is set to an empty string, the IP address is automatically assigned."

  type    = string
  default = null
}

variable "description" {
  description = "Specifies the description of the instance.Changing this parameter will create a new resource"

  type    = string
  default = null
}



