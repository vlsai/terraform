# The Terraform module of HUAWEI Bandwidth Service

## Usage

### Create an Shared Bandwidth instance

```
// 创建共享带宽
module "bandwidth" {
  source = "../../modules/bandwidth"

  is_bandwidth_create = true

  name_suffix    = "mkp"
  bandwidth_name = format("%s-%s", "test", "bandwidth")
  bandwidth_size = 5

  charging_mode = "postPaid"
  period_unit   = "month"
  period        = 1
}

```