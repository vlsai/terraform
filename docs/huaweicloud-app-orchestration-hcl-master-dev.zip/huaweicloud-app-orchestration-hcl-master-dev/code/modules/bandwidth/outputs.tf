output "id" {
  value       = huaweicloud_vpc_bandwidth.bandwidth.id
  description = "The resource Id of the bandwidth."
}