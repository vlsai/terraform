variable "charge_mode" {
  description = "Specifies whether the billing is based on bandwidth or 95th percentile bandwidth (enhanced). Possible values can be bandwidth and 95peak_plus. The default value is bandwidth, and 95peak_plus is only valid for v4 and v5 Customer.When charging_mode is prePaid, only bandwidth is valid, please updating charge_mode to bandwidth before changing to prePaid billing mode."

  type    = string
  default = "bandwidth"
}

variable "charging_mode" {
  description = "Specifies the charging mode of the elastic IP. Valid values are prePaid and postPaid. The valid values are as follows:prePaid: the year/month billing mode,postPaid: the pay-per-use billing mode."

  type    = string
  default = "prePaid"
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "bandwidth_type" {
  description = "Specifies the bandwidth type. Valid values are share and edgeshare. Default is share."

  type    = string
  default = "share"
}

variable "bandwidth_name" {
  description = "Specifies the bandwidth name.The name can contain 1 to 64 characters, including letters, digits, underscores (_), hyphens (-), and periods (.). This parameter is mandatory when share_type is set to PER"

  type    = string
  default = null
}

variable "bandwidth_size" {
  description = "The bandwidth size.The value ranges from 1 to 300 Mbit/s. This parameter is mandatory when share_type is set to PER."

  type    = number
  default = null
}

######################################################################
# Attributes of the EIP
######################################################################

variable "name_suffix" {
  description = "The suffix string of name for all bandwidth resources"

  type    = string
  default = "mkp"
}

variable "is_bandwidth_create" {
  type    = bool
  default = true
}



