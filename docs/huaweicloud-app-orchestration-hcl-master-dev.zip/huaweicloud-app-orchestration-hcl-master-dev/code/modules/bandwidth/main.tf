//  Parameter details refer to:https://support.huaweicloud.com/api-eip/BatchCreatePublicips.html
resource "huaweicloud_vpc_bandwidth" "bandwidth" {
  name           = var.name_suffix != null ? format("%s-%s", var.bandwidth_name, var.name_suffix) : var.bandwidth_name
  size           = var.bandwidth_size
  charge_mode    = var.charge_mode
  charging_mode  = var.charging_mode
  period_unit    = var.period_unit
  bandwidth_type = var.bandwidth_type
  period         = var.period
}
