# The Terraform module of HUAWEI Cloud Security Group

## Usage

### Create Security Group

```
module "security-group" {
  source = "./modules/security-group"

  is_secgroup_create = true

  name_suffix             = "mkp"
  secgroup_name           = format("%s-%s", local.app_id, "secgroup")
  is_delete_default_rules = true

  // You need to modify it according to your actual situation.
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "443", remote_ip_prefix = var.remote_ip_cidr, remote_group_id = var.remote_group_id }
  ]
}

```