resource "huaweicloud_cfw_firewall" "cfw_instance" {
  name = "cfw"

  flavor {
    # Standard 标准版,Professional 专业版, 防火墙版本
    # “charge_mode”为“prePaid”时，标准版、支持专业版。
    # “charge_mode”为“postPaid”时，专业版。
    version = var.cfw_version
  }

  tags = var.cfw_tags

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.auto_renew
}