output "id" {
  value = huaweicloud_cfw_firewall.cfw_instance.id
}

