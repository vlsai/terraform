# The Terraform module of HUAWEI Cloud CFW Service

## Usage

```
module "cfw" {
  # You need to modify this path according to your code directory structure.
  source        = "modules/cfw"
  cfw_version   = "Standard"
  charging_mode = "prePaid"
  period_unit   = "month"
  period        = 1
}
```