variable "charging_mode" {
  type        = string
  default     = null
  description = " Specifies the charging mode of the cfw. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode."
}

variable "period_unit" {
  type        = string
  description = "Specifies the charging period unit of the cloud CFW. Valid values are month and year"
}

variable "period" {
  type        = string
  description = "Specifies the charging period of the cloud CFW. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3"
}

variable "auto_renew" {
  type        = string
  default     = "false"
  description = "Specifies whether auto renew is enabled. Valid values are true and false."
}

variable "cfw_version" {
  description = "Specifies the cfw version. The valid values are as follows:Standard and Professional"
  type        = string
  default     = "Standard"
}
variable "cfw_tags" {
  description = "The tags configuration of the cfw instance"

  type    = map(string)
  default = { Purpose = "cfw" }
}
