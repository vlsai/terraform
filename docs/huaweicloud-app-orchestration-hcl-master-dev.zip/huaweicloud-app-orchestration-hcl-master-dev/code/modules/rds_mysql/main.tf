data "huaweicloud_rds_flavors" "rds_flavor" {
  db_type       = var.db_engines
  db_version    = var.db_version
  instance_mode = var.db_instance_mode
  vcpus         = var.db_vcpus
  memory        = var.db_memory
  group_type    = var.group_type
}

# Query Rds storage type
data "huaweicloud_rds_storage_types" "rds_storage" {
  db_type       = var.db_engines
  db_version    = var.db_version
  instance_mode = var.db_instance_mode
}

data "huaweicloud_rds_flavors" "rds_readonly_flavor" {
  db_type       = var.db_engines
  db_version    = var.db_version
  instance_mode = "replica"
  vcpus         = var.db_vcpus
  memory        = var.db_memory
  group_type    = var.group_type
}

locals {
  storage_all        = data.huaweicloud_rds_storage_types.rds_storage.storage_types
  storage_azs        = [for i, name in local.storage_all[*].name : local.storage_all[i].az_status if name == var.db_instance_storage_type][0]
  storage_normal_azs = [for k, v in local.storage_azs : k if v == "normal"]

  flavors_az_maps      = { for i, flavor_ids in data.huaweicloud_rds_flavors.rds_flavor.flavors[*] : data.huaweicloud_rds_flavors.rds_flavor.flavors[i].name => data.huaweicloud_rds_flavors.rds_flavor.flavors[i].availability_zones }
  rds_ok_flavor        = var.flavor != null && contains(keys(local.flavors_az_maps), var.flavor) ? var.flavor : keys(local.flavors_az_maps)[0]
  rds_flavor_azs       = local.flavors_az_maps[local.rds_ok_flavor]
  rds_azs              = tolist(setintersection(local.storage_normal_azs, local.rds_flavor_azs))
  db_availability_zone = var.db_instance_mode == "ha" ? slice(local.rds_azs, 0, 2) : (length(local.rds_azs) > 1 ? slice(local.rds_azs, 0, 1) : local.rds_azs)

  readonly_flavors_az_maps      = { for i, flavor_ids in data.huaweicloud_rds_flavors.rds_readonly_flavor.flavors[*] : data.huaweicloud_rds_flavors.rds_readonly_flavor.flavors[i].name => data.huaweicloud_rds_flavors.rds_readonly_flavor.flavors[i].availability_zones }
  rds_readonly_ok_flavor        = var.readonly_flavor != null && contains(keys(local.readonly_flavors_az_maps), var.readonly_flavor) ? var.readonly_flavor : keys(local.readonly_flavors_az_maps)[0]
  rds_readonly_flavor_azs       = local.readonly_flavors_az_maps[local.rds_readonly_ok_flavor]
  rds_readonly_azs              = tolist(setintersection(local.storage_normal_azs, local.rds_readonly_flavor_azs))
  db_readonly_availability_zone = local.rds_readonly_azs[0]
}

//  Parameter details refer to:https://support.huaweicloud.com/api-rds/rds_01_0002.html
resource "huaweicloud_rds_instance" "rds" {
  count             = var.is_rds_create ? 1 : 0
  availability_zone = var.db_availability_zone == null ? local.db_availability_zone : var.db_availability_zone

  name   = var.name_suffix != null ? format("%s-%s", var.db_instance_name, var.name_suffix) : var.db_instance_name
  flavor = local.rds_ok_flavor

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id

  ha_replication_mode = var.replication_mode
  charging_mode       = var.charging_mode
  period_unit         = var.period_unit
  period              = var.period
  time_zone           = var.time_zone

  param_group_id = var.param_group_id

  lower_case_table_names = var.lower_case_table_names

  ssl_enable = true

  db {
    type     = var.db_engines
    version  = var.db_version
    password = var.db_password
    port     = var.db_port
  }

  volume {
    type               = var.db_instance_storage_type
    size               = var.db_allocated_storage
    disk_encryption_id = var.disk_encryption_id
  }

  backup_strategy {
    keep_days  = var.keep_days
    start_time = var.start_time
  }

  tags = var.rds_tags

  dynamic "parameters" {
    for_each = var.parameter_configuration

    content {
      name  = parameters.value["parameter_name"]
      value = parameters.value["parameter_value"]
    }
  }
}

// Create RDS mysql account resource
resource "huaweicloud_rds_mysql_account" "mysql_account" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  name        = var.account_name
  password    = var.account_pwd
}

// Create RDS mysql account resource
resource "huaweicloud_rds_mysql_database" "mysql_database" {
  count         = var.is_rds_create ? 1 : 0
  instance_id   = huaweicloud_rds_instance.rds[0].id
  name          = var.lower_case_table_names == "1" ? lower(var.database_name) : var.database_name
  character_set = var.character_set
}

// Manages RDS Mysql database privilege resource within HuaweiCloud.
resource "huaweicloud_rds_mysql_database_privilege" "dbPrivilege" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  depends_on  = [huaweicloud_rds_mysql_account.mysql_account, huaweicloud_rds_mysql_database.mysql_database]
  db_name     = var.lower_case_table_names == "1" ? lower(var.database_name) : var.database_name
  users {
    name     = var.account_name
    readonly = false
  }
}

# Create ReadOnly Instance
resource "huaweicloud_rds_read_replica_instance" "readonly_instance" {
  count  = var.is_rds_readonly_create ? 1 : 0
  name   = var.name_suffix != null ? format("%s-%s", "rds_readonly_instance", var.name_suffix) : "rds_readonly_instance"
  flavor = local.rds_readonly_ok_flavor

  primary_instance_id = huaweicloud_rds_instance.rds[0].id
  availability_zone   = var.db_readonly_availability_zone == null ? local.db_readonly_availability_zone : var.db_readonly_availability_zone
  security_group_id   = var.security_group_id

  db {
    port = var.db_port
  }

  volume {
    type = var.db_instance_storage_type
    size = var.db_allocated_storage
  }

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  tags = var.rds_tags
}
