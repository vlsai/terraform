output "rds_ip" {
  value = huaweicloud_rds_instance.rds[*].private_ips[0]
}

output "rds_user_name" {
  value = huaweicloud_rds_instance.rds[*].db[0].user_name
}

