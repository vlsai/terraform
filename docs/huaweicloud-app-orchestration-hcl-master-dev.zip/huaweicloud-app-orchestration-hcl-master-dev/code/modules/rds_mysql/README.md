# The Terraform module of HUAWEI Cloud RDS Service

## Usage

### Create an RDS for Mysql instance

```
locals {
  tags = { Purpose = "MkpApplication" }

  # RDS flavor config
  db_type    = "MySQL"
  db_version = "8.0"
  # vcpu 个数
  db_vcpus = 4
  # 内存大小
  db_memory = 8
  # RDS instance config
  db_port = 33006
  # 实例类型 ha--主备
  db_instance_mode = "single"
  # 性能规格：通用型
  db_group_type = "general"
  # 表名是否区分大小写 0--区分，1--不区分
  db_lower_case_table_names = "1"
  # 备份保留天数 0~732
  db_keep_days = 732
  # 自动备份触发时间点
  db_start_time            = "01:00-02:00"
  db_instance_storage_type = "CLOUDSSD"
  # 存储大小
  db_allocated_storage = 150

  rds_flavor          = "rds.mysql.n1.xlarge.2 "
  rds_readonly_flavor = "rds.mysql.x1.xlarge.2.rha.rr"
}

# Create RDS for postgresql
module "rds" {
  source        = "../../modules/rds_mysql"
  is_rds_create = true

  name_suffix      = "mkp"
  db_instance_name = format("%s-%s", "mkp", "rds")

  vpc_id            = "ed50b46d-5e0d-4d09-912f-d6b1e219d97f"
  subnet_id         = "e349ef1b-27ec-408c-8470-8162be2c83af"
  security_group_id = "07c5d320-282c-492a-9460-be8e6c281f4a"

  db_instance_mode = local.db_instance_mode
  db_vcpus         = local.db_vcpus
  db_memory        = local.db_memory
  group_type       = local.db_group_type

  flavor = local.rds_flavor

  replication_mode = null
  db_engines       = local.db_type
  db_version       = local.db_version
  db_password      = "xxx"
  db_port          = local.db_port

  # 备份
  keep_days  = local.db_keep_days
  start_time = local.db_start_time

  # 存储
  db_instance_storage_type = local.db_instance_storage_type
  db_allocated_storage     = local.db_allocated_storage
  # 表名忽略大小写
  lower_case_table_names = "1"

  charging_mode = "postPaid"

  rds_tags = local.tags

  # 只读实例的配置
  is_rds_readonly_create = true
  readonly_flavor        = local.rds_readonly_flavor
}

```