# The Terraform module of HUAWEI Cloud DCS Service

## Usage

### Create an Distributed Cache Service

```
locals {
  engine         = "Redis"
  engine_version = "5.0"
  capacity       = "1"
  cache_mode     = "ha"
  dcs_spec_code  = "redis.ha.xu1.large.r2.1"
  dcs_port       = 38000
}

module "dcs" {
  source = "modules/dcs"

  dcs_name           = format("%s-%s", "dcs", "0627")
  dcs_engine         = local.engine
  dcs_engine_version = local.engine_version
  dcs_capacity       = local.capacity
  dcs_flavor         = local.dcs_spec_code
  dcs_cache_mode     = local.cache_mode
  vpc_id             = "xxx"
  subnet_id          = "xxx"
  dcs_password       = "xxx"
  dcs_port           = local.dcs_port

  whitelists_configuration = [{ group_name = "dcs_whitelists", ip_address = []}]
  whitelist_enable         = true

  charging_mode = "postPaid"
}
```