# The Terraform module of HUAWEI Cloud DMS Service

## Usage

### Create an dms rabbitmq instance

```
module "dms" {
  source = "modules/dms"

  dms_name              = format("%s-%s", local.app_id, "dms")
  vpc_id                = module.vpc.vpc_id
  network_id            = module.vpc.subnet_id
  dms_security_group_id = module.security-group.secgroup_id[0]

  dms_flavor_id          = local.dms_flavor_id
  dms_storage_spec_code  = local.dms_flavorid_list[0]
  dms_availability_zones = [data.huaweicloud_dms_rabbitmq_flavors.dms_flavors.flavors[0].ios[0].availability_zones[0]]
  dms_storage_space      = 100

  dms_manager_user     = var.dms_manager_user
  dms_manager_password = var.dms_manager_password
  
  charging_mode          = var.charging_mode
  period_unit            = var.period_unit
  period                 = var.period
}
```