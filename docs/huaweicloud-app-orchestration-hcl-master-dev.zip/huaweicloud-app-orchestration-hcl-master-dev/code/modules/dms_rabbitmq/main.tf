resource "huaweicloud_dms_rabbitmq_instance" "dms_rabbitmq" {
  name              = var.dms_name
  vpc_id            = var.vpc_id
  network_id        = var.network_id
  security_group_id = var.dms_security_group_id

  flavor_id          = var.dms_flavor_id
  storage_spec_code  = var.dms_storage_spec_code
  availability_zones = var.dms_availability_zones
  engine_version     = var.dms_engine_version
  storage_space      = var.dms_storage_space

  access_user = var.dms_manager_user
  password    = var.dms_manager_password

  enterprise_project_id = var.enterprise_project_id

  charging_mode   = var.charging_mode
  period_unit     = var.period_unit
  period          = var.period

  tags = var.dms_tags
}