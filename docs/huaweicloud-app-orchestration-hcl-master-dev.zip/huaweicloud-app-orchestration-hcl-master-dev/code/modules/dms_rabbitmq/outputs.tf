output "ip" {
  value = huaweicloud_dms_rabbitmq_instance.dms_rabbitmq.connect_address
}