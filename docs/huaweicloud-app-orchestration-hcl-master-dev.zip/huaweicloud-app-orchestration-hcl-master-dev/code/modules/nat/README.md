# The Terraform module of HUAWEI Cloud NAT Service

## Usage

### Create an NAT instance 

```
locals {
  name_suffix = mkp
  nat_spec    = 1
  vpc_id      = ""
  subnet_id   = ""
}

# 创建 NAT网关
module "nat" {
  is_nat_creat = true
  source       = "modules/nat"
  name_suffix  = local.name_suffix
  gateway_name = format("%s-%s", local.app_id, "nat")
  spec         = local.nat_spec 
  vpc_id       = local.vpc_id
  subnet_id    = local.subnet_id

  nat_tags = local.tags
}

```