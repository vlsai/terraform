resource "huaweicloud_nat_gateway" "nat" {
  count       = var.is_nat_creat ? 1 : 0
  name        = var.name_suffix != null ? format("%s-%s", var.gateway_name, var.name_suffix) : var.gateway_name
  vpc_id      = var.vpc_id
  subnet_id   = var.subnet_id
  spec        = var.spec
  description = var.description

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.is_auto_renew

  ngport_ip_address = var.ngport_ip_address

  enterprise_project_id = var.enterprise_project_id

  tags = var.nat_tags
}

resource "huaweicloud_nat_snat_rule" "snat" {
  count          = var.is_nat_creat ? 1 : 0
  nat_gateway_id = huaweicloud_nat_gateway.nat[0].id
  floating_ip_id = var.publicip_id
  subnet_id      = var.subnet_id
}
