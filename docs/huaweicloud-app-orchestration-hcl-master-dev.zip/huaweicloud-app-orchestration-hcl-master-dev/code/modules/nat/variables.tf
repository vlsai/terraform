variable "is_nat_creat" {
  type        = bool
  description = "Specifies whether to create a NAT gateway."
  default     = false
}

variable "vpc_id" {
  type        = string
  description = "Specifies the ID of the VPC to which the NAT gateway belongs."
  default     = null
}

variable "subnet_id" {
  type        = string
  description = "Specifies the subnet ID of the downstream interface (the next hop of the DVR) of the NAT gateway"
  default     = null
}

variable "gateway_name" {
  description = "Specifies the NAT gateway name.The valid length is limited from 1 to 64, only letters, digits, hyphens (-) and underscores (_) are allowed."
  type        = string
  default     = null
}

variable "spec" {
  type        = string
  description = "The valid values are as follows,1: Small type, which supports up to 10,000 SNAT connections,2: Medium type, which supports up to 50,000 SNAT connections,3: Large type, which supports up to 200,000 SNAT connections,4: Extra-large type, which supports up to 1,000,000 SNAT connections."
  default     = null
}

variable "description" {
  type        = string
  description = "Specifies the description of the NAT gateway, which contain maximum of 512 characters, and angle brackets (<) and (>) are not allowed."
  default     = null
}

variable "charging_mode" {
  type        = string
  description = "Specifies the charging mode of the NAT gateway. The valid values are as follows:prePaid: the yearly/monthly billing mode.postPaid: the pay-per-use billing mode."
  default     = "postPaid"
}

variable "period_unit" {
  description = " Specifies the charging period unit of the NAT gateway. Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. Changing this will create a new resource."
  type        = string
  default     = "month"
}

variable "period" {
  description = "Specifies the charging period of the NAT gateway. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid."

  type    = number
  default = 1
}

variable "is_auto_renew" {
  description = "specifies whether auto-renew is enabled. This parameter is only valid when charging_mode is set to prePaid. Valid values are true and false. Defaults to false."
  type        = bool
  default     = false
}

variable "ngport_ip_address" {
  type        = string
  description = "Specifies the private IP address of the NAT gateway. The IP address must be one of the IP addresses of the VPC subnet associated with the NAT gateway. If not spacified, it will be automatically allocated."
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID of the NAT gateway."

  type    = string
  default = null
}

variable "nat_tags" {
  description = "The tags configuration of the nat instance"
  type        = map(string)
  default     = { Purpose = "MkpApplication" }
}

variable "publicip_id" {
  type        = string
  description = "The id of eip ip."
  default     = null
}



variable "name_suffix" {
  description = "The suffix string of name for all nat subnet resources"
  type        = string
  default     = ""
}

