# The Terraform module of HUAWEI Cloud EIP Service

## Usage

### Create an EIP 

```
module "eip" {
  # You need to modify this path according to your code directory structure.
  source = "modules/eip"

  is_eip_create = true

  name_suffix = "mkp"
  eip_name = format("%s-%s", local.app_id, "eip")

  publicip_type = "5_bgp"

  bandwidth_name = format("%s-%s", local.app_id, "bandwidth")
  bandwidth_share_type = "PER"
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_size = 1

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period
}

```