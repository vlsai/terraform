# The Terraform module of HUAWEI Cloud EPS Service

## Usage

### Create an enterprise project.

```
module "enterprise_project." {
  source = "module/eps"

  enterprise_project_name        = "auto_deploy"
  enterprise_project_description = "Used by auto deploy"
  enterprise_project_type        = "prod"
  enterprise_project_enable      = true
  skip_disable_on_destroy        = false
}
```