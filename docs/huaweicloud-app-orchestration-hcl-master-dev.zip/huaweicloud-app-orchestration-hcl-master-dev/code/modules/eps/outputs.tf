output "enterprise_project_id" {
  value       = huaweicloud_enterprise_project.enterprise_project.id
  description = "The Id of the enterprise project."
}

