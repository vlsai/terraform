variable "enterprise_project_name" {
  type = string
  description = "Specifies the name of the enterprise project."
}

variable "enterprise_project_description" {
  type = string
  description = "Specifies the name of the enterprise project."
}

variable "enterprise_project_type" {
  type = string
  description = " Specifies the type of the enterprise project. The valid values are poc and prod, defaults to prod."
}

variable "enterprise_project_enable" {
  type = string
  description = " Specifies whether to enable the enterprise project. Defaults to true."
}

variable "skip_disable_on_destroy" {
  type = bool
  description = "Specifies whether to skip disable the enterprise project on destroy. Defaults to false."
}

