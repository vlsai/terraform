resource "huaweicloud_enterprise_project" "enterprise_project" {
  name                    = var.enterprise_project_name
  description             = var.enterprise_project_description
  type                    = var.enterprise_project_type
  enable                  = var.enterprise_project_enable
  skip_disable_on_destroy = var.skip_disable_on_destroy
}