resource "huaweicloud_gaussdb_redis_instance" "gaussdb_redis" {
  name              = var.name_suffix != null ? format("%s-%s", var.redis_name, var.name_suffix) : var.redis_name
  password          = var.redis_password
  flavor            = var.redis_flavor
  volume_size       = var.volume_size
  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id
  availability_zone = var.availability_zone
  port              = var.port

  enterprise_project_id = var.enterprise_project_id

  backup_strategy {
    start_time = var.backup_start_time
    keep_days  = var.keep_days
  }

  tags = var.redis_tags
  ssl  = var.ssl

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
}