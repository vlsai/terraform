variable "redis_name" {
  description = "The name of the Redis instance"

  type    = string
  default = null
}

variable "name_suffix" {
  description = "The suffix string of name for all rds subnet resources"
  type        = string
  default     = ""
}

variable "redis_password" {
  type        = string
  description = "the admin password of redis."
  nullable    = false
  sensitive   = true
  validation {
    condition = (
    length(var.redis_password) >= 8 && length(var.redis_password) <= 32 &&
    length(regexall(".*[a-zA-Z].*", var.redis_password)) > 0 &&
    length(regexall(".*[0-9].*", var.redis_password)) > 0 &&
    length(regexall(".*[~!@#\\$%\\^&\\*\\(\\)\\-_=\\+\\?].*", var.redis_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(~！@#$%^&*()-_=+?)中的三种！"
  }
}

variable "redis_flavor" {
  description = "The ID of the Redis instance flavor"
  type        = string
  default     = null
}

variable "node_num" {
  description = "Specifies the number of nodes, ranges from 2 to 12.Defaults to 3."
  type        = number
  default     = 3
}

variable "availability_zone" {
  description = "Specifies the AZ name.  For a three-AZ deployment instance, use commas (,) to separate the AZs, for example, cn-north-4a,cn-north-4b,cn-north-4c"
  type        = string
  default     = null
}

variable "volume_size" {
  description = "Specifies the storage space in GB. For a GaussDB for Redis instance, the minimum and maximum storage space depends on the flavor and nodes_num."
  type        = number
  default     = null
}

variable "port" {
  description = "Specifies the port number for accessing the instance. You can specify a port number based on your requirements.The port number ranges from 1024 to 65535, excluding 2180, 2887, 3887, 6377, 6378, 6380, 8018, 8079, 8091, 8479, 8484, 8999, 12017, 12333, and 50069. Defaults to 6379. If you want to use this instance for dual-active DR, set the port to 8635."
  type        = number
  default     = 6379
}

variable "ssl" {
  description = "Specifies whether SSL is enabled. Defaults to false"
  type        = bool
  default     = false
}

variable "vpc_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a VPC."
}

variable "subnet_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a subnet."
}

variable "security_group_id" {
  type        = string
  default     = null
  description = "Specifies the security group ID. Required if the selected subnet doesn't enable network ACL"
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the Redis instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}

variable "charging_mode" {
  type        = string
  default     = null
  description = "Specifies the [charging mode](https://baidu.com) of the RDS DB instance"
}

variable "period_unit" {
  type        = string
  default     = null
  description = "Specifies the charging period unit of the RDS DB instance. Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "period" {
  type        = number
  default     = null
  description = "Specifies the charging period of the RDS DB instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}


variable "redis_tags" {
  description = "The tags configuration of the Redis instance"
  type        = map(string)
  default     = { Purpose = "MkpApplication" }
}

variable "backup_start_time" {
  description = "Specifies the backup time window. Automated backups will be triggered during the backup time window. It must be a valid value in the hh:mm-HH:MM format. The current time is in the UTC format. The HH value must be 1 greater than the hh value. The values of mm and MM must be the same and must be set to 00. Example value: 08:00-09:00, 03:00-04:00."
  type        = string
  default     = "00:00-01:00"
}

variable "keep_days" {
  description = "Specifies the number of days to retain the generated backup files. The value ranges from 0 to 35. If this parameter is set to 0, the automated backup policy is not set. If this parameter is not transferred, the automated backup policy is enabled by default. Backup files are stored for seven days by default."
  type        = number
  default     = 7
}