output "redis_ip" {
  value = huaweicloud_gaussdb_redis_instance.gaussdb_redis.private_ips
}

