# The Terraform module of HUAWEI Cloud GeminiDB Service

## Usage

### Create an GeminiDB for Redis instance

```
module "redis" {
  source = "modules/geminidb_redis"

  name_suffix       = "mkp"
  redis_name        = "redis"
  redis_flavor      = "geminidb.redis.medium.2"
  redis_password    = "xxx"
  volume_size       = 4
  node_num          = 2
  vpc_id            = "xxx"
  subnet_id         = "xxx"
  security_group_id = "xxx"
  port              = 10001

  enterprise_project_id = "xxx"

  availability_zone = ""

  charging_mode = "postPaid"
}

```