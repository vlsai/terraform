variable "dms_name" {
  type = string
  default = "dms-test"
  description = "(Required, String) Specifies the name of the DMS kafka instance. An instance name starts with a letter, consist of 4 to 64 characters, and supports only letters, digits, hyphens (-) and underscores (_)."
}

variable "dms_engine_version" {
  type = string
  default = "2.7"
  description = "(Required, String, ForceNew) Specifies the version of the kafka engine. Valid values are 1.1.0 and 2.3.0. Changing this creates a new instance resource."
}

variable "dms_storage_spec_code" {
  type = string
  default = "dms.physical.storage.high.v2"
  description = "(Required, String, ForceNew) Specifies the storage I/O specification. Changing this creates a new instance resource."
}

variable "dms_storage_space" {
  type = number
  default = 300
  description = "(Optional, Int) Specifies the message storage capacity, the unit is GB."
}

variable "dms_broker_num" {
  type = number
  default = 3
  description = "(Optional, Int) Specifies the message storage capacity, the unit is GB."
}

variable "vpc_id" {
  type = string
  description = "(Required, String, ForceNew) Specifies the ID of a VPC. Changing this creates a new instance resource."
}

variable "network_id" {
  type = string
  description = "(Required, String, ForceNew) Specifies the ID of a subnet. Changing this creates a new instance resource."
}

variable "dms_security_group_id" {
  type = string
  description = "(Required, String) Specifies the ID of a security group."
}

variable "dms_availability_zones" {
  type = list(string)
  description = "(Required, List, ForceNew) The names of the AZ where the Kafka instances reside. The parameter value can not be left blank or an empty array. Changing this creates a new instance resource."
}

variable "dms_manager_user" {
  type = string
  description = "(Required, List, ForceNew) Specifies the username for logging in to the Kafka Manager. The username consists of 4 to 64 characters and can contain letters, digits, hyphens (-), and underscores (_). Changing this creates a new instance resource."
}

variable "dms_manager_password" {
  type = string
  description = "Specifies the password for logging in to the Kafka Manager. The password must meet the following complexity requirements: Must be 8 to 32 characters long. Must contain at least 2 of the following character types: lowercase letters, uppercase letters, digits, and special characters. Changing this creates a new instance resource."
  sensitive   = true
  validation {
    condition = (
      length(var.dms_manager_password) >= 8 && length(var.dms_manager_password) <= 32 &&
      length(regexall(".*[a-zA-Z].*", var.dms_manager_password)) > 0 &&
      length(regexall(".*[0-9].*", var.dms_manager_password)) > 0 &&
      length(regexall(".*[`~!@#\\$%\\^&\\*\\(\\)\\-_=\\+\\|\\[\\{\\}\\]:'\",<\\.>/\\?].*", var.dms_manager_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(`~!@#$%^&*()-_=+|[{}]:'\",<.>/?)中的三种！"
  }
}

variable "dms_flavor_id" {
  type = string
  default = "kafka.4u8g.cluster"
  description = "(Optional, String) Specifies the kafka flavor ID, e.g. c6.2u4g.cluster. This parameter and product_id are alternative."
}

variable "enterprise_project_id" {
  default = null
  type = string
}

variable "dms_tags" {
  description = "The tags configuration of the DMS instance"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}