# The Terraform module of HUAWEI Cloud DMS Service

## Usage

### Create an dms kafka instance

