resource "huaweicloud_dms_kafka_instance" "dms_kafka" {
  name              = var.dms_name
  vpc_id            = var.vpc_id
  network_id        = var.network_id
  security_group_id = var.dms_security_group_id

  flavor_id          = var.dms_flavor_id
  storage_spec_code  = var.dms_storage_spec_code
  availability_zones = var.dms_availability_zones
  engine_version     = var.dms_engine_version
  storage_space      = var.dms_storage_space
  broker_num         = var.dms_broker_num

  manager_user     = var.dms_manager_user
  manager_password = var.dms_manager_password

  enterprise_project_id = var.enterprise_project_id

  tags = var.dms_tags

}