variable "db_instance_mode" {
  type        = string
  default     = null
  description = "The mode of instance. The value can be ha(indicates primary/standby instance), single(indicates single instance) and replica(indicates read replicas)."
}

variable "db_vcpus" {
  type        = number
  default     = null
  description = "Specifies the number of vCPUs in the RDS flavor."
}

variable "db_memory" {
  type        = number
  default     = null
  description = "Specifies the memory size(GB) in the RDS flavor."
}

variable "group_type" {
  type = string
  default = null
  description = "Specifies the performance specification.For more details, please refer to https://registry.terraform.io/providers/huaweicloud/huaweicloud/latest/docs/data-sources/rds_flavors"
}

variable "charging_mode" {
  type        = string
  default     = null
  description = "Specifies the charging mode of the RDS DB instance"
}

variable "period_unit" {
  type        = string
  default     = null
  description = "Specifies the charging period unit of the RDS DB instance. Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "period" {
  type        = number
  default     = null
  description = "Specifies the charging period of the RDS DB instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "db_instance_name" {
  type        = string
  default     = null
  description = "Specifies the DB instance name"
}

variable "db_version" {
  type        = string
  default     = null
  description = "Specifies the database version, available values detailed in https://support.huaweicloud.com/intl/en-us/productdesc-rds/en-us_topic_0043898356.html"
}

variable "db_instance_storage_type" {
  type        = string
  default     = null
  description = "Specifies the volume type,the value can be ULTRAHIGH,LOCALSSD,CLOUDSSD,ESSD. For details about volume types, see https://support.huaweicloud.com/intl/en-us/productdesc-rds/rds_01_0020.html"
}

variable "db_availability_zone" {
  type        = list(string)
  default     = null
  description = "Specifies the availability zone in which to create the instance."
}

variable "time_zone" {
  type        = string
  default     = null
  description = "For Microsoft SQL Server international site use UTC by default and Chinese mainland site use China Standard Time."
}

variable "disk_encryption_id" {
  type        = string
  default     = null
  description = "Specifies the key ID for disk encryption"
}

variable "db_allocated_storage" {
  type        = number
  default     = null
  description = "the size of database, in GB."
}

variable "db_port" {
  type        = number
  default     = 1433
  description = "The Microsoft SQL Server database port can be 1433 or ranges from 2100 to 9500, excluding 5355 and 5985. The default value is 1433"
}

variable "db_password" {
  type        = string
  sensitive   = true
  nullable    = false
  description = "database password."
  validation {
    condition = (
    length(var.db_password) >= 8 && length(var.db_password) <= 32 &&
    length(regexall(".*[a-zA-Z].*", var.db_password)) > 0 &&
    length(regexall(".*[0-9].*", var.db_password)) > 0 &&
    length(regexall(".*[~!@#\\$%\\^\\*\\-_\\+\\?].*", var.db_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(~!@#$%^*-_+?)中的三种！"
  }
}

variable "vpc_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "security_group_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "subnet_id" {
  type        = string
  default     = null
  description = " Specifies the subnet ID. "
}

variable "param_group_id" {
  type        = string
  default     = null
  description = "Specifies the parameter group ID."
}

variable "keep_days" {
  type        = number
  default     = null
  description = "Specifies the retention days for specific backup files. The value range is from 0 to 732. If this parameter is not specified or set to 0, the automated backup policy is disabled."
}

variable "start_time" {
  type        = string
  default     = null
  description = "Specifies the backup time window. Automated backups will be triggered during the backup time window."
}

variable "replication_mode" {
  type        = string
  default     = "sync"
  description = "For Microsoft SQL Server, the value is sync."
}

variable "collation" {
  type        = string
  default     = null
  description = "Specifies the Character Set, only available to Microsoft SQL Server DB instances."
}

variable "rds_tags" {
  description = "The tags configuration of the RDS instance"
  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "name_suffix" {
  description = "The suffix string of name for all rds subnet resources"
  type    = string
  default = ""
}

variable "is_rds_create" {
  type = bool
  default = true
}

variable "parameter_configuration" {
  description = "Specify an array of one or more parameters to be set to the RDS instance after launched. You can check on console to see which parameters supported."
  type = list(object({
    parameter_name         = string
    parameter_value       = string
  }))
  default = []
}

variable "flavor" {
  type    = string
  default = null
}

variable "account_name" {
  type = string
  default = null
  description = "Specifies the username of the DB account. The username consists of 1 to 128 characters and must be different from system usernames. System users include rdsadmin, rdsuser, rdsbackup, and rdsmirror."
}
variable "account_pwd" {
  type = string
  default = null
  description = "Specifies the password of the DB account.It consists of 8 to 128 characters and contains at least three types of the following characters: uppercase letters, lowercase letters, digits, and special characters. "
}
variable "database_name" {
  type = string
  default = null
  description = "create a database"
}
