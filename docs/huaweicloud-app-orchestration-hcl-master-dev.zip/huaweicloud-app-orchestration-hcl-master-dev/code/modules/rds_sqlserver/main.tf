data "huaweicloud_rds_flavors" "rds_flavor" {
  db_type       = local.db_type
  db_version    = var.db_version
  instance_mode = var.db_instance_mode
  vcpus         = var.db_vcpus
  memory        = var.db_memory
  group_type    = var.group_type
}

# Query Rds storage type
data "huaweicloud_rds_storage_types" "rds_storage" {
  db_type       = local.db_type
  db_version    = var.db_version
  instance_mode = var.db_instance_mode
}

locals {

  db_type = "SQLServer"

  storage_all        = data.huaweicloud_rds_storage_types.rds_storage.storage_types
  storage_azs        = [for i, name in local.storage_all[*].name : local.storage_all[i].az_status if name == var.db_instance_storage_type][0]
  storage_normal_azs = [for k, v in local.storage_azs : k if v == "normal"]
  rds_flavor_azs     = data.huaweicloud_rds_flavors.rds_flavor.flavors[0].availability_zones
  rds_azs            = tolist(setintersection(local.storage_normal_azs, local.rds_flavor_azs))

  db_availability_zone = var.db_instance_mode == "single" ? (length(local.rds_azs) > 1 ? slice(local.rds_azs, 0, 1) : local.rds_azs) : slice(local.rds_azs, 0, 2)
}

//  Parameter details refer to:https://support.huaweicloud.com/api-rds/rds_01_0002.html
resource "huaweicloud_rds_instance" "rds" {
  count             = var.is_rds_create ? 1 : 0
  availability_zone = var.db_availability_zone == null ? local.db_availability_zone : var.db_availability_zone

  name   = var.name_suffix != null ? format("%s-%s", var.db_instance_name, var.name_suffix) : var.db_instance_name
  flavor = var.flavor == null ? data.huaweicloud_rds_flavors.rds_flavor.flavors[0].name : var.flavor

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id

  ha_replication_mode = var.replication_mode
  charging_mode       = var.charging_mode
  period_unit         = var.period_unit
  period              = var.period

  time_zone = var.time_zone

  collation = var.collation

  param_group_id = var.param_group_id

  db {
    type     = local.db_type
    version  = var.db_version
    password = var.db_password
    port     = var.db_port
  }
  volume {
    size               = var.db_allocated_storage
    type               = var.db_instance_storage_type
    disk_encryption_id = var.disk_encryption_id
  }

  backup_strategy {
    keep_days  = var.keep_days
    start_time = var.start_time
  }

  tags = var.rds_tags

  dynamic "parameters" {
    for_each = var.parameter_configuration

    content {
      name  = parameters.value["parameter_name"]
      value = parameters.value["parameter_value"]
    }
  }
}

// Create RDS SQLServer account resource
resource "huaweicloud_rds_sqlserver_account" "sqlserver_account" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  name        = var.account_name
  password    = var.account_pwd
}

// Create RDS SQLServer account resource
resource "huaweicloud_rds_sqlserver_database" "sqlserver_database" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  name        = var.database_name
}
// Manages RDS Sqlserver database privilege resource within HuaweiCloud.
resource "huaweicloud_rds_sqlserver_database_privilege" "dbPrivilege" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  depends_on  = [huaweicloud_rds_sqlserver_account.sqlserver_account, huaweicloud_rds_sqlserver_database.sqlserver_database]
  db_name     = var.database_name
  users {
    name     = var.account_name
    readonly = false
  }
}
