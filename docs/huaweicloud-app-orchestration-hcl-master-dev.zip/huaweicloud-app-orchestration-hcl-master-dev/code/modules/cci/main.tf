resource "huaweicloud_cci_network" "cci_network" {
  availability_zone = var.availability_zone
  namespace         = var.namespace_name
  name              = var.network_name
  network_id        = var.vpc_network_id
  security_group_id = var.security_group_id
}

resource "huaweicloud_cci_namespace" "cci_namespace" {
  name         = var.namespace_name
  type         = var.namespace_type
  rbac_enabled = var.rbac_enabled

  warmup_pool_size          = var.warmup_pool_size
  recycling_interval        = var.recycling_interval
  container_network_enabled = var.container_network_enabled

  enterprise_project_id = var.enterprise_project_id
}