# The Terraform module of HUAWEI Cloud CCI NameSpace Service

## Usage

### Create an CCI namespace instance

```
module "cci" {
  source = "modules/cci"

  namespace_name = "test-cci"
  namespace_type = "general-computing"
  rbac_enabled   = false

  network_name      = "test-network"
  vpc_network_id    = "xxxx"
  security_group_id = "xxx"
}

```