variable "namespace_name" {
  type = string
  default = null
  description = "Specifies the unique name of the CCI namespace. This parameter can contain a maximum of 63 characters, which may consist of lowercase letters, digits and hyphens, and must start and end with lowercase letters and digits."
}

variable "namespace_type" {
  type = string
  default = "general-computing"
  description = "Specifies the CCI namespace type. The valid values are general-computing and gpu-accelerated. "
}

variable "rbac_enabled" {
  type = bool
  default = false
  description = "Specifies whether Role-based access control is enabled.After the RBAC permission is enabled, the user's use of resources under the namespace will be controlled by the RBAC permission"
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the CBH instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}

variable "warmup_pool_size" {
  type = number
  default = 10
  description = "Specifies the size of IP pool to warm-up."
}

variable "recycling_interval" {
  type = number
  default = 24
  description = " Specifies the IP address recycling interval, in hour. The idle IP resources from the elastic expansion of the IP resource pool can be recycled within this time."
}

variable "container_network_enabled" {
  type = bool
  default = false
  description = "Specifies whether container network is enabled. Enable this option if you want CCI to start the container network in advance so that containers can connect to the network as soon as they are started."
}

variable "network_name" {
  type = string
  default = null
  description = "Specifies an unique name of the CCI network resource. The name can contain a maximum of 200 characters, which may consist of lowercase letters, digits and hyphens (-). The name must start and end with a lowercase letter or digit. "
}

variable "vpc_network_id" {
  type = string
  default = null
  description = "Specifies a network ID of the VPC subnet which the CCI network belongs to."
}

variable "security_group_id" {
  type = string
  default = null
  description = "Specifies a security group ID to which the CCI network belongs to."
}

variable "availability_zone" {
  type = string
  default = null
  description = "Specifies the availability zone (AZ) to which the CCI network belongs"
}