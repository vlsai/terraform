# The Terraform module of HUAWEI Cloud EVS Service

## Usage

### Create an EVS 

```
module "evs" {
  # You need to modify this path according to your code directory structure.
  source = "modules/evs"

  is_volume_create = true
  # The total number of The EVS instance
  volume_count = 1

  availability_zone = local.availability_zone

  name_suffix = "mkp"
  volume_name = format("%s-%s", local.app_id, "evs")

  # You need to change the volume type according to the actual situation. 
  volume_type = "SAS"
  # You need to change the volume size according to the actual situation. 
  volume_size = 40

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  attached_configuration = [
    { instance_id = module.ecs.ecs_ids[0] }
  ]
}

```