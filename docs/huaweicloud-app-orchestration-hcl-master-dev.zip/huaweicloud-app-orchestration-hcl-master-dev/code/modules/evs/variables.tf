######################################################################
# Attributes of the CBC payment
######################################################################

variable "charging_mode" {
  description = "The charging mode of the EVS resources"

  type    = string
  default = null
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "is_auto_renew" {
  description = "Whether to automatically renew after expiration for EVS resources"

  type    = bool
  default = null
}

######################################################################
# Configuration of EVS resources
######################################################################

variable "name_suffix" {
  description = "The suffix string of name for all EVS resources"

  type    = string
  default = null
}

variable "is_volume_create" {
  description = "Controls whether the EVS volumes should be created (it affects all EVS related resources under this module)"

  type    = bool
  default = true
}

variable "availability_zone" {
  description = "The availability zone where the EVS volume is located"

  type = string
}

variable "volume_count" {
  description = "The total count of the EVS volumes"

  type    = number
  default = null
}

variable "volume_name" {
  description = "The name of the EVS volumes"

  type    = string
  default = null
}

variable "volume_description" {
  description = "The description of the EVS volumes"

  type    = string
  default = null
}

variable "volume_type" {
  description = "The type of the EVS volumes"

  type    = string
  default = "SSD"
}

variable "volume_size" {
  description = "The capacity of the EVS volumes, in GB.The valid value is range from:System disk: 1 GB to 1024 GB,Data disk: 10 GB to 32768 GB"

  type    = number
  default = 100
}

variable "volume_tags" {
  description = "The key/value pairs of the EVS volumes"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "attached_configuration" {
  description = "The configuration for attached resources to which the evs belongs"
  type = list(object({
    instance_id = string
  }))
  default = []
}
