//  Parameter details refer to:https://support.huaweicloud.com/api-eip/BatchCreatePublicips.html
resource "huaweicloud_evs_volume" "volume" {
  count = var.is_volume_create ? (var.volume_count != null ? var.volume_count : 1) : 0

  name                  = var.name_suffix != null ? format("%s-%s", var.volume_name, var.name_suffix) : var.volume_name
  description           = var.volume_description
  availability_zone     = var.availability_zone
  volume_type           = var.volume_type
  size                  = var.volume_size

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.is_auto_renew

  tags   = var.volume_tags
}

//  Bind a data disk to an ECS instance
resource "huaweicloud_compute_volume_attach" "attached" {
  count       = var.attached_configuration != null ? length(var.attached_configuration) : 0
  instance_id = lookup(element(var.attached_configuration, count.index), "instance_id")
  volume_id   = huaweicloud_evs_volume.volume[count.index].id
}

