output "evs_ids" {
  value = huaweicloud_evs_volume.volume[*].id
}
