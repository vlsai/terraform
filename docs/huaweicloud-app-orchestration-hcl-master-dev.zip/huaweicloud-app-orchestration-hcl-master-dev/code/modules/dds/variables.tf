variable "charging_mode" {
  type        = string
  default     = null
  description = "Specifies the charging mode of the RDS DB instance"
}

variable "period_unit" {
  type        = string
  default     = null
  description = "Specifies the charging period unit of the RDS DB instance. Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "period" {
  type        = number
  default     = null
  description = "Specifies the charging period of the RDS DB instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "dds_instance_name" {
  type        = string
  default     = null
  description = "Specifies the dds instance name"
}

variable "availability_zone" {
  type        = string
  default     = null
  description = "Specifies the availability zone in which to create the instance."
}

variable "disk_encryption_id" {
  type        = string
  default     = null
  description = "Specifies the key ID for disk encryption"
}

variable "dds_storage_type" {
  type        = string
  default     = null
  description = "Specifies the DB engine."
}

variable "dds_storage_version" {
  type        = string
  default     = null
  description = "Specifies the DB instance version. For the Community Edition, the valid values are 3.2, 3.4, 4.0, 4.2, or 4.4."
}

variable "dds_storage_storage_engine" {
  type        = string
  default     = null
  description = "Specifies the storage engine of the DB instance. If version is set to 3.2, 3.4, or 4.0, the value is wiredTiger. If version is set to 4.2, or 4.4, the value is rocksDB."
}

variable "dds_mode" {
  type        = string
  default     = null
  description = "Specifies the mode of the database instance. Sharding, ReplicaSet are supported. Changing this creates a new instance."
}

variable "dds_port" {
  type        = number
  default     = 8635
  description = "Specifies the dds port.The valid values are range from 2100 to 9500 and 27017, 27018, 27019. Defaults to 8635."
}

variable "dds_password" {
  type        = string
  sensitive   = true
  nullable    = false
  description = "DDS password."
  validation {
    condition = (
    length(var.dds_password) >= 8 && length(var.dds_password) <= 32 &&
    length(regexall(".*[a-zA-Z].*", var.dds_password)) > 0 &&
    length(regexall(".*[0-9].*", var.dds_password)) > 0 &&
    length(regexall(".*[~!@#%\\^\\*\\-_=\\+\\?].*", var.dds_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(~!@#%^*-_=+?)中的三种！"
  }
}

variable "vpc_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "security_group_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "subnet_id" {
  type        = string
  default     = null
  description = " Specifies the subnet ID. "
}

variable "keep_days" {
  type        = number
  default     = null
  description = "Specifies the retention days for specific backup files. The value range is from 0 to 732. If this parameter is not specified or set to 0, the automated backup policy is disabled."
}

variable "start_time" {
  type        = string
  default     = null
  description = "Specifies the backup time window. Automated backups will be triggered during the backup time window."
}

variable "backup_period" {
  type        = string
  default     = null
  description = "Specifies the backup cycle. Data will be automatically backed up on the selected days every week."
}

variable "name_suffix" {
  description = "The suffix string of name for all rds subnet resources"
  type    = string
  default = ""
}

variable "is_dds_create" {
  type = bool
  default = true
}

variable "flavor_type" {
  type     = string
  default  = null
  description = "Specifies the node type"
}

variable "flavor_num" {
  type     = number
  default  = null
  description = "Specifies the node quantity. "
}

variable "flavor_storage" {
  type     = string
  default  = null
  description = "Specifies the disk type. Valid value: ULTRAHIGH which indicates the type SSD."
}

variable "flavor_size" {
  type     = number
  default  = null
  description = "Specifies the disk size."
}

variable "flavor_spec_code" {
  type     = string
  default  = null
  description = "Specifies the resource specification code. "
}

variable "enable_ssl" {
  type = bool
  default = true
  description = "Specifies whether to enable or disable SSL. Defaults to true."
}