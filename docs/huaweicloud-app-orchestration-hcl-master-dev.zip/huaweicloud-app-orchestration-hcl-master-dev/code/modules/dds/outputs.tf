output "dds_ip" {
  value = huaweicloud_dds_instance.dds[*].nodes[*].private_ip
}

output "dds_user_name" {
  value = huaweicloud_dds_instance.dds[*].db_username
}

output "dds_id" {
  value = huaweicloud_dds_instance.dds[*].id
}

