resource "huaweicloud_dds_instance" "dds" {
  count = var.is_dds_create ? 1 : 0
  name  = var.name_suffix != null ? format("%s-%s", var.dds_instance_name, var.name_suffix) : var.dds_instance_name

  datastore {
    type           = var.dds_storage_type
    version        = var.dds_storage_version
    storage_engine = var.dds_storage_storage_engine
  }

  availability_zone = var.availability_zone
  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id
  password          = var.dds_password
  port              = var.dds_port
  mode              = var.dds_mode
  ssl               = var.enable_ssl

  flavor {
    type      = var.flavor_type
    num       = var.flavor_num
    storage   = var.flavor_storage
    size      = var.flavor_size
    spec_code = var.flavor_spec_code
  }

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  backup_strategy {
    start_time = var.start_time
    keep_days  = var.keep_days
    period     = var.backup_period
  }
}