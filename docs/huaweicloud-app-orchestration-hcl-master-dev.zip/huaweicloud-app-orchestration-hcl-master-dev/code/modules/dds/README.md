# The Terraform module of HUAWEI Cloud DDS Service

## Usage

### Create an DDS instance

```
module "dds" {
  source = "modules/dds"

  is_dds_create     = true
  name_suffix       = local.name_suffix
  dds_instance_name = format("%s-%s", local.app_id, "dds")

  availability_zone          = ""
  vpc_id                     = ""
  subnet_id                  = ""
  security_group_id          = ""
  dds_storage_type           = "DDS-Community"
  dds_storage_version        = "4.2"
  dds_storage_storage_engine = "rocksDB"
  dds_mode                   = "ReplicaSet"
  dds_port                   = 8635
  dds_password               = ""

  flavor_type      = "replica"
  flavor_num       = 3
  flavor_storage   = "ULTRAHIGH"
  flavor_size      = 20
  flavor_spec_code = "dds.mongodb.s6.medium.4.repset"

  start_time    = "01:00-02:00"
  keep_days     = 732
  backup_period = 3

  charging_mode = "postPaid"
  period_unit   = "month"
  period        = 1
}

```