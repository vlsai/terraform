variable "name_suffix" {
  description = "The suffix string of name for all cbh resources"

  type    = string
  default = "mkp"
}

variable "css_cluster_name" {
  type        = string
  default     = null
  description = "Specifies the cluster name. It contains 4 to 32 characters. Only letters, digits, hyphens (-), and underscores (_) are allowed. The value must start with a letter. "
}

variable "engine_type" {
  type        = string
  default     = null
  description = "Specifies the engine type. The valid value is elasticsearch. Defaults to elasticsearch"
}

variable "engine_version" {
  type        = string
  default     = null
  description = "Specifies the engine version.Supported Cluster Versions:https://support.huaweicloud.com/intl/en-us/api-css/css_03_0056.html"
}

variable "security_mode" {
  type        = bool
  default     = false
  description = "Specifies Whether to enable authentication. The value can be true or false. Authentication is disabled by default."
}

variable "cluster_password" {
  type        = string
  default     = null
  description = "Specifies the password of the cluster administrator in security mode. This parameter is mandatory only when security_mode is set to true. "
  sensitive   = true
  validation {
    condition = (
    length(var.cluster_password) >= 8 && length(var.cluster_password) <= 32 &&
    length(regexall(".*[a-zA-Z].*", var.cluster_password)) > 0 &&
    length(regexall(".*[0-9].*", var.cluster_password)) > 0 &&
    length(regexall(".*[~!@#\\$%\\^&\\*\\(\\)\\-_=\\+\\|\\[\\{\\}\\];:,<\\.>/].*", var.cluster_password)) > 0
    )
    error_message = "密码要求长度范围为8到32位，至少包含大写字母、小写字母、数字、特殊字符(~!@#$%^&*()-_=+\\|[{}];:,<.>/)中的三种！"
  }
}

variable "https_enabled" {
  type        = bool
  default     = false
  description = "Specifies whether to enable HTTPS. Defaults to false. When https_enabled is set to true, the security_mode needs to be set to true. "
}

variable "flavor_name" {
  type        = string
  default     = null
  description = "Specifies the flavor name"
}

variable "instance_num" {
  type        = number
  default     = 1
  description = "When it is ess_node_config, The value range is 1 to 32"
}

variable "volume_size" {
  type        = number
  default     = 1
  description = "Specifies the volume size in GB, which must be a multiple of 10"
}

variable "volume_type" {
  type        = string
  default     = null
  description = "Specifies the volume type. Value options are as follows,COMMON:Common I/O. The SATA disk is used.HIGH: High I/O. The SAS disk is used.ULTRAHIGH: Ultra-high I/O. The solid-state drive (SSD) is used."
}

variable "vpc_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a VPC."
}

variable "subnet_id" {
  type        = string
  default     = null
  description = "Specifies the ID of a subnet."
}

variable "security_group_id" {
  type        = string
  default     = null
  description = "Specifies the IDs of the security group. Multiple security group IDs are separated by commas (,) without spaces."
}

variable "availability_zone" {
  type        = string
  default     = null
  description = "Specifies the availability zone name.The number of nodes must be greater than or equal to the number of AZs"
}

variable "charging_mode" {
  type        = string
  default     = "prePaid"
  description = "Specifies the charging mode of the CBH instance. The options are as follows:prePaid: the yearly/monthly billing mode"
}

variable "period_unit" {
  description = "Specifies the charging period unit of the instance. Valid values are month and year."

  type    = string
  default = "month"
}

variable "period" {
  description = "Specifies the charging period of the CBH instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3."

  type    = number
  default = 1
}

variable "auto_renew" {
  description = "Specifies whether auto renew is enabled."

  type    = bool
  default = false
}

variable "subnet_address" {
  description = "Specifies the IP address of the subnet. If not specified, a new IP address will be assigned."

  type    = string
  default = null
}

variable "public_ip_id" {
  description = "Specifies the ID of the elastic IP."

  type    = string
  default = null
}

variable "attach_disk_size" {
  description = "Specifies the size of the additional data disk for the CBH instance. The unit is TB. It refers to the additional disk size added on top of the existing disk. And the sum of the built-in disk of the instance flavor and the additional disk cannot exceed 300TB."

  type    = number
  default = 0
}

variable "cluster_tags" {
  description = "The key/value pairs to associate with the cluster."

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the CBH instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}
