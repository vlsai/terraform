
resource "huaweicloud_css_cluster" "css_cluster" {
  name           = var.name_suffix != null ? format("%s-%s", var.css_cluster_name, var.name_suffix) : var.css_cluster_name
  engine_type    = var.engine_type
  engine_version = var.engine_version

  security_mode = var.security_mode
  password      = var.cluster_password
  https_enabled = var.https_enabled

  ess_node_config {
    flavor          = var.flavor_name
    instance_number = var.instance_num
    volume {
      volume_type = var.volume_type
      size        = var.volume_size
    }
  }

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id
  availability_zone = var.availability_zone

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.auto_renew

  tags                  = var.cluster_tags
  enterprise_project_id = var.enterprise_project_id
}