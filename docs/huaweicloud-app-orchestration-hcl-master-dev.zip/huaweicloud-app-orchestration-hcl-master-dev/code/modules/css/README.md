# The Terraform module of HUAWEI Cloud CSS Service

## Usage

### Create an CSS instance

```
module "css" {
  source = "modules/css"

  name_suffix      = "mkp"
  css_cluster_name = "css"
  engine_type      = "elasticsearch"
  engine_version   = "7.6.2"

  security_mode    = true
  cluster_password = ""
  https_enabled    = true

  flavor_name  = "ess.spec-8u16g"
  instance_num = 3
  volume_type  = "ULTRAHIGH"
  volume_size  = 500

  vpc_id            = ""
  subnet_id         = ""
  security_group_id = ""
  availability_zone = ""

  charging_mode = "postPaid"
  period_unit   = "month"
  period        = 1
  auto_renew    = false

  cluster_tags = { Purpose = "MkpApplication" }
}

```