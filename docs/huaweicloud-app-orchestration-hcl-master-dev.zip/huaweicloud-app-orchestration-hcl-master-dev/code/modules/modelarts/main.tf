resource "huaweicloud_modelarts_authorization" "authorization" {
  user_id     = var.user_id
  type        = "agency"
  agency_name = "modelarts_agency"
}

resource "huaweicloud_modelarts_network" "network" {
  name         = var.network_name
  cidr         = var.network_cidr
  workspace_id = var.workspace_id

  dynamic "peer_connections" {
    for_each = var.peer_connections

    content {
      vpc_id    = peer_connections.value["vpc_id"]
      subnet_id = peer_connections.value["subnet_id"]
    }
  }
}

resource "huaweicloud_modelarts_resource_pool" "resource_pool" {
  name        = var.pool_name
  description = var.description
  scope       = var.scope
  network_id  = huaweicloud_modelarts_network.network.id

  resources {
    flavor_id = var.flavor_id
    count     = var.node_count
    labels    = var.pool_labels
  }

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.is_auto_renew
}