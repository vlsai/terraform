# The Terraform module of HUAWEI Cloud ModelArts Pool

## Usage

### Create an ModelArts Pool instance

```
module "modearts_pool" {
  source = "modules/modelarts"

  network_name = "pool-network"
  network_cidr = "192.168.20.0/24"

  pool_name = "pool-test"

  scope = ["Train", "Infer", "Notebook"]

  charging_mode = "postPaid"
  node_count    = 1
  flavor_id     = ""

  user_id = ""
}

```