variable "network_name" {
  type        = string
  default     = null
  description = "The name of network.he name can contain 4 to 32 characters, only lowercase letters, digits and hyphens (-) are allowed. The name must start with a lowercase letter and end with a lowercase letter or digit."
}

variable "network_cidr" {
  type        = string
  default     = null
  description = "Network CIDR. Valid CIDR blocks are 10.0.0.0/8-24, 172.16.0.0/12-24, and 192.168.0.0/16-24."
}

variable "workspace_id" {
  type        = string
  default     = 0
  description = "Workspace ID, which defaults to 0.Changing this parameter will create a new resource."
}

variable "peer_connections" {
  description = "List of networks that can be connected in peer mode."
  type = list(object({
    vpc_id    = string
    subnet_id = string
  }))
  default = []
}

variable "pool_name" {
  type        = string
  default     = null
  description = "Specifies the name of the dedicated resource pool.The name can contain 4 to 32 characters, only lowercase letters, digits and hyphens (-) are allowed. The name must start with a lowercase letter and end with a lowercase letter or digit."
}

variable "description" {
  type        = string
  default     = null
  description = "Specifies the description of the dedicated resource pool"
}

variable "scope" {
  type        = list(string)
  default     = ["Train", "Infer", "Notebook"]
  description = "Specifies the list of job types supported by the resource pool. It is mandatory when network_id is specified and can not be specified when vpc_id is specified. The options are as follows:Train: training job.Infer: inference job.Notebook: Notebook job."
}

variable "charging_mode" {
  type        = string
  default     = null
  description = " Specifies the charging mode of the disk. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode. Changing this creates a new disk."
}

variable "period_unit" {
  description = "The period unit of the pre-paid purchase"

  type    = string
  default = null
}

variable "period" {
  description = "The period number of the pre-paid purchase"

  type    = number
  default = null
}

variable "is_auto_renew" {
  description = "Whether to automatically renew after expiration for ECS resources"

  type    = bool
  default = null
}

variable "flavor_id" {
  type        = string
  default     = null
  description = "Specifies the resource flavor ID."
}

variable "node_count" {
  type        = number
  default     = 1
  description = "Specifies the number of resources of the corresponding flavors."
}

variable "pool_labels" {
  description = "The tags configuration of the ModelArts pool instance"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "user_id" {
  description = "User ID.If user_id is set to all-users, all IAM users are authorized.If this user has been authorized, the authorization setting will be updated"
  type        = string
  default     = null
}