variable "resource_spec_code" {
  type        = string
  description = "Specifies the specification of the cloud WAF. The valid values are as follows,detection: Introduction edition. professional: Standard edition. enterprise: Professional edition. ultimate: Platinum edition."
}

variable "period_unit" {
  type        = string
  description = "Specifies the charging period unit of the cloud WAF. Valid values are month and year"
}

variable "period" {
  type        = string
  description = "Specifies the charging period of the cloud WAF. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3"
}

variable "auto_renew" {
  type        = string
  default     = "false"
  description = "Specifies whether auto renew is enabled. Valid values are true and false."
}

variable "enterprise_project_id" {
  type = string
  default = null
  description = "Specifies the ID of the enterprise project to which the cloud WAF belongs."
}


