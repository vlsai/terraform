resource "huaweicloud_waf_cloud_instance" "waf_cloud_instance" {
  resource_spec_code = var.resource_spec_code

  // The postpaid charging mode is only applicable to Huawei Cloud International website.
  charging_mode = "prePaid"
  period_unit   = var.period_unit
  period        = var.period
  auto_renew    = var.auto_renew

  enterprise_project_id = var.enterprise_project_id
}