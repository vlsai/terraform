# The Terraform module of HUAWEI Cloud ECS Service

## Usage

### Create an WAF instance 

```
module "waf" {
  # You need to modify this path according to your code directory structure.
  source             = "module/ecs"
  resource_spec_code = "detection"
  period_unit        = "month"
  period             = "1"
}

```