output "id" {
  value = huaweicloud_waf_cloud_instance.waf_cloud_instance.id
}

