//  Parameter details refer to:https://support.huaweicloud.com/api-rds/rds_01_0002.html
resource "huaweicloud_rds_instance" "rds" {
  count             = var.is_rds_create ? 1 : 0
  availability_zone = var.db_availability_zone

  name   = var.name_suffix != null ? format("%s-%s", var.db_instance_name, var.name_suffix) : var.db_instance_name
  flavor = var.flavor

  vpc_id            = var.vpc_id
  subnet_id         = var.subnet_id
  security_group_id = var.security_group_id

  ha_replication_mode = var.replication_mode
  charging_mode       = var.charging_mode
  period_unit         = var.period_unit
  period              = var.period
  time_zone           = var.time_zone

  param_group_id = var.param_group_id

  db {
    type     = var.db_engines
    version  = var.db_version
    password = var.db_password
    port     = var.db_port
  }

  volume {
    type               = var.db_instance_storage_type
    size               = var.db_allocated_storage
    disk_encryption_id = var.disk_encryption_id
  }

  backup_strategy {
    keep_days  = var.keep_days
    start_time = var.start_time
  }

  tags = var.rds_tags

  dynamic "parameters" {
    for_each = var.parameter_configuration != null ? [var.parameter_configuration] : []

    content {
      name  = parameters.value["parameter_name"]
      value = parameters.value["parameter_value"]
    }
  }
}

// Create RDS pgsql account resource
resource "huaweicloud_rds_pg_account" "pgsql_account" {
  count       = var.is_rds_create ? 1 : 0
  instance_id = huaweicloud_rds_instance.rds[0].id
  name        = var.account_name
  password    = var.account_pwd
}

// Create RDS pgsql database resource
resource "huaweicloud_rds_pg_database" "pgsql_database" {
  count                      = var.is_rds_create ? 1 : 0
  name                       = var.database_name
  owner                      = huaweicloud_rds_pg_account.pgsql_account
  template                   = var.template
  instance_id                = huaweicloud_rds_instance.rds[0].id
  character_set              = var.character_set
  lc_collate                 = var.lc_collate
  is_revoke_public_privilege = var.is_revoke_public_privilege
  description                = var.database_description
}

// Manages RDS for PostgreSQL plugin on the databases within HuaweiCloud.
resource "huaweicloud_rds_pg_plugin" "pg_plugin" {
  count         = var.is_rds_create ? 1 : 0
  instance_id   = huaweicloud_rds_instance.rds[0].id
  database_name = var.database_name
  name          = var.plugin_name
}

