# The Terraform module of HUAWEI Cloud RDS Service

## Usage

### Create an RDS for PostgreSQL instance

```
module "rds_pgsql" {
 source = "./modules/rds_pgsql"

  is_rds_create = true

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  name_suffix          = "mkp"
  db_instance_name     = format("%s-%s", local.app_id, "rds")
  db_availability_zone = [data.huaweicloud_rds_flavors.flavors.flavors[0].availability_zones[0]]
  time_zone            = "UTC"

  vpc_id            = module.vpc.vpc_id
  subnet_id         = module.vpc.subnet_id
  security_group_id = module.rds-security-group.secgroup_id[0]

  flavor = data.huaweicloud_rds_flavors.flavors.flavors[0].name

  param_group_id = ""

  replication_mode = null

  # db config
  db_version  = local.db_version
  db_password = var.db_password
  db_port     = local.db_port

  account_name  = var.account_name
  account_pwd   = var.account_pwd
  database_name = var.database_name

  # backup_strategy
  keep_days  = 100
  start_time = "01:00-02:00"

  # volume config
  db_instance_storage_type = "CLOUDSSD"
  db_allocated_storage     = var.db_allocated_storage
  disk_encryption_id       = ""
}

```