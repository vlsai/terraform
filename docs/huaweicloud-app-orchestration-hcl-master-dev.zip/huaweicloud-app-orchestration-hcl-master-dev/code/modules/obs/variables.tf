variable "bucket_name" {
  type        = string
  description = "Specifies the name of the bucket. Changing this parameter will create a new resource."
}

variable "storage_class" {
  type        = string
  default     = "STANDARD"
  description = "Specifies the storage class of the bucket. OBS provides three storage classes: STANDARD, WARM (Infrequent Access) and COLD (Archive). Defaults to STANDARD."
}

variable "bucket_acl" {
  default     = "private"
  type        = string
  description = "Specifies the ACL policy for a bucket. The predefined common policies are as follows: private, public-read, public-read-write and log-delivery-write. Defaults to private."
}

variable "bucket_policy" {
  default     = null
  type        = string
  description = "Specifies the text of the bucket policy in JSON format. For more information about obs format bucket policy"
}

variable "policy_format" {
  default     = "obs"
  type        = string
  description = "Specifies the policy format, the supported values are obs and s3. Defaults to obs."
}

variable "multi_az" {
  type        = bool
  default     = true
  description = "(Optional, Bool, ForceNew) Whether enable the multi-AZ mode for the bucket. When the multi-AZ mode is enabled, data in the bucket is duplicated and stored in multiple AZs."
}

variable "enterprise_project_id" {
  type        = string
  default     = null
  description = "(Optional, String, ForceNew) Specifies the enterprise project id of the OBS bucket. Changing this will create a new bucket."
}
variable "obs_tags" {
  description = "The tags configuration of the OBS Bucket"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}
