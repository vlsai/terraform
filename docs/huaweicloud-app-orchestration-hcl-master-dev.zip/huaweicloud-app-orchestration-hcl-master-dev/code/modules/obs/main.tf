resource "huaweicloud_obs_bucket" "obs_bucket" {
  bucket                = var.bucket_name
  storage_class         = var.storage_class
  acl                   = var.bucket_acl
  multi_az              = var.multi_az
  enterprise_project_id = var.enterprise_project_id
  tags                  = var.obs_tags
}