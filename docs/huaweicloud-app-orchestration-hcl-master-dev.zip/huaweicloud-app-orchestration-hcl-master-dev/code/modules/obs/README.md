# The Terraform module of HUAWEI Cloud OBS Service

## Usage

### Create an OBS Bucket

```
module "OBS" {
  source = "modules/obs"
  bucket_name = "xxx"
  storage_class = "STANDARD"
  bucket_acl = "private"
  multi_az = true
  enterprise_project_id = "xxx"
}

```