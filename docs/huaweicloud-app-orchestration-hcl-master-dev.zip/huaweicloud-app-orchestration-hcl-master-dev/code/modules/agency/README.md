# The Terraform module of HUAWEI Cloud IAM Agency Service

## Usage

### Create an IAM Agency 

```
module "agency" {
  source = "modules/agency"

  agency_name           = "test_agency"
  delegated_domain_name = "xxx"
  duration              = "1"

  project_name               = "cn-north-4"
  project_policy_name        = "ecs_flavor"
  project_policy_description = "Get ECS Flavors policy"
  project_policy             = <<EOF
  {
    "Version": "1.1",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ecs:flavors:get"
            ]
        }
    ]
  }
  EOF

  global_policy_name        = "obs_bucket"
  global_policy_description = "List OBS Bucket policy"
  global_policy             = <<EOF
  {
    "Version": "1.1",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "obs:bucket:ListBucket"
            ]
        }
    ]
  }
  EOF
}
```