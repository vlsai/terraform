resource "huaweicloud_identity_agency" "agency" {
  name                   = var.agency_name
  description            = var.agency_description
  delegated_domain_name  = var.delegated_domain_name
  duration               = var.duration

  project_role {
    project = var.project_name
    roles   = [huaweicloud_identity_role.project_policy.name]
  }

  domain_roles = [huaweicloud_identity_role.global_policy.name]
}

resource "huaweicloud_identity_role" "project_policy" {
  name        = var.project_policy_name
  description = var.project_policy_description
  type        = "XA"
  policy      = var.project_policy
}

resource "huaweicloud_identity_role" "global_policy" {
  name        = var.global_policy_name
  description = var.global_policy_description
  type        = "AX"
  policy      = var.global_policy
}