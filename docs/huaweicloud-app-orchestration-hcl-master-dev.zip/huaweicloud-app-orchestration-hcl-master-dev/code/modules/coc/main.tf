resource "huaweicloud_coc_script" "coc_script" {
  name        = var.script_name
  description = var.script_description
  risk_level  = var.risk_level
  version     = var.script_version
  type        = var.script_type

  content = var.script_content

  dynamic "parameters" {
    for_each = var.script_parameters

    content {
      name        = parameters.value["name"]
      value       = parameters.value["value"]
      description = parameters.value["description"]
      sensitive   = parameters.value["sensitive"]
    }
  }
}

resource "huaweicloud_coc_script_execute" "coc_script_execute" {
  script_id    = huaweicloud_coc_script.coc_script.id
  instance_id  = var.instance_id
  timeout      = var.execute_timeout
  execute_user = var.execute_user

  dynamic "parameters" {
    for_each = var.script_execute_parameters

    content {
      name  = parameters.value["name"]
      value = parameters.value["value"]
    }
  }
}