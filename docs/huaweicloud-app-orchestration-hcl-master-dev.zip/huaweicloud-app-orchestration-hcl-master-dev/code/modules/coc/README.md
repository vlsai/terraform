# The Terraform module of HUAWEI Cloud COC Service，COC is in the OBT phase. You need to apply for an OBT before using it. For details, see https://www.huaweicloud.com/product/coc.html.

## Usage

```
variable "instance_id" {}

module "coc_script" {
  source             = "modules/coc"
  script_name        = "demo"
  script_description = "a demo script"
  risk_level         = "LOW"
  script_version     = "1.0.0"
  script_type        = "SHELL"

  script_content = <<EOF
  #! /bin/bash
  echo "hello $${name}!" >> /usr/local/coc.txt
  EOF

  script_parameters = [{ name = "name", value = "world", description = "the first parameter", sensitive = false }]

  instance_id               = var.instance_id
  execute_timeout           = 600
  execute_user              = "root"
  script_execute_parameters = [{ name = "name", value = "world_value1" }]
}

```