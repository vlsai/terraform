output "execute_status" {
  value = huaweicloud_coc_script_execute.coc_script_execute.status
}
