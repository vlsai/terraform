variable "script_name" {
  type        = string
  default     = null
  description = "Specifies the name of the script.The value can contains 3 to 64 characters, including letters, digits, hyphens (-), and underscores (_). Changing this creates a new resource."
}

variable "script_description" {
  type        = string
  default     = null
  description = "Specifies the description of the script. The value can consist of up to 256 characters."
}

variable "risk_level" {
  type        = string
  default     = null
  description = "Specifies the risk level. The valid values are LOW, MEDIUM and HIGH."
}

variable "script_version" {
  type        = string
  default     = null
  description = "Specifies the version of the script. For example, 1.0.0 or 1.1.0."
}

variable "script_type" {
  type        = string
  default     = null
  description = "Specifies the content type of the script. The valid values are SHELL, PYTHON and BAT."
}

variable "script_content" {
  type        = string
  default     = null
  description = "Specifies the content of the script. The value can consist of up to 4096 characters."
}

variable "script_parameters" {
  description = "Specifies the parameters of the script"
  type = list(object({
    name        = string
    value       = string
    description = string
    sensitive   = bool
  }))
  default = []
}

variable "instance_id" {
  type        = string
  default     = null
  description = "Specifies the ECS instance ID. Changing this creates a new resource."
}

variable "execute_timeout" {
  type        = number
  default     = 1200
  description = "Specifies the maximum time to execute the script in seconds.Minimum value: 5, Maximum value: 1800"
}

variable "execute_user" {
  type        = string
  default     = "root"
  description = "Specifies the ECS instance ID. Changing this creates a new resource."
}

variable "script_execute_parameters" {
  description = "Specifies the parameters of the script"
  type = list(object({
    name        = string
    value       = string
  }))
  default = []
}




