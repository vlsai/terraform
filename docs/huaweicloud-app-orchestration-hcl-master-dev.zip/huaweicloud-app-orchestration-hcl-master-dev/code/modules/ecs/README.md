# The Terraform module of HUAWEI Cloud ECS Service

## Usage

### Create an ECS instance by public image

```
data "huaweicloud_availability_zones" "az" {}

locals {
  // you need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id = format("%s-%s", "app", formatdate("hhmm", timestamp()))

  name_suffix = "mkp"

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  # Configuration of the ECS memory size and number of cores
  instance_flavor_cpu    = 2
  instance_flavor_memory = 4
  # ���ͨ�ü�����ǿ��
  instance_performance_type = "computingv3"
  # ϵͳ�̣�ͨ����SSD
  ecs_volume_type = "GPSSD"
  # ϵͳ�̴�С��G
  ecs_volume_size = 40
  # ���id
  ecs_flavor = "c7.large.2"
  # ������
  ecs_data_disks = [{ data_disk_type = "GPSSD", data_disk_size = 50 }]
  # ������ҵ������ȫ���Ƽ��
  ecs_agent_list = "ces"

  // Billing model for cloud resources, You need to modify it according to your actual situation.
  // In the development and testing phase, pay-per-use billing is recommended.
  // You can also set these three parameters as variables, allowing users to select at deployment time.
  charging_mode = "postPaid"

  # Image information in different regions, you need to enter your own image ID or add another region.
  # For Marketplace Image Id,you can log in to Seller Console, view the marketplace image id on Product Specifications section of My Products detail page.
  # ����汾��Windows Server 2022 ��׼�� 64λ ����
  instance_image_id_maps = {
    cn-north-4     = "0eaf8527-7fc5-4b90-931e-8b2cb71b767d"
    cn-south-1     = "0ad606d3-2ca7-4e42-b5db-4677560d1d22"
    cn-east-3      = "22bb7fad-b92d-4cab-aadc-04f40ebb8937"
    cn-north-9     = "35449935-a461-4170-8795-287251499287"
    cn-southwest-2 = "065bf138-6279-4964-8dc9-5058bdab0073"
  }
}

// Create an ECS
module "ecs" {
  source = "modules/ecs"

  is_instance_create = true
  # The total number of The ECS instance
  instance_count = 1

  instance_image_id  = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]
  instance_flavor_id = local.ecs_flavor

  # You need to change the performance type��cpu and memory of the ECS based on the your requirements.
  instance_flavor_performance = local.instance_performance_type
  instance_flavor_cpu         = local.instance_flavor_cpu
  instance_flavor_memory      = local.instance_flavor_memory

  agent_list    = local.ecs_agent_list
  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs")

  security_group_ids = [""]

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = local.ecs_volume_type
  system_disk_size = local.ecs_volume_size
  data_disks       = local.ecs_data_disks

  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = "", fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = false, access_network = false },
  ]

  charging_mode = local.charging_mode

  admin_pass = "xxx"

  instance_tags = local.tags
  
  user_data = <<-EOF
  <powershell>
  #ps1
  Invoke-WebRequest -Uri "https://ecs-instance-driver.obs.cn-north-1.myhuaweicloud.com/datadisk/WinVMDataDiskAutoInitialize.ps1" -OutFile "C:\Windows\System32\WinVMDataDiskAutoInitialize.ps1"
  Set-ExecutionPolicy -ExecutionPolicy Bypass -Force
  C:\Windows\System32\WinVMDataDiskAutoInitialize.ps1
  </powershell>
  EOF
}

```