//  Query the az available for the Region
data "huaweicloud_availability_zones" "az" {}

//  Query the az available for the Region
// Query Rds flavors
data "huaweicloud_rds_flavors" "rds_flavor"{
  db_type = local.db_type
  db_version = local.db_version
  instance_mode = local.db_instance_mode
  vcpus = local.db_vcpus
  memory = local.db_memory
  group_type = local.db_group_type
}
# Query Rds storage type
data "huaweicloud_rds_storage_types" "rds_storage" {
  db_type    = local.db_type
  db_version = local.db_version
  instance_mode = local.db_instance_mode
}

