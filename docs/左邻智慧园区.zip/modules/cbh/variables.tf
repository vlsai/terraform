variable "cbh_type" {
  type = string
  default = "basic"
  description = "Specifies the type of CBH specification. The value can be:basic: Standard version, enhance: Professional version."
}
variable "is_instance_create" {
  description = "Controls whether a ECS instance should be created (it affects all ECS related resources under this module)"

  type    = bool
  default = true
}
variable "instance_count" {
  description = "The total number of the ECS instances"

  type    = number
  default = 0
}
variable "asset_number" {
  type = number
  default = null
  description = "Specifies the number of CBH assets"
}

variable "cbh_name" {
  type = string
  default = null
  description = "Specifies the name of the CBH instance. The field can contain 1 to 64 characters. Only letters, digits, underscores (_), and hyphens (-) are allowed."
}

variable "name_suffix" {
  description = "The suffix string of name for all cbh resources"

  type    = string
  default = "mkp"
}

variable "flavor_id" {
  type = string
  default = null
  description = "Specifies the product ID of the CBH server. When updating the flavor, it can only be changed to a higher flavor."
}

variable "vpc_id" {
  type = string
  default = null
  description = "Specifies the ID of a VPC."
}

variable "subnet_id" {
  type = string
  default = null
  description = "Specifies the ID of a subnet."
}

variable "security_group_id" {
  type = string
  default = null
  description = "Specifies the IDs of the security group. Multiple security group IDs are separated by commas (,) without spaces."
}

variable "availability_zone" {
  type = string
  default = null
  description = "Specifies the availability zone name."
}

variable "cbh_password" {
  type = string
  default = null
  description = "Specifies the password for logging in to the management console. The value of the field has the following restrictions:The value of the field must contain 8 to 32 characters.The value of the field must contain at least three of the following: letters, digits, and special characters (!@$%^-_=+[{}]:,./?~#*).The value of the field cannot contain the username or the username spelled backwards."
}

variable "charging_mode" {
  type        = string
  default     = "prePaid"
  description = "Specifies the charging mode of the CBH instance. The options are as follows:prePaid: the yearly/monthly billing mode"
}

variable "period_unit" {
  description = "Specifies the charging period unit of the instance. Valid values are month and year."

  type    = string
  default = "month"
}

variable "period" {
  description = "Specifies the charging period of the CBH instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3."

  type    = number
  default = 1
}

variable "subnet_address" {
  description = "Specifies the IP address of the subnet. If not specified, a new IP address will be assigned."

  type    = string
  default = null
}

variable "public_ip_id" {
  description = "Specifies the ID of the elastic IP."

  type    = string
  default = null
}

variable "attach_disk_size" {
  description = "Specifies the size of the additional data disk for the CBH instance. The unit is TB. It refers to the additional disk size added on top of the existing disk. And the sum of the built-in disk of the instance flavor and the additional disk cannot exceed 300TB."

  type    = number
  default = 0
}

variable "enterprise_project_id" {
  description = "Specifies the enterprise project ID to which the CBH instance belongs. For enterprise users, if omitted, default enterprise project will be used."

  type    = string
  default = null
}
