variable "db_instance_mode" {
  type        = string
  default     = null
  description = "The mode of instance. The value can be ha(indicates primary/standby instance), single(indicates single instance) and replica(indicates read replicas)."
}

variable "db_vcpus" {
  type        = number
  default     = null
  description = "Specifies the number of vCPUs in the RDS flavor."
}

variable "db_memory" {
  type        = number
  default     = null
  description = "Specifies the memory size(GB) in the RDS flavor."
}

variable "charging_mode" {
  type        = string
  default     = null
  description = "Specifies the charging mode of the RDS DB instance"
}

variable "period_unit" {
  type        = string
  default     = null
  description = "Specifies the charging period unit of the RDS DB instance. Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "period" {
  type        = number
  default     = null
  description = "Specifies the charging period of the RDS DB instance. If period_unit is set to month, the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. Changing this creates a new resource."
}

variable "db_instance_name" {
  type        = string
  default     = null
  description = "Specifies the DB instance name"
}

variable "db_engines" {
  type        = string
  default     = null
  description = "database engines,the value can be MySQL,PostgreSQL,Microsoft SQL Server"
}

variable "db_version" {
  type        = string
  default     = null
  description = "Specifies the database version"
}

variable "db_instance_storage_type" {
  type        = string
  default     = null
  description = "Specifies the volume type,the value can be ULTRAHIGH,LOCALSSD,CLOUDSSD,ESSD"
}

variable "group_type" {
  type = string
  default = null
  description = "Specifies the performance specification.For more details, please refer to https://registry.terraform.io/providers/huaweicloud/huaweicloud/latest/docs/data-sources/rds_flavors"
}

variable "db_availability_zone" {
  type        = list(string)
  default     = null
  description = "Specifies the availability zone in which to create the instance."
}

variable "time_zone" {
  type        = string
  default     = null
  description = " Specifies the UTC time zone. For MySQL and PostgreSQL Chinese mainland site and international site use UTC by default. "
}

variable "disk_encryption_id" {
  type        = string
  default     = null
  description = "Specifies the key ID for disk encryption"
}

variable "db_allocated_storage" {
  type        = number
  default     = null
  description = "the size of database, in GB."
}

variable "db_port" {
  type        = number
  default     = null
  description = "Specifies the database port"
}

variable "db_password" {
  type        = string
  sensitive   = true
  nullable    = false
  description = "database password."
}

variable "vpc_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "security_group_id" {
  type        = string
  default     = null
  description = " Specifies the VPC ID. "
}

variable "subnet_id" {
  type        = string
  default     = null
  description = " Specifies the subnet ID. "
}

variable "param_group_id" {
  type        = string
  default     = null
  description = "Specifies the parameter group ID."
}

variable "keep_days" {
  type        = number
  default     = null
  description = "Specifies the retention days for specific backup files. The value range is from 0 to 732. If this parameter is not specified or set to 0, the automated backup policy is disabled."
}

variable "start_time" {
  type        = string
  default     = null
  description = "Specifies the backup time window. Automated backups will be triggered during the backup time window."
}

variable "replication_mode" {
  type        = string
  default     = "async"
  description = "For MySQL, the value is async or semisync."
}

variable "lower_case_table_names" {
  type        = string
  default     = "1"
  description = "0: Table names are stored as fixed and table names are case-sensitive.1: Table names will be stored in lower case and table names are not case-sensitive."
}

variable "mysql_configuration" {
  description = "The configuration for rds database resources to which the rds belongs"
  type = list(object({
    name = string
    character_set = string
  }))
  default = []
}

variable "rds_tags" {
  description = "The tags configuration of the RDS instance"
  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "name_suffix" {
  description = "The suffix string of name for all rds subnet resources"
  type    = string
  default = ""
}

variable "is_rds_create" {
  type = bool
  default = true
}

variable "flavor" {
  type    = string
  default = ""
}

variable "parameter_configuration" {
  description = "Specify an array of one or more parameters to be set to the RDS instance after launched. You can check on console to see which parameters supported."
  type = list(object({
    parameter_name         = string
    parameter_value       = string
  }))
  default = []
}

variable "account_name" {
  type = string
  default = null
  description = "create a database user"
}

variable "account_pwd" {
  type = string
  default = null
  description = "config database user's password"
}

variable "database_name" {
  type = string
  default = null
  description = "create a database"
}

variable "character_set" {
  type = string
  default = null
  description = "Specifies the character set used by the database, For example utf8, gbk, ascii, etc."
}

variable "is_rds_readonly_create" {
  type = bool
  default = false
  description = "Whether to create RDS Read Replica Instance."
}

variable "readonly_flavor" {
  type    = string
  default = ""
}

variable "db_readonly_availability_zone" {
  type        = string
  default     = null
  description = "Specifies the availability zone in which to create the instance."
}
