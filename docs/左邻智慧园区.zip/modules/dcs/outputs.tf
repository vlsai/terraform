output "id" {
  value = huaweicloud_dcs_instance.dcs.id
}

output "dcs_ip" {
  value = huaweicloud_dcs_instance.dcs.private_ip
}

output "dcs_domain_name" {
  value = huaweicloud_dcs_instance.dcs.domain_name
}