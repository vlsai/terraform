variable "dcs_name" {
  type        = string
  default     = "dcs-test"
  description = "(Required, String) Specifies the name of an instance. The name must be 4 to 64 characters and start with a letter. Only chinese, letters (case-insensitive), digits, underscores (_) ,and hyphens (-) are allowed."
}
variable "name_suffix" {
  description = "The suffix string of name for all dcs resources"

  type    = string
  default = "mkp"
}
variable "dcs_engine" {
  type        = string
  default     = "Redis"
  description = "Specifies a cache engine. Options: Redis"
}

variable "dcs_cache_mode" {
  type        = string
  default     = "single"
  description = "The mode of a cache engine.The valid values are as follows:single - Single-node.ha - Master/Standby.cluster - Redis Cluster.proxy - Proxy Cluster. Redis6.0 not support this mode.ha_rw_split - Read/Write splitting. Redis6.0 not support this mode."
}

variable "dcs_engine_version" {
  type        = string
  default     = "6.0"
  description = "Specifies the version of a cache engine. It is mandatory when the engine is Redis, the value can be 6.0, 5.0, or 4.0. "
}

variable "dcs_capacity" {
  type        = number
  default     = 0.25
  description = "Stand-alone and active/standby type instance values: 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32 and 64. Cluster instance specifications support 4,8,16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768 and 1024. Unit: GB."
}

variable "dcs_flavor" {
  type        = string
  default     = "redis.ha.xu1.tiny.r2.256"
  description = "(Required, String) The flavor of the cache instance, which including the total memory, available memory, maximum number of connections allowed, maximum/assured bandwidth and reference performance. It also includes the modes of Redis instances."
}

variable "vpc_id" {
  type        = string
  default     = "b46699da-f321-4fcc-9d4d-72ea219c2207"
  description = "(Required, String, ForceNew) The ID of VPC which the instance belongs to. Changing this creates a new instance resource."
}

variable "subnet_id" {
  type        = string
  default     = "3a49f2cd-4043-48c4-ad2d-7c476a277f14"
  description = "(Required, String, ForceNew) The ID of subnet which the instance belongs to. Changing this creates a new instance resource."
}

variable "enterprise_project_id" {
  type        = string
  default     = null
  description = "(Optional, String, ForceNew) The enterprise project id of the dcs instance. Changing this creates a new instance."
}

variable "dcs_password" {
  type        = string
  description = "(Optional, String, ForceNew) Specifies the password of a DCS instance. Changing this creates a new instance."
}

variable "dcs_port" {
  type        = number
  default     = 6379
  description = "Specifies the Redis port"
}

variable "whitelists_configuration" {
  description = "Specifies the IP addresses which can access the instance"
  type = list(object({
    group_name = string
    ip_address = list(string)
  }))
  default = []
}

variable "whitelist_enable" {
  type        = bool
  default     = true
  description = "Enable or disable the IP address whitelists. Defaults to true. If the whitelist is disabled, all IP addresses connected to the VPC can access the instance."
}

variable "dcs_tags" {
  description = "The tags configuration of the DCS instance"

  type    = map(string)
  default = { Purpose = "MkpApplication" }
}

variable "charging_mode" {
  type        = string
  nullable    = false
  default     = "postPaid"
  description = " Specifies the charging mode of the disk. The valid values are as follows:prePaid: the yearly/monthly billing mode,postPaid: the pay-per-use billing mode. Changing this creates a new disk."
  validation {
    condition     = contains(["postPaid", "prePaid"], var.charging_mode)
    error_message = "Allowed values for input_parameter are prePaid or postPaid."
  }
}
variable "period_unit" {
  description = "The period unit of the pre-paid purchase.Valid values are month and year. This parameter is mandatory if charging_mode is set to prePaid. "

  type    = string
  default = "month"
  validation {
    condition     = contains(["month", "year"], var.period_unit)
    error_message = "Allowed values for input_parameter are month or year."
  }
}
variable "period" {
  description = "The period number of the pre-paid purchase. If period_unit is set to month , the value ranges from 1 to 9. If period_unit is set to year, the value ranges from 1 to 3. This parameter is mandatory if charging_mode is set to prePaid. "
  type        = number
  default     = 1
}