data "huaweicloud_dcs_flavors" "dcs_flavors" {
  capacity       = var.dcs_capacity
  cache_mode     = var.dcs_cache_mode
  engine_version = var.dcs_engine_version
}

locals {
  dcs_flavors_maps = { for i, flavor_ids in data.huaweicloud_dcs_flavors.dcs_flavors.flavors : data.huaweicloud_dcs_flavors.dcs_flavors.flavors[i].name => data.huaweicloud_dcs_flavors.dcs_flavors.flavors[i].available_zones }
  az_count = var.dcs_cache_mode == "single" ? 1 : 2
}

resource "huaweicloud_dcs_instance" "dcs" {
  name               = var.name_suffix != null ? format("%s-%s", var.dcs_name, var.name_suffix) : var.dcs_name
  engine             = var.dcs_engine
  engine_version     = var.dcs_engine_version
  capacity           = var.dcs_capacity
  flavor             = var.dcs_flavor
  availability_zones = slice(local.dcs_flavors_maps[var.dcs_flavor], 0, local.az_count)
  vpc_id             = var.vpc_id
  subnet_id          = var.subnet_id
  password           = var.dcs_password
  port               = var.dcs_port

  dynamic "whitelists" {
    for_each = var.whitelists_configuration

    content {
      group_name  = whitelists.value["group_name"]
      ip_address = whitelists.value["ip_address"]
    }
  }
  whitelist_enable = var.whitelist_enable

  enterprise_project_id = var.enterprise_project_id

  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period

  tags = var.dcs_tags
}

