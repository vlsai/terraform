

locals {
  // you need to specify a unique name under a tenant according to the business, which will be used as part of the resource name
  app_id = format("%s-%s", "app", formatdate("hhmm", timestamp()))
  name_suffix = "mkp"

  // Tags of HUAWEI CLOUD resources. You can add tags to resources to classify resources.
  // for more details, please refer to https://support.huaweicloud.com/usermanual-tms/zh-cn_topic_0056266263.html
  tags = { Purpose = "MkpApplication" }

  # Configuration of the ECS memory size and number of cores
  instance_flavor_cpu    = 8
  instance_flavor_memory = 64
  #  规格·通用计算增强型 此规格特殊 ecs_flavor = "x1e.8u.64g"
  instance_performance_type = "advanced_smb"
  # 通用型SSD云硬盘
  ecs_volume_type = "GPSSD"
  # 系统盘大小：G
  ecs_volume_size = 40
  # 数据盘
  ecs_data_disks = [{ data_disk_type = "GPSSD", data_disk_size = 300 }]
  # 规格：通用计算增强型
  ecs_flavor = "x1e.8u.64g"

  // Billing model for cloud resources, You need to modify it according to your actual situation.
  // In the development and testing phase, pay-per-use billing is recommended.
  // You can also set these three parameters as variables, allowing users to select at deployment time.
  charging_mode = var.charging_mode
  period_unit   = var.period_unit
  period        = var.period


  # Image information in different regions, you need to enter your own image ID or add another region.
  # For Marketplace Image Id,you can log in to Seller Console, view the marketplace image id on Product Specifications section of My Products detail page.
  # 镜像名称：
  # 镜像版本：CentOS 7.6 64bit
  instance_image_id_maps = {
    #     北京4
    cn-north-4 = "67f433d8-ed0e-4321-a8a2-a71838539e09"
    #     广州
    cn-south-1 = "7077ec61-7553-4890-8b33-364005a590b9"
    #     上海一
    cn-east-3 = "f101dc0f-2383-400b-8631-22c07b7847e2"
    #     乌兰察布一
    cn-north-9 = "1045a9f6-ef2e-4895-b81d-c823723d8160"
    #     贵阳一
    cn-southwest-2 = "c3d0e09b-48de-4d0d-9d3f-67c22a51bb87"
  }


  // The billing model for bandwidth, You need to modify it according to your actual situation.
  // 5_bgp 全动态bgp 5_sbgp 静态bgp
  publicip_type         = "5_bgp"   # 全动态bgp
  bandwidth_share_type  = "PER"     # 独享带宽
  bandwidth_charge_mode = "bandwidth" # 按带宽计费
  bandwidth_size =  10

  # Specifies the DNS server address list of a subnet. For details about the private DNS address, see https://support.huaweicloud.com/dns_faq/dns_faq_002.html#?
  subnet_dns_list_maps = {
    cn-north-4     = ["100.125.1.250", "100.125.129.250"]
    cn-south-1     = ["100.125.1.250", "100.125.136.29"]
    cn-east-3      = ["100.125.1.250", "100.125.64.250"]
    cn-north-9     = ["100.125.1.250", "100.125.107.250"]
    cn-southwest-2 = ["100.125.1.250", "100.125.129.250"]
  }
  az_maps = {
    cn-north-4     = "cn-north-4a"
    cn-south-1     = "cn-south-1c"
    cn-east-3      = "cn-east-3a"
    cn-north-9     = "cn-north-9a"
    cn-southwest-2 = "cn-southwest-2a"
  }

  # RDS flavor config
  #数据名称
  database_name = "mysql_test"
  #账号
  account_name = "eam"

  db_type      = "MySQL"
  # 数据库版本
  db_version = "5.7"
  # 实例类型 ha--主备,single：单实例，replica：只读实例。
  db_instance_mode = "ha"
  # 规格
  db_flavor = "rds.mysql.sld2.2xlarge.ha"
  # vcpu 个数
  db_vcpus = 8
  # 内存大小
  db_memory = 16
  # 性能规格：通用型
  db_group_type = "general"
  # RDS instance config
  db_port = 3306
  # 主备同步方式 async--异步复制，sync--同步复制
  db_replication_mode = "async"
  # 备份保留天数 0~732
  db_keep_days = 732
  # 自动备份触发时间点
  db_start_time = "01:00-02:00"
  # 存储类型 CLOUDSSD--SSD云盘
  db_instance_storage_type = "CLOUDSSD"
  # 存储大小
  db_allocated_storage = 500
  # 查询数据库磁盘类型可用区和规格可用区交集
  storage_all        = data.huaweicloud_rds_storage_types.rds_storage.storage_types
  storage_azs        = [for i, name in local.storage_all[*].name : local.storage_all[i].az_status if name == local.db_instance_storage_type][0]
  storage_normal_azs = [for k, v in local.storage_azs : k if v == "normal"]
  rds_flavor_azs     = data.huaweicloud_rds_flavors.rds_flavor.flavors[0].availability_zones
  rds_azs            = tolist(setintersection(local.storage_normal_azs, local.rds_flavor_azs))

  # config DCS
  # 实例类型：主备
  dcs_cache_mode = "ha"
  # 引擎类型
  dcs_engine = "Redis"
  # 引擎版本
  dcs_engine_version = "6.0"
  # 主备2g规格
  dcs_flavor = "redis.ha.xu1.large.r2.2"
  # 存储，单位G
  dcs_capacity = 2
  # 端口
  dcs_port = 6379


    # CBR config
  # 存储库类型，server-云服务器备份库
  vault_type                  = "server"
  # 保护类型，backup-备份；replication-复制
  vault_protection_type       = "backup"
  # 一致性等级
  vault_consistent_level      = "crash_consistent"
  # G
  vault_size                  = 1000
  # 备份数据冗余，false-单AZ；true-多AZ
  vault_is_multi_az           = false
  # 备份名称前缀
  vault_backup_name_prefix    = "mkp"
  #策略类型，backup-备份；replication-复制
  policy_type     = "backup"
  # 备份保留时间，天
  policy_time_period     = 365
  # 启用策略
  policy_enabled         = true
  # 备份间隔，每1天
  policy_backup_interval = 1
  # 备份时间，UTC 当前HH:MM
  policy_execution_times = ["18:00"]

  software_url        = data.huaweicloud_koogallery_assets.assets.assets[0].software_pkg_deployed_object[0].internal_path
  software_url_decode = jsondecode("\"${local.software_url}\"")
}

