# TODO asset_id，为创建的资产id；asset_version，资产版本
data "huaweicloud_koogallery_assets" "assets" {
  region = "cn-north-4"
  asset_id      = "0e6a1898-1961-4f02-91a5-138c63426b36"  //必修填
  deployed_type = "software_package"
  asset_version = "v12.1.3"
}

// Create a VPC
module "vpc" {
  source = "./modules/vpc"

  # config of vpc
  name_suffix       = local.name_suffix
  vpc_name          = format("%s-%s", local.app_id, "vpc")
  availability_zone = local.az_maps[data.huaweicloud_availability_zones.az.region]
  vpc_cidr          = var.vpc_cidr
  vpc_tags          = local.tags

  # config of subnet
  subnet_name           = format("%s-%s", local.app_id, "subnet")
  vpc_subnet_dns_list   = local.subnet_dns_list_maps[data.huaweicloud_availability_zones.az.region]
  vpc_subnet_cidr       = var.vpc_subnet_cidr
  vpc_subnet_gateway_ip = var.vpc_subnet_gateway_ip
  subnet_tags           = local.tags
}

//创建弹性公网1
module "eip-ecs-wm" {
  source = "./modules/eip"
  is_eip_create = true
  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip-ecs-wm")
  publicip_type         = local.publicip_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_share_type = local.bandwidth_share_type
  bandwidth_size        = local.bandwidth_size
  charging_mode = local.bandwidth_charge_mode == "traffic"? "postPaid":local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags
}

//创建弹性公网2
module "eip-ecs-app" {
  source = "./modules/eip"
  is_eip_create = true
  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip-ecs-app")
  publicip_type         = local.publicip_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_share_type = local.bandwidth_share_type
  bandwidth_size        = local.bandwidth_size
  charging_mode = local.bandwidth_charge_mode == "traffic"? "postPaid":local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags
}

module "eip-cbh" {
  source = "./modules/eip"
  is_eip_create = var.is_create_cbh
  name_suffix = local.name_suffix
  eip_name    = format("%s-%s", local.app_id, "eip-cbh")
  publicip_type         = local.publicip_type
  bandwidth_charge_mode = local.bandwidth_charge_mode
  bandwidth_share_type = local.bandwidth_share_type
  bandwidth_size        = local.bandwidth_size
  charging_mode = local.bandwidth_charge_mode == "traffic"? "postPaid":local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  eip_tags = local.tags
}

# Create security group for ecs
module "ecs-wm-security-group" {
  source = "./modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "ecs-wm-secgroup")
  is_delete_default_rules = true

  //TODO 服务器安全组修改
  // 服务器安全组配置
  secgroup_rules_configuration = [ //todo  修改安全组入规则，remote_ip_prefix为允许访问源地址，默认只有子网，ports为端口。
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = var.vpc_cidr, remote_group_id = null },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null }
  ]
}

// Create  ECS
module "ecs-wm" {
  source = "./modules/ecs"

  is_instance_create = true
  # The total number of The ECS instance
  instance_count = 1

  instance_image_id  = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]
  instance_flavor_id = local.ecs_flavor

  # You need to change the performance type��cpu and memory of the ECS based on the your requirements.
  instance_flavor_performance = local.instance_performance_type
  instance_flavor_cpu         = local.instance_flavor_cpu
  instance_flavor_memory      = local.instance_flavor_memory

  #agent_list    = local.ecs_agent_list
  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs-wm")

  security_group_ids = module.ecs-wm-security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = local.ecs_volume_type
  system_disk_size = local.ecs_volume_size
  data_disks = local.ecs_data_disks
  # 绑定eip
  eip_id = module.eip-ecs-wm.id != null && length(module.eip-ecs-wm.id) > 0 ? module.eip-ecs-wm.id[0] : null
  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = module.vpc.subnet_id, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = true, access_network = false },

  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  admin_pass = var.admin_password

  instance_tags = local.tags

  // TODO 根据实际软件包格式和安装启动脚本名称修改下载、解压、安装命令
  // 此处为中间件服务器执行
  user_data = <<-EOF
  #! /bin/bash
  #   ecs服务器系统用户root密码  "${var.admin_password}"

  #   RDS服务ip    "${module.rds_mysql.rds_ip[0]}"
  #   RDS服务端口   3306
  #   RDS服务管理员用户名  root
  #   RDS服务管理员密码    "${var.db_password}"
  #
  #   redis1服务ip     "${module.dcs1.dcs_ip}"   示例： 192.168.10.133,192.168.10.194,192.168.10.120,192.168.10.66,192.168.10.61,192.168.10.151
  #   redis1服务ip     "${module.dcs2.dcs_ip}"   示例： 192.168.10.133,192.168.10.194,192.168.10.120,192.168.10.66,192.168.10.61,192.168.10.151
  #   redis服务端口  : "${local.dcs_port}"
  #   redis服务密码  "${var.dcs_password}"
  
  echo "root:${var.admin_password}" | chpasswd
  sleep 10
  #初始化数据盘，挂载到/data1
  Dev=$(fdisk -l 2>/dev/null | grep -o "/dev/.*d[b-z]")
  Mfile=/data1
  mkdir $Mfile
  fdisk_mkfs() {
  echo -e "n\np\n1\n\n\nwq" | fdisk -S 56 $1
  mkfs.ext4 $${1}1
  }
  fdisk_mkfs $Dev > /dev/null 2>&1
  mount $${Dev}1 $Mfile
  uuids=`blkid |grep $${Dev}1|awk '{print $2}'|awk -F'[="]+' '{print $2}'`
  echo "UUID=$uuids       $Mfile        ext4    defaults        0 2" >> /etc/fstab

EOF
}


# Create security group for ecs
module "ecs-app-security-group" {
  source = "./modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "ecs-app-secgroup")
  is_delete_default_rules = true

  //TODO 服务器安全组修改
  // 服务器安全组配置
  secgroup_rules_configuration = [ //todo  修改安全组入规则，remote_ip_prefix为允许访问源地址，默认只有子网，ports为端口。
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "22,80,443", remote_ip_prefix = var.vpc_cidr, remote_group_id = null },
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = var.vpc_cidr, remote_group_id = null },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null }
  ]
}

// Create  ECS
module "ecs-app" {
  source = "./modules/ecs"

  is_instance_create = true
  # The total number of The ECS instance
  instance_count = 1

  instance_image_id  = local.instance_image_id_maps[data.huaweicloud_availability_zones.az.region]
  instance_flavor_id = local.ecs_flavor

  # You need to change the performance type��cpu and memory of the ECS based on the your requirements.
  instance_flavor_performance = local.instance_performance_type
  instance_flavor_cpu         = local.instance_flavor_cpu
  instance_flavor_memory      = local.instance_flavor_memory

  #agent_list    = local.ecs_agent_list
  name_suffix   = local.name_suffix
  instance_name = format("%s-%s", local.app_id, "ecs-app")

  security_group_ids = module.ecs-app-security-group.secgroup_id

  # Default size and type of the system disk, You need to modify it according to your actual situation. And the size must be greater than the minimum memory size required by the image.
  system_disk_type = local.ecs_volume_type
  system_disk_size = local.ecs_volume_size
  data_disks = local.ecs_data_disks
  # 绑定eip
  eip_id = module.eip-ecs-app.id != null && length(module.eip-ecs-app.id) > 0 ? module.eip-ecs-app.id[0] : null
  # If you need to create multiple network adapters, you need to configure multiple data records.
  networks_configuration = [
    { subnet_id = module.vpc.subnet_id, fixed_ip_v4 = null, ipv6_enable = false, source_dest_check = true, access_network = false },

  ]

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  admin_pass = var.admin_password

  instance_tags = local.tags

  // TODO 根据实际软件包格式和安装启动脚本名称修改下载、解压、安装命令
  //此处为应用服务器执行
  user_data = <<-EOF
  #! /bin/bash
  #   8C64G ecs-wm公网ip  "${module.eip-ecs-wm.ip[0]}"
  #   8C64G ecs-wm内网ip   "${module.ecs-wm.access_ips[0]}"
  #   ecs服务器系统用户root密码  "${var.admin_password}"
  #   ecs服务器端口 8002 8080

  #   RDS服务ip    "${module.rds_mysql.rds_ip[0]}"
  #   RDS服务端口   3306
  #   RDS服务管理员用户名  root
  #   RDS服务管理员密码    "${var.db_password}"
  #
  #   redis1服务ip     "${module.dcs1.dcs_ip}"   示例： 192.168.10.133,192.168.10.194,192.168.10.120,192.168.10.66,192.168.10.61,192.168.10.151
  #   redis2服务ip     "${module.dcs2.dcs_ip}"   示例： 192.168.10.133,192.168.10.194,192.168.10.120,192.168.10.66,192.168.10.61,192.168.10.151
  #   redis服务端口  : "${local.dcs_port}"
  #   redis服务密码  "${var.dcs_password}"

  echo "root:${var.admin_password}" | chpasswd
  sleep 10
  #初始化数据盘，挂载到/data1
  Dev=$(fdisk -l 2>/dev/null | grep -o "/dev/.*d[b-z]")
  Mfile=/data1
  mkdir $Mfile
  fdisk_mkfs() {
  echo -e "n\np\n1\n\n\nwq" | fdisk -S 56 $1
  mkfs.ext4 $${1}1
  }
  fdisk_mkfs $Dev > /dev/null 2>&1
  mount $${Dev}1 $Mfile
  uuids=`blkid |grep $${Dev}1|awk '{print $2}'|awk -F'[="]+' '{print $2}'`
  echo "UUID=$uuids       $Mfile        ext4    defaults        0 2" >> /etc/fstab

  #下载软件安装包
  wget -O /data1/park-install-huawei.zip "${local.software_url_decode}"
  # 解压
  unzip  /data1/park-install-huawei.zip -d /data1/
  #渲染配置

  echo "SERVER1=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)" >>/data1/park-install-huawei/.env
  echo "SERVER1_ROOT_PASSWD=${var.admin_password}" >>/data1/park-install-huawei/.env
  echo "SERVER2=${module.ecs-wm.access_ips[0]}" >>/data1/park-install-huawei/.env
  echo "SERVER2_ROOT_PASSWD=${var.admin_password}" >>/data1/park-install-huawei/.env

  echo "PROJECT_NAME=${var.project_name}" >>/data1/park-install-huawei/.env
  echo "PROJECT_NAME_ZH=${var.project_name_zh}" >>/data1/park-install-huawei/.env
  echo "NAMESPACE_ID=${var.namespace_id}" >>/data1/park-install-huawei/.env
  echo "OPC_ZONE_ID=${var.opc_zone_id}" >>/data1/park-install-huawei/.env
  echo "DOMAIN=${var.domain}" >>/data1/park-install-huawei/.env


  #云rds信息
  echo "RDS_HOST=${module.rds_mysql.rds_ip[0]}" >>/data1/park-install-huawei/.env
  echo "RDS_ROOT_PASSWD=${var.db_password}" >>/data1/park-install-huawei/.env
  #云redis信息
  echo "REDIS_CACHE=${module.dcs1.dcs_ip}" >>/data1/park-install-huawei/.env
  echo "REDIS_CACHE_PASSWD=${var.dcs_password}" >>/data1/park-install-huawei/.env
  echo "REDIS_STORAGE=${module.dcs2.dcs_ip}" >>/data1/park-install-huawei/.env
  echo "REDIS_STORAGE_PASSWD=${var.dcs_password}" >>/data1/park-install-huawei/.env

  #对象存储连接信息
  echo "ENDPOINT=${var.obs_endpoint}" >>/data1/park-install-huawei/.env
  echo "ACCESSKEY=${var.obs_accesskey}" >>/data1/park-install-huawei/.env
  echo "SECRETKEY=${var.obs_secretkey}" >>/data1/park-install-huawei/.env
  echo "BUCKETNAME=${var.obs_bucketname}"   >>/data1/park-install-huawei/.env
  执行安装包中的安装脚本
  cd /data1/park-install-huawei/ && sh  install.sh &>> install.log
EOF
}

# Create RDS for MySQL
module "rds_mysql" {
  source = "./modules/rds_mysql"

  is_rds_create = true

  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period

  name_suffix          = "mkp"
  db_instance_name     = format("%s-%s", local.app_id, "rds")
  db_availability_zone = length(local.rds_azs)>1 ? slice(local.rds_azs,0 ,2 ) : local.rds_azs
  # db_availability_zone = slice(local.rds_azs,0 ,1 )
  time_zone            = "UTC"

  vpc_id            = module.vpc.vpc_id
  subnet_id         = module.vpc.subnet_id
  security_group_id = module.rds-security-group.secgroup_id[0]

  flavor = data.huaweicloud_rds_flavors.rds_flavor.flavors[0].name
  lower_case_table_names = "1"


  # db config
  db_engines = local.db_type
  db_version  = local.db_version
  db_password = var.db_password
  db_port     = local.db_port

  # backup_strategy
  keep_days  = local.db_keep_days
  start_time = local.db_start_time

  # volume config
  db_instance_storage_type = local.db_instance_storage_type
  db_allocated_storage     = local.db_allocated_storage

  #数据库
  database_name = local.database_name
  character_set = "utf8"
  #账号
  account_name = local.account_name
  account_pwd = var.db_password

  rds_tags = local.tags
}

# Create security group for rds
module "rds-security-group" {
  source = "./modules/security-group"

  is_secgroup_create = true

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "rdssecgroup")
  is_delete_default_rules = true

  # TODo 数据库安全组配置
  //数据库安全组配置，对同子网开放3306端口
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "3306", remote_ip_prefix = var.vpc_cidr, remote_group_id = null }
    ]
}

// Create a DCS (for Redis)
module "dcs1" {
  source = "./modules/dcs"

  name_suffix        = local.name_suffix
  dcs_name           = format("%s-%s", local.app_id, "dcs1")
  dcs_engine         = local.dcs_engine
  dcs_engine_version = local.dcs_engine_version
  dcs_capacity       = local.dcs_capacity
  dcs_flavor         = local.dcs_flavor
  dcs_cache_mode     = local.dcs_cache_mode
  vpc_id             = module.vpc.vpc_id
  subnet_id          = module.vpc.subnet_id
  dcs_password       = var.dcs_password
  dcs_port           = local.dcs_port
  # TODO 修改白名单
  # 配置白名单，当前配置的是所在VPC网段
  whitelists_configuration = [{ group_name = "dcs_whitelists", ip_address = [var.vpc_cidr] }]
  # 开启白名单，不开启的话则同VPC可访问
  whitelist_enable = true

  # 计费
  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period
  dcs_tags      = local.tags
}

// Create a DCS (for Redis)
module "dcs2" {
  source = "./modules/dcs"

  name_suffix        = local.name_suffix
  dcs_name           = format("%s-%s", local.app_id, "dcs2")
  dcs_engine         = local.dcs_engine
  dcs_engine_version = local.dcs_engine_version
  dcs_capacity       = local.dcs_capacity
  dcs_flavor         = local.dcs_flavor
  dcs_cache_mode     = local.dcs_cache_mode
  vpc_id             = module.vpc.vpc_id
  subnet_id          = module.vpc.subnet_id
  dcs_password       = var.dcs_password
  dcs_port           = local.dcs_port
  # TODO 修改白名单
  # 配置白名单，当前配置的是所在VPC网段
  whitelists_configuration = [{ group_name = "dcs_whitelists", ip_address = [var.vpc_cidr] }]
  # 开启白名单，不开启的话则同VPC可访问
  whitelist_enable = true

  # 计费
  charging_mode = local.charging_mode
  period_unit   = local.period_unit
  period        = local.period
  dcs_tags      = local.tags
}


// Create a CBR
module "cbr" {
  is_create_cbr = true

  source                = "./modules/cbr"
  vault_name            = format("%s-%s", local.app_id, "cbr")
  name_suffix           = local.name_suffix
  # 存储库类型，server-云服务器备份库
  type                  = local.vault_type
  # 保护类型，backup-备份；replication-复制
  protection_type       = local.vault_protection_type
  # 一致性等级
  consistent_level      = local.vault_consistent_level
  size                  = local.vault_size
  # 备份数据冗余，false-单AZ；true-多AZ
  is_multi_az           = local.vault_is_multi_az
  # 备份名称前缀
  backup_name_prefix    = local.vault_backup_name_prefix
  charging_mode         = var.charging_mode
  period_unit = var.period_unit
  period = var.period
  # 服务器列表
  resources = [
    {server_id = module.ecs-wm.ecs_ids[0],excludes = [],includes = []}
    ]

  # 备份策略
  policy_name     = format("%s-%s", local.app_id, "cbr_policy")
  #策略类型，backup-备份；replication-复制
  policy_type     = local.policy_type
  # 备份保修时间
  time_period     = local.policy_time_period
  # 启用策略
  enabled         = local.policy_enabled
  # 备份间隔，每n天
  backup_interval = local.policy_backup_interval
  # 备份时间，当前HH:MM
  execution_times = local.policy_execution_times
  vault_tags = local.tags
}

# Create security group for CBH
module "cbh-security-group" {
  source = "./modules/security-group"

  is_secgroup_create = var.is_create_cbh

  name_suffix             = local.name_suffix
  secgroup_name           = format("%s-%s", local.app_id, "cbhsecgroup")
  is_delete_default_rules = true

  //TODO 修改云堡垒机安全组
  // 服务器安全组配置
  secgroup_rules_configuration = [
    { description = null, direction = "ingress", ethertype = "IPv4", protocol = "tcp", ports = "443,2222", remote_ip_prefix = var.vpc_cidr, remote_group_id = null },
    { description = null, direction = "egress", ethertype = "IPv4", protocol = null, ports = null, remote_ip_prefix = "0.0.0.0/0", remote_group_id = null }
  ]
}
// Create a CBH
module "cbh" {
  source = "./modules/cbh"

  is_instance_create = var.is_create_cbh
  #basic: 标准
  #enhance: 专业
  cbh_type     = "basic"
  asset_number = 10

  name_suffix           = local.name_suffix
  cbh_name              = format("%s-%s", local.app_id, "cbh")
  vpc_id                = module.vpc.vpc_id
  subnet_id             = module.vpc.subnet_id
  security_group_id     = var.is_create_cbh ? module.cbh-security-group.secgroup_id[0] : null
  availability_zone     = data.huaweicloud_availability_zones.az.names[0]
  cbh_password          = var.cbh_password
  public_ip_id          = module.eip-cbh.id != null && length(module.eip-cbh.id) > 0 ? module.eip-cbh.id[0] : null
  charging_mode         = "prePaid"
  period_unit           = var.period_unit
  period                = var.period
  #enterprise_project_id = "xxx"
}
